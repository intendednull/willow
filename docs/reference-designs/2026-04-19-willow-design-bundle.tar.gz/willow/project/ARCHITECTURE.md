# Willow — architecture

Two presentation surfaces (`Willow.html` desktop, `Willow Mobile.html` mobile)
share one codebase. The review canvas (`Willow Review.html`) embeds both in
iframes for visual drift-detection.

## Layout

```
src/
├── data.jsx              ← groves, peers, channels, messages, DMs   (shared)
├── icons.jsx             ← icon set                                  (shared)
├── shared/               ← anything that must behave/read identically
│   ├── messaging.jsx     ← mentions, reactions, badges, self-highlight
│   ├── sas.jsx           ← fingerprint words + grid (security-critical)
│   ├── call_atoms.jsx    ← screen-share content, whisper pill, handoff
│   └── thread_atoms.jsx  ← thread parent card + reply list + copy
├── app.jsx, chat.jsx, thread.jsx, call.jsx,
│   onboarding.jsx, sidebar.jsx, dms.jsx, members.jsx,
│   settings.jsx, discovery.jsx, governance.jsx, ...
│                         ← DESKTOP layouts + hover affordances
└── mobile/
    ├── m_app.jsx, m_chat.jsx, m_thread.jsx, m_call.jsx,
    │   m_onboarding.jsx, m_home.jsx, m_dms.jsx,
    │   m_settings.jsx, m_discovery.jsx, m_ephemeral.jsx, m_sync.jsx
    │                     ← MOBILE layouts + swipe gestures + sheets
    ├── m_primitives.jsx
    └── {ios,android}-frame.jsx
```

## The rule

> If a change is about **what the feature does**, or **what it says** to the
> user, it goes in `src/shared/`.
>
> If it's about **how it looks on that platform** (three panes vs stacked
> screens, hover toolbars vs swipe gestures, side panel vs full-screen modal),
> it goes in the platform file.

## How sharing works

Scripts load as Babel JSX in script tags, so every module exports via
`Object.assign(window, {...})` at the bottom. Platform files reference shared
symbols as globals.

Components that need a platform-specific piece (e.g. the mobile Avatar looks
different from the desktop one) accept it as a prop:

```jsx
<ThreadParentCard parent={p} AvatarComponent={MAvatar} size="sm"/>
```

## When to extract

Don't refactor pre-emptively. Extract when:
1. A teammate comment reveals drift (one surface is behind the other).
2. You're about to copy-paste logic between `src/foo.jsx` and `src/mobile/m_foo.jsx`.
3. Copy changes — copy belongs in `src/shared/*_COPY` constants so it can only change once.

## Verifying no drift

Open `Willow Review.html` to see all three surfaces side-by-side. If mentions,
badges, fingerprints, screen-share, or whisper affordances look different
across the panes, something is being defined per-surface that should be shared.
