// Roles + Invites + Files — surface willow's permission model and content-addressed files.

const ROLES = [
  { name: 'steward', color: 'var(--willow)', count: 1, perms: ['ManageChannels','ManageRoles','ManageMessages','KickMembers','CreateInvite','ProposeAction','SendMessages','ReadHistory','SyncProvider'] },
  { name: 'moderator', color: 'var(--moss-3)', count: 2, perms: ['ManageChannels','ManageMessages','CreateInvite','SendMessages','ReadHistory'] },
  { name: 'contributor', color: 'var(--moss-4)', count: 4, perms: ['CreateInvite','SendMessages','ReadHistory','ProposeAction'] },
  { name: 'guest', color: 'var(--ink-2)', count: 1, perms: ['SendMessages','ReadHistory'] },
];
const ALL_PERMS = [
  'ManageChannels','ManageRoles','ManageMessages','KickMembers',
  'CreateInvite','SendMessages','ReadHistory','ProposeAction','SyncProvider',
];

const INVITES = [
  { id: 'i_2f4', fp: 'cedar-moss-delta', by: 'u1', made: '2h ago', expires: '6d 22h', uses: { used: 1, max: 5 }, role: 'contributor' },
  { id: 'i_9a1', fp: 'loom-amber-river', by: 'u4', made: 'yesterday', expires: '15h', uses: { used: 0, max: 1 }, role: 'guest', note: 'for kes\'s sister' },
  { id: 'i_4c8', fp: 'slate-heron-mint', by: 'u6', made: '3d ago', expires: 'expired', uses: { used: 3, max: 3 }, role: 'contributor', burned: true },
];

const FILES = [
  { name: 'reading-list-winter.md', size: '4.2 KB', chunks: 1, hash: 'a41f…72e0', by: 'u6', at: '09:14', keys: 'grove-keys · ep 14' },
  { name: 'IMG_2108.jpg',           size: '1.2 MB', chunks: 3, hash: 'b8c2…019d', by: 'u1', at: '10:02', keys: 'grove-keys · ep 14', img: true },
  { name: 'storm-notes.pdf',        size: '820 KB', chunks: 2, hash: '2d40…91ab', by: 'u4', at: '10:08', keys: 'grove-keys · ep 14' },
  { name: 'river-glass-vol2.flac',  size: '38.4 MB',chunks: 78,hash: 'f19e…44c2', by: 'u8', at: 'yst', keys: 'custom · 3 holders', large: true },
  { name: 'field-recording-06.wav', size: '12.1 MB',chunks: 25,hash: '504a…be13', by: 'u6', at: 'yst', keys: 'ephemeral · 3d', ephemeral: true },
];

const RolesInvitesFilesView = () => {
  const [tab, setTab] = React.useState('roles');
  return (
    <div style={{ flex: 1, background: 'var(--bg-1)', display: 'flex', flexDirection: 'column', minWidth: 0 }}>
      <div style={{ padding: '22px 32px 0', borderBottom: '1px solid var(--line-soft)' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 24, color: 'var(--ink-0)' }}>
          grove management
        </div>
        <div style={{ fontSize: 12.5, color: 'var(--ink-2)', marginTop: 4, maxWidth: 620 }}>
          roles, invites, and shared files. every change here is a signed event and needs a vote unless self-scoped.
        </div>
        <div style={{ display: 'flex', gap: 4, marginTop: 16 }}>
          {[
            { id: 'roles', label: 'roles & permissions', icon: Icons.Shield },
            { id: 'invites', label: 'invites', icon: Icons.Link },
            { id: 'files', label: 'files', icon: Icons.Paperclip },
          ].map(t => {
            const I = t.icon;
            const active = tab === t.id;
            return (
              <button key={t.id} onClick={() => setTab(t.id)} style={{
                padding: '8px 14px', borderRadius: '8px 8px 0 0',
                background: active ? 'var(--bg-1)' : 'transparent',
                borderBottom: active ? '2px solid var(--moss-2)' : '2px solid transparent',
                color: active ? 'var(--ink-0)' : 'var(--ink-3)', fontSize: 13,
                display: 'inline-flex', alignItems: 'center', gap: 6,
              }}>
                <I size={13} stroke={1.6}/>{t.label}
              </button>
            );
          })}
        </div>
      </div>
      <div className="scroll" style={{ flex: 1, padding: '20px 32px 40px' }}>
        {tab === 'roles' && <RolesPanel/>}
        {tab === 'invites' && <InvitesPanel/>}
        {tab === 'files' && <FilesPanel/>}
      </div>
    </div>
  );
};

const RolesPanel = () => (
  <div>
    <div style={{ background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 12, overflow: 'hidden' }}>
      <div style={{
        display: 'grid',
        gridTemplateColumns: `180px repeat(${ALL_PERMS.length}, 1fr)`,
        gap: 0, borderBottom: '1px solid var(--line)',
      }}>
        <div style={{ padding: '12px 16px', fontSize: 11, color: 'var(--ink-3)',
          textTransform: 'uppercase', letterSpacing: 1.2 }}>role</div>
        {ALL_PERMS.map(p => (
          <div key={p} style={{ padding: '12px 6px', fontSize: 10, color: 'var(--ink-3)',
            writingMode: 'vertical-rl', transform: 'rotate(180deg)',
            fontFamily: 'var(--font-mono)', letterSpacing: 0.3 }}>
            {p}
          </div>
        ))}
      </div>
      {ROLES.map(r => (
        <div key={r.name} style={{
          display: 'grid',
          gridTemplateColumns: `180px repeat(${ALL_PERMS.length}, 1fr)`,
          gap: 0, borderBottom: '1px solid var(--line-soft)',
          alignItems: 'center',
        }}>
          <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ width: 10, height: 10, borderRadius: '50%', background: r.color }}/>
            <div>
              <div style={{ fontSize: 13, color: 'var(--ink-0)' }}>{r.name}</div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{r.count} peer{r.count === 1 ? '' : 's'}</div>
            </div>
          </div>
          {ALL_PERMS.map(p => {
            const has = r.perms.includes(p);
            return (
              <div key={p} style={{ padding: '12px 6px', display: 'flex', justifyContent: 'center' }}>
                {has
                  ? <span style={{ color: r.color }}><Icons.Check size={14} stroke={2.2}/></span>
                  : <span style={{ color: 'var(--ink-4)', fontSize: 10, fontFamily: 'var(--font-mono)' }}>—</span>}
              </div>
            );
          })}
        </div>
      ))}
    </div>
    <div style={{ marginTop: 12, fontSize: 12, color: 'var(--ink-3)', display: 'flex', alignItems: 'center', gap: 8 }}>
      <Icons.Shield size={12}/>
      role changes require a grove vote. propose one from <span style={{ color: 'var(--ink-1)' }}>governance</span>.
    </div>
  </div>
);

const InvitesPanel = () => (
  <div>
    <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
      <button style={{ padding: '10px 14px', borderRadius: 10, background: 'var(--moss-1)', color: 'var(--moss-4)',
        fontSize: 13, fontWeight: 500, display: 'inline-flex', alignItems: 'center', gap: 8 }}>
        <Icons.Plus size={13} stroke={2}/>create invite
      </button>
      <div style={{ flex: 1, padding: '10px 14px', borderRadius: 10, background: 'var(--bg-2)',
        border: '1px dashed var(--line)', fontSize: 12, color: 'var(--ink-3)',
        display: 'flex', alignItems: 'center', gap: 8 }}>
        <Icons.Fingerprint size={14}/>
        invites are human-readable fingerprints. paste one from someone you trust, or share yours by voice.
      </div>
    </div>

    {INVITES.map(inv => (
      <div key={inv.id} style={{
        display: 'grid', gridTemplateColumns: '1fr 160px 140px 120px 90px',
        gap: 16, alignItems: 'center',
        padding: '14px 16px', borderRadius: 12,
        background: inv.burned ? 'transparent' : 'var(--bg-1)',
        border: `1px ${inv.burned ? 'dashed' : 'solid'} var(--line)`,
        opacity: inv.burned ? 0.55 : 1, marginBottom: 10,
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Icons.Link size={14}/>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--ink-0)' }}>
              willow://invite/{inv.fp}
            </span>
          </div>
          {inv.note && <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 3, fontStyle: 'italic' }}>
            — {inv.note}
          </div>}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <Avatar user={PEOPLE_BY_ID[inv.by]} size={20}/>
          <span style={{ fontSize: 12, color: 'var(--ink-2)' }}>{PEOPLE_BY_ID[inv.by].name} · {inv.made}</span>
        </div>
        <Tag mono color={inv.role === 'guest' ? 'var(--ink-2)' : 'var(--moss-3)'} border="var(--line)">
          grants {inv.role}
        </Tag>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: inv.burned ? 'var(--ink-4)' : 'var(--ink-2)' }}>
          {inv.uses.used}/{inv.uses.max} uses · {inv.expires}
        </div>
        <div style={{ textAlign: 'right' }}>
          {!inv.burned && (
            <button style={{ padding: '5px 10px', borderRadius: 6, background: 'transparent',
              border: '1px solid var(--line)', color: 'var(--err)', fontSize: 11 }}>revoke</button>
          )}
        </div>
      </div>
    ))}
  </div>
);

const FilesPanel = () => (
  <div>
    <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
      <Tag mono color="var(--moss-3)" border="var(--line)"><Icons.Paperclip size={10}/>{FILES.length} files</Tag>
      <Tag mono color="var(--ink-2)" border="var(--line)">content-addressed · sha-256</Tag>
      <Tag mono color="var(--ink-2)" border="var(--line)">chunked at 256 KiB</Tag>
      <span style={{ flex: 1 }}/>
      <Tag mono color="var(--ink-2)" border="var(--line)"><Icons.Lock size={10}/>keys per chunk</Tag>
    </div>
    <div style={{ background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 12, overflow: 'hidden' }}>
      {FILES.map((f, i) => (
        <div key={i} style={{
          display: 'grid', gridTemplateColumns: '40px 1fr 90px 80px 170px 130px 90px',
          gap: 14, alignItems: 'center',
          padding: '14px 18px',
          borderBottom: i < FILES.length - 1 ? '1px solid var(--line-soft)' : 'none',
        }}>
          <div style={{
            width: 34, height: 34, borderRadius: 8, background: 'var(--bg-2)', border: '1px solid var(--line)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: f.ephemeral ? 'var(--whisper)' : f.large ? 'var(--amber)' : 'var(--moss-3)',
          }}>
            {f.img ? <Icons.Spark size={16} stroke={1.4}/> : <Icons.Paperclip size={14} stroke={1.4}/>}
          </div>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 13, color: 'var(--ink-0)', whiteSpace: 'nowrap',
              overflow: 'hidden', textOverflow: 'ellipsis' }}>{f.name}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)' }}>
              sha-256 · {f.hash}
            </div>
          </div>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11.5, color: 'var(--ink-1)' }}>{f.size}</span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-2)' }}>
            {f.chunks} chunk{f.chunks === 1 ? '' : 's'}
          </span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Avatar user={PEOPLE_BY_ID[f.by]} size={18}/>
            <span style={{ fontSize: 11.5, color: 'var(--ink-2)' }}>{PEOPLE_BY_ID[f.by].name} · {f.at}</span>
          </div>
          <Tag mono color={f.ephemeral ? 'var(--whisper)' : 'var(--ink-2)'}
               border={f.ephemeral ? 'color-mix(in oklab, var(--whisper) 30%, var(--line))' : 'var(--line)'}>
            {f.keys}
          </Tag>
          <div style={{ textAlign: 'right' }}>
            <button style={{ padding: '4px 10px', borderRadius: 6, background: 'var(--bg-2)',
              border: '1px solid var(--line)', color: 'var(--ink-1)', fontSize: 11 }}>fetch</button>
          </div>
        </div>
      ))}
    </div>
  </div>
);

window.RolesInvitesFilesView = RolesInvitesFilesView;
