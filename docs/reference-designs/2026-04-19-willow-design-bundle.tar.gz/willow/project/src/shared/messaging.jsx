// Shared messaging primitives — used by both desktop and mobile chat views.
// Keep this module small and purely presentational so both surfaces can share it.

// ---- Mention parsing ----
// Matches @handle tokens, resolves against PEERS by handle / first-segment / name / 'you'.
const MENTION_RE = /@([a-z][a-z0-9._-]*)/gi;

const parseMentions = (body) => {
  if (!body || typeof body !== 'string') return [body];
  const out = []; let last = 0; let m;
  MENTION_RE.lastIndex = 0;
  while ((m = MENTION_RE.exec(body)) !== null) {
    const tok = m[1].toLowerCase();
    const user = PEERS.find(p =>
      p.handle.toLowerCase() === tok ||
      p.handle.toLowerCase().split('.')[0] === tok ||
      p.name.toLowerCase() === tok ||
      (tok === 'you' && p.self)
    );
    if (!user) continue;
    if (m.index > last) out.push(body.slice(last, m.index));
    out.push({ mention: user, raw: m[0] });
    last = m.index + m[0].length;
  }
  if (last < body.length) out.push(body.slice(last));
  return out.length ? out : [body];
};

// Returns true if message has an explicit mentions[] listing self, or @you/@<self-handle>
// appears in the body.
const messageMentionsMe = (m) => {
  if (Array.isArray(m.mentions) && m.mentions.some(id => PEOPLE_BY_ID[id]?.self)) return true;
  const parts = parseMentions(m.body || '');
  return parts.some(p => typeof p === 'object' && p.mention?.self);
};

// ---- Visuals ----

const MentionPill = ({ user, size = 'md' }) => {
  const isSelf = !!user.self;
  const small = size === 'sm';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'baseline',
      padding: small ? '0 5px' : '1px 6px',
      margin: '0 1px', borderRadius: 5,
      background: isSelf
        ? 'color-mix(in oklab, var(--amber) 28%, var(--bg-2))'
        : 'color-mix(in oklab, var(--moss-2) 22%, var(--bg-2))',
      color: isSelf ? 'var(--amber)' : 'var(--moss-3)',
      border: `1px solid ${isSelf ? 'var(--amber-soft)' : 'var(--moss-1)'}`,
      fontWeight: 500, fontSize: 'inherit', lineHeight: 1.35,
      cursor: 'pointer',
    }}>@{user.self ? 'you' : user.handle.split('.')[0]}</span>
  );
};

// Renders a message body string, turning @mentions into pills.
const MessageBody = ({ body }) => {
  const parts = parseMentions(body);
  return (
    <span>
      {parts.map((p, i) => typeof p === 'string'
        ? <span key={i}>{p}</span>
        : <MentionPill key={i} user={p.mention}/>)}
    </span>
  );
};

// ---- Reactions ----
const RECENT_REACTIONS = ['🍃', '💚', '☀️', '👀', '✨'];

// Existing-reactions strip (shown beneath a message when reactions exist).
// Compact variant for mobile, roomier for desktop.
const ReactionList = ({ list, compact = false, showAdd = !compact }) => (
  <div style={{ display: 'flex', gap: 5, marginTop: 6, flexWrap: 'wrap' }}>
    {list.map(([emoji, n], i) => (
      <span key={i} style={{
        display: 'inline-flex', alignItems: 'center', gap: 5,
        padding: compact ? '2px 8px' : '2px 8px', borderRadius: 999,
        background: 'var(--bg-2)', border: '1px solid var(--line)',
        fontSize: compact ? 11 : 12, color: 'var(--ink-1)', cursor: 'pointer',
      }}>
        <span>{emoji}</span><span style={{ color: 'var(--ink-2)', fontWeight: 500 }}>{n}</span>
      </span>
    ))}
    {showAdd && (
      <span style={{
        display: 'inline-flex', alignItems: 'center', padding: '2px 8px', borderRadius: 999,
        background: 'transparent', border: '1px dashed var(--line)', color: 'var(--ink-3)', cursor: 'pointer',
      }}>
        <Icons.Plus size={11}/><span style={{ marginLeft: 2 }}><Icons.Smile size={11}/></span>
      </span>
    )}
  </div>
);

// Hover-reveal toolbar (desktop). Mobile uses long-press instead.
const HoverReactionBar = ({ compact, onOpenThread }) => {
  const btn = {
    width: 26, height: 26, borderRadius: 6, background: 'transparent',
    color: 'var(--ink-2)',
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    cursor: 'pointer',
  };
  return (
    <div className="msg-actions" style={{
      position: 'absolute', right: 24, top: -14,
      display: 'none', alignItems: 'center', gap: 2,
      padding: 3, borderRadius: 10,
      background: 'var(--bg-1)', border: '1px solid var(--line)',
      boxShadow: '0 6px 20px rgba(0,0,0,0.35)', zIndex: 2,
    }}>
      {RECENT_REACTIONS.map((e, i) => (
        <button key={i} title={`react ${e}`} style={{ ...btn, fontSize: 14 }}
          onMouseEnter={ev => ev.currentTarget.style.background = 'var(--bg-3)'}
          onMouseLeave={ev => ev.currentTarget.style.background = 'transparent'}
        >{e}</button>
      ))}
      <div style={{ width: 1, height: 16, background: 'var(--line)', margin: '0 2px' }}/>
      <button title="more reactions" style={btn}><Icons.Smile size={14} stroke={1.6}/></button>
      <button title="start thread" style={btn} onClick={onOpenThread}><Icons.Thread size={14} stroke={1.6}/></button>
      <button title="whisper reply" style={btn}><Icons.Ear size={14} stroke={1.6}/></button>
      <button title="more" style={btn}><Icons.More size={14} stroke={1.6}/></button>
    </div>
  );
};

// ---- Shared message badges ----

const WhisperBadge = ({ compact }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 4,
    padding: compact ? '1px 6px' : '2px 7px', borderRadius: 999,
    background: 'color-mix(in oklab, var(--whisper) 20%, var(--bg-2))',
    color: 'var(--whisper)',
    border: '1px solid color-mix(in oklab, var(--whisper) 30%, var(--bg-2))',
    fontSize: compact ? 10 : 10.5, fontFamily: 'var(--font-ui)', lineHeight: 1.2,
  }}>
    <Icons.Ear size={compact ? 9 : 10} stroke={1.6}/>{compact ? 'whisper' : 'whisper'}
  </span>
);

const QueuedBadge = ({ compact }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 4,
    padding: compact ? '1px 6px' : '2px 7px', borderRadius: 999,
    background: 'var(--bg-2)', color: 'var(--amber)',
    border: '1px solid var(--amber-soft)',
    fontFamily: 'var(--font-mono)',
    fontSize: compact ? 10 : 10.5, lineHeight: 1.2, letterSpacing: 0.2,
  }}>
    <Icons.Signal size={compact ? 9 : 10} stroke={1.6}/>{compact ? 'queued' : 'synced from queue'}
  </span>
);

const PinBadge = ({ compact }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 4,
    padding: compact ? '1px 6px' : '2px 7px', borderRadius: 999,
    background: 'transparent', color: 'var(--amber)',
    border: '1px solid var(--amber-soft)',
    fontSize: compact ? 10 : 10.5, lineHeight: 1.2,
  }}>
    <Icons.Pin size={compact ? 9 : 10}/>pinned
  </span>
);

// Row-level styles when the current user is @mentioned in a message.
// Both desktop and mobile apply this to the message container.
const mentionHighlightStyle = (mentionsMe) => mentionsMe ? {
  borderLeft: '2px solid var(--amber)',
  background: 'color-mix(in oklab, var(--amber) 8%, transparent)',
} : {
  borderLeft: '2px solid transparent',
  background: 'transparent',
};

Object.assign(window, {
  parseMentions, messageMentionsMe,
  MentionPill, MessageBody,
  RECENT_REACTIONS, ReactionList, HoverReactionBar,
  WhisperBadge, QueuedBadge, PinBadge,
  mentionHighlightStyle,
});
