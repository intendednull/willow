// Shared thread primitives — parent message card, reply list, compose footer.
// Desktop renders these in a side panel; mobile renders them in a full-screen view.

// Parent-message card shown at the top of any thread view.
// Accepts an AvatarComponent prop so each surface can pass its platform Avatar.
const ThreadParentCard = ({ parent, AvatarComponent, size = 'md' }) => {
  if (!parent) return null;
  const u = PEOPLE_BY_ID[parent.from];
  if (!u) return null;
  const pad = size === 'sm' ? '10px 12px' : '6px 14px 10px';
  const margin = size === 'sm' ? '12px 12px 8px' : '0 10px 12px';
  const avSize = size === 'sm' ? 24 : 22;
  return (
    <div style={{
      padding: pad, margin, borderRadius: size === 'sm' ? 12 : 10,
      background: 'var(--bg-2)', border: '1px solid var(--line)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
        <AvatarComponent user={u} size={avSize}/>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--ink-0)' }}>{u.name}</span>
        <span style={{ fontSize: size === 'sm' ? 10 : 11, color: 'var(--ink-3)' }}>{parent.t}</span>
      </div>
      <div style={{ fontSize: 13, color: 'var(--ink-1)', lineHeight: 1.5 }}>
        <MessageBody body={parent.body}/>
      </div>
    </div>
  );
};

// Reply list — shared rendering, with platform Avatar passed in.
const ThreadReplyList = ({ replies, AvatarComponent, size = 'md' }) => (
  <>
    {replies.map((m, i) => {
      const uu = PEOPLE_BY_ID[m.from];
      const compact = i > 0 && replies[i-1].from === m.from;
      const avSize = size === 'sm' ? 26 : 24;
      return (
        <div key={m.id} style={{
          display: 'flex', gap: 10,
          padding: compact ? '1px 14px' : (size === 'sm' ? '5px 14px' : '6px 14px'),
          marginTop: compact ? 0 : (size === 'sm' ? 2 : 4),
        }}>
          <div style={{ width: 28, flexShrink: 0, paddingTop: 2 }}>
            {!compact && <AvatarComponent user={uu} size={avSize}/>}
          </div>
          <div style={{ minWidth: 0, flex: 1 }}>
            {!compact && (
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 1 }}>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--ink-0)' }}>{uu.name}</span>
                <span style={{ fontSize: size === 'sm' ? 10 : 10.5, color: 'var(--ink-3)' }}>{m.t}</span>
              </div>
            )}
            <div style={{
              fontSize: size === 'sm' ? 13.5 : 13,
              color: 'var(--ink-1)', lineHeight: 1.5,
            }}>
              <MessageBody body={m.body}/>
            </div>
          </div>
        </div>
      );
    })}
  </>
);

// Copy: shared across both.
const THREAD_COPY = {
  fromLabel: (channel, replies) => `from #${channel} · ${replies} replies`,
  sealedFooter: (n) => `sealed to thread participants (${n}) — not the whole grove`,
  composePlaceholder: 'reply to thread…',
};

Object.assign(window, { ThreadParentCard, ThreadReplyList, THREAD_COPY });
