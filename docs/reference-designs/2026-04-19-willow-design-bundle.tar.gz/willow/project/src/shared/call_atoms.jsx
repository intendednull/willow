// Shared call primitives — participant tiles, screen-share content, whisper pill.
// Both desktop CallView and mobile CallScreen compose these.

// Mock screen-share document — rendered identically in every call tile that is
// a screen share. If the mock changes, it changes on both surfaces at once.
const ScreenShareContent = ({ compact = false }) => {
  const titleH = compact ? 18 : 22;
  const chipSize = compact ? 6 : 8;
  const pad = compact ? '10px 12px' : 24;
  const fs = compact ? 10 : 12;
  const lh = compact ? 1.7 : 1.8;
  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column' }}>
      <div style={{
        height: titleH, background: '#0f0e0c',
        display: 'flex', alignItems: 'center', gap: compact ? 3 : 4, padding: `0 ${compact ? 8 : 10}px`,
        fontFamily: 'var(--font-mono)', fontSize: compact ? 9 : 10, color: 'var(--ink-3)',
      }}>
        <span style={{ width: chipSize, height: chipSize, borderRadius: '50%', background: '#c97a5a' }}/>
        <span style={{ width: chipSize, height: chipSize, borderRadius: '50%', background: '#d6a54a' }}/>
        <span style={{ width: chipSize, height: chipSize, borderRadius: '50%', background: '#8fb36a' }}/>
        <span style={{ marginLeft: compact ? 8 : 10 }}>
          {compact ? 'reading-list.md' : 'reading-list.md — draft'}
        </span>
      </div>
      <div style={{
        flex: 1, padding: pad, fontFamily: 'var(--font-mono)', fontSize: fs,
        color: 'var(--ink-2)', lineHeight: lh, background: '#141310',
      }}>
        <div style={{ color: 'var(--willow)' }}># {compact ? 'winter reading' : 'long reading list · winter'}</div>
        <div style={{ color: 'var(--ink-3)' }}>&gt; {compact ? 'drafting w/ perrin' : 'drafting with perrin + wren'}</div>
        <div style={{ height: compact ? 6 : 10 }}/>
        <div><span style={{ color: 'var(--moss-3)' }}>1.</span> {compact ? 'idea of north' : 'the idea of north'}</div>
        <div><span style={{ color: 'var(--moss-3)' }}>2.</span> river-glass{compact ? ' ii' : ', vol. ii'}</div>
        {!compact && <div><span style={{ color: 'var(--moss-3)' }}>3.</span> field recording as memoir</div>}
        <div>
          <span style={{ color: 'var(--moss-3)' }}>{compact ? '3.' : '4.'}</span>{' '}
          {!compact && '━━━ '}
          <span style={{
            background: 'var(--moss-1)', color: 'var(--moss-4)',
            padding: compact ? '0 3px' : '0 4px',
          }}>cursor</span>
        </div>
        {!compact && <>
          <div style={{ height: 10 }}/>
          <div style={{ color: 'var(--ink-3)' }}>// annotations visible to the call only</div>
        </>}
      </div>
    </div>
  );
};

// Status pill shown in the call header when a whisper is active.
// Desktop renders it in the top toolbar; mobile renders it above the participant grid.
const WhisperPill = ({ label = 'whisper · ori', onClick }) => (
  <button onClick={onClick} style={{
    display: 'inline-flex', alignItems: 'center', gap: 6,
    padding: '3px 10px', borderRadius: 999,
    background: 'color-mix(in oklab, var(--whisper) 14%, var(--bg-1))',
    border: '1px solid color-mix(in oklab, var(--whisper) 40%, var(--line))',
    color: 'var(--whisper)', fontSize: 11, fontFamily: 'var(--font-mono)',
    cursor: 'pointer',
  }}>
    <Icons.Ear size={10} stroke={1.8}/>{label}
  </button>
);

// Handoff device list — same three devices and copy, rendered differently
// (desktop popover vs mobile bottom sheet) by each surface.
const HANDOFF_DEVICES_DESKTOP = [
  { n: 'willow · desk',  here: true,  meta: 'this device' },
  { n: 'willow · phone', here: false, meta: 'last seen 3m ago · wifi' },
  { n: 'willow · cabin', here: false, meta: 'online · ethernet' },
];
const HANDOFF_DEVICES_MOBILE = [
  { n: 'willow · phone', here: true,  meta: 'this device' },
  { n: 'willow · desk',  here: false, meta: 'online · ethernet' },
  { n: 'willow · cabin', here: false, meta: 'last seen 3m · wifi' },
];
const HANDOFF_COPY = {
  title: 'move this call',
  subtitle: 'keys re-seal automatically on the new device. no re-join.',
};

// Speaking-time stats rows, shared by desktop stats popover (and available
// for mobile if we ever add it).
const SPEAKING_STATS = [
  { id: 'u6', bars: 92, t: '14:02' },
  { id: 'u1', bars: 68, t: '7:41' },
  { id: 'u4', bars: 40, t: '4:18' },
  { id: 'u2', bars: 28, t: '2:58' },
  { id: 'u9', bars: 12, t: '1:04' },
];

Object.assign(window, {
  ScreenShareContent, WhisperPill,
  HANDOFF_DEVICES_DESKTOP, HANDOFF_DEVICES_MOBILE, HANDOFF_COPY,
  SPEAKING_STATS,
});
