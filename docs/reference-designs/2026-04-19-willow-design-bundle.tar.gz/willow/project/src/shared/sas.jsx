// Short-Authentication-String verification — the six-word fingerprint grid.
// This is security-critical and MUST render identically on every surface.
// Both desktop onboarding and mobile onboarding consume from here.

// Derived from a session's shared key. In a real build this comes from crypto,
// not a hardcoded list — but the word list + grid shape is the UX contract.
const SAS_YOU_WORDS = ['willow', 'copper', 'reed', 'glade', 'slate', 'moth'];
const SAS_PEER_WORDS = ['cedar', 'moss', 'delta', 'rune', 'lamp', 'harbor'];
// What their device shows when it derived the SAME key (SAS match state).
const SAS_PEER_MATCHED_WORDS = SAS_YOU_WORDS;

// Renders a 2×3 grid of numbered words. Size variants: 'md' (desktop) / 'sm' (mobile).
const FingerprintGrid = ({ words, size = 'md' }) => {
  const cellPad = size === 'sm' ? '8px' : '10px 12px';
  const fs = size === 'sm' ? 12 : 14;
  const numFs = size === 'sm' ? 9 : 10;
  const gap = size === 'sm' ? 5 : 6;
  return (
    <div style={{
      marginTop: size === 'sm' ? 6 : 10,
      display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap,
    }}>
      {words.map((w, i) => (
        <div key={i} style={{
          padding: cellPad, background: 'var(--bg-2)', borderRadius: 8,
          border: '1px solid var(--line)',
          fontFamily: 'var(--font-mono)', fontSize: fs, color: 'var(--ink-0)',
          display: 'flex', alignItems: 'center', gap: size === 'sm' ? 4 : 6,
        }}>
          <span style={{ fontSize: numFs, color: 'var(--ink-4)' }}>{i+1}</span>{w}
        </div>
      ))}
    </div>
  );
};

// Section label above a fingerprint grid (identical copy on both surfaces).
const FingerprintLabel = ({ which, size = 'md' }) => (
  <div style={{
    fontSize: size === 'sm' ? 10 : 11.5, color: 'var(--ink-3)',
    marginTop: size === 'sm' ? 12 : 14, textTransform: 'uppercase', letterSpacing: 1.2,
  }}>
    {which === 'you' ? 'your fingerprint — read this aloud' : 'their fingerprint — do these match?'}
  </div>
);

// Copy shared across both surfaces.
const SAS_COPY = {
  title: 'add a friend',
  intro: "compare six words on two screens. if they match, you've verified each other — no one can impersonate either of you in this conversation, ever.",
  reassurance: "these six words are derived from your shared key. if an attacker tried to sit in the middle, at least one word would be different. verification gets stronger with repetition.",
  youMeta: 'just now · keys created',
  peerMeta: 'arrived via nearby share',
  matchCta: 'they match',
  noMatchCta: "they don't match",
};

Object.assign(window, {
  SAS_YOU_WORDS, SAS_PEER_WORDS, SAS_PEER_MATCHED_WORDS,
  FingerprintGrid, FingerprintLabel, SAS_COPY,
});
