// Shared profile card — cross-surface profile summary.
// - ProfileCardContent renders the platform-agnostic interior.
// - openProfile(userId, anchorEl) / closeProfile() are window globals
//   that emit events; app shells subscribe via useProfileController().
// - Platform files render the wrapper chrome (desktop popover vs mobile sheet).

const PROFILE_COPY = {
  message:       'message',
  call:          'start call',
  whisper:       'whisper',
  copyFp:        'copy fingerprint',
  verify:        'verify in person',
  block:         'block',
  editProfile:   'edit profile',
  editNickname:  'set nickname',
  unverified:    'not yet verified — compare fingerprints before you trust this peer.',
  verified:      'verified peer',
  self:          'this is you',
  queuedPrefix:  'queued ·',
  whisperStatus: 'whispering',
  fingerprint:   'fingerprint',
  since:         'in the grove since',
  sharedGroves:  'you share',
  knownAs:       'you call them',
  pinned:        'pinned fragment',
  elsewhere:     'elsewhere',
};

const ROLE_LABEL = { steward: 'steward', member: 'member', guest: 'guest' };
const LAST_SEEN_BY_STATUS = {
  online:  'here, now',
  idle:    'here · away 12m',
  whisper: 'in a whisper',
  offline: 'last seen yesterday',
};
const STATUS_WORD = {
  online:  'online',
  idle:    'idle',
  whisper: 'whispering',
  offline: 'offline',
};

// ---- event bus ---------------------------------------------------------

const PROFILE_EVENT = '__willow_profile';

function openProfile(userId, anchorEl) {
  window.dispatchEvent(new CustomEvent(PROFILE_EVENT, {
    detail: { kind: 'open', userId, anchor: anchorEl ?? null },
  }));
}
function closeProfile() {
  window.dispatchEvent(new CustomEvent(PROFILE_EVENT, { detail: { kind: 'close' } }));
}

function useProfileController() {
  const [state, setState] = React.useState(null);
  React.useEffect(() => {
    const onEvt = (e) => {
      const d = e.detail;
      if (!d) return;
      if (d.kind === 'open') {
        const u = PEOPLE_BY_ID[d.userId];
        if (u) setState({ user: u, anchor: d.anchor });
      } else if (d.kind === 'close') {
        setState(null);
      }
    };
    const onKey = (e) => { if (e.key === 'Escape') setState(null); };
    window.addEventListener(PROFILE_EVENT, onEvt);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener(PROFILE_EVENT, onEvt);
      window.removeEventListener('keydown', onKey);
    };
  }, []);
  // Reference-stable return so downstream effects don't loop.
  return state;
}

// ---- personal crest (procedural SVG) ----------------------------------
// Each peer has a crestPattern + crestColor; we draw a subtle banner motif.
// The pattern is deterministic per user so the banner feels like *their* mark.

function ProfileCrest({ user, height = 72, width = 320 }) {
  const color = user?.crestColor || user?.avatar || 'var(--moss-2)';
  const pattern = user?.crestPattern || 'fronds';
  // Deterministic seed from user id → subtle per-user variation
  const seed = (user?.id || 'u0').split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const r = (i) => ((seed * 9301 + i * 49297) % 233280) / 233280;

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}
         preserveAspectRatio="none" style={{ display: 'block' }}>
      <defs>
        <linearGradient id={`crest-bg-${user.id}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0"   stopColor={color} stopOpacity="0.55"/>
          <stop offset="0.6" stopColor={color} stopOpacity="0.18"/>
          <stop offset="1"   stopColor={color} stopOpacity="0"/>
        </linearGradient>
        <linearGradient id={`crest-ink-${user.id}`} x1="0" x2="1">
          <stop offset="0" stopColor="#14130f" stopOpacity="0.0"/>
          <stop offset="0.5" stopColor="#14130f" stopOpacity="0.22"/>
          <stop offset="1" stopColor="#14130f" stopOpacity="0.0"/>
        </linearGradient>
      </defs>
      <rect width={width} height={height} fill={`url(#crest-bg-${user.id})`}/>

      {pattern === 'fronds' && (
        <g stroke={color} strokeOpacity="0.9" strokeWidth="1.1" fill="none" strokeLinecap="round">
          {Array.from({ length: 14 }).map((_, i) => {
            const x = 12 + i * 24 + Math.round(r(i) * 6);
            const len = 22 + Math.round(r(i + 5) * 18);
            const sway = Math.round((r(i + 11) - 0.5) * 10);
            return <path key={i} d={`M ${x} 6 q ${sway} ${len * 0.5} ${sway + 2} ${len}`} />;
          })}
          <path d={`M 0 ${height - 4} Q ${width / 2} ${height - 14} ${width} ${height - 2}`}
                stroke={color} strokeOpacity="0.35" fill="none"/>
        </g>
      )}

      {pattern === 'rings' && (
        <g stroke={color} strokeOpacity="0.8" fill="none">
          {Array.from({ length: 6 }).map((_, i) => {
            const cx = (i % 2 === 0 ? 40 : width - 40) + (r(i) - 0.5) * 10;
            const cy = 10 + (i * 11) % (height - 14);
            const rad = 8 + r(i + 2) * 14;
            return <circle key={i} cx={cx} cy={cy} r={rad} strokeWidth="1" strokeOpacity={0.25 + r(i + 9) * 0.5}/>;
          })}
          <circle cx={width / 2} cy={height / 2} r={height * 0.4} strokeWidth="1" strokeOpacity="0.15"/>
          <circle cx={width / 2} cy={height / 2} r={height * 0.25} strokeWidth="1" strokeOpacity="0.3"/>
        </g>
      )}

      {pattern === 'leaf' && (
        <g stroke={color} fill="none" strokeLinecap="round">
          <path d={`M 20 ${height - 8}
                    C ${width * 0.25} ${height - 40}, ${width * 0.55} ${height - 6}, ${width - 12} ${height - 28}`}
                strokeOpacity="0.75" strokeWidth="1.4"/>
          {Array.from({ length: 9 }).map((_, i) => {
            const t = i / 8;
            const x = 20 + t * (width - 40) + (r(i) - 0.5) * 8;
            const y = height - 10 - Math.sin(t * Math.PI) * 22 + (r(i + 3) - 0.5) * 6;
            const drop = 10 + r(i + 1) * 8;
            return <path key={i} d={`M ${x} ${y} q -2 ${drop * 0.6} 0 ${drop}`}
                         strokeOpacity="0.7" strokeWidth="1"/>;
          })}
          <path d={`M 12 10 q ${width / 2} 6 ${width - 24} 2`}
                strokeOpacity="0.18" strokeWidth="0.8"/>
        </g>
      )}

      <rect width={width} height={height} fill={`url(#crest-ink-${user.id})`}/>
    </svg>
  );
}

// ---- small bits --------------------------------------------------------

function StatusPill({ user }) {
  const c = {
    online:  'var(--moss-2)',
    idle:    'var(--warn)',
    whisper: 'var(--whisper)',
    offline: 'var(--ink-4)',
  }[user.status] ?? 'var(--ink-4)';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      fontSize: 11, color: 'var(--ink-2)',
    }}>
      <span style={{ width: 7, height: 7, borderRadius: '50%', background: c }}/>
      {STATUS_WORD[user.status] ?? 'offline'}
      {user.queued > 0 && (
        <>
          <span style={{ color: 'var(--ink-4)' }}>·</span>
          <span style={{ color: 'var(--warn)' }}>{PROFILE_COPY.queuedPrefix} {user.queued}</span>
        </>
      )}
    </span>
  );
}

function Chip({ children, onClick, accent }) {
  return (
    <span onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '3px 8px', borderRadius: 999,
      background: accent ? 'color-mix(in oklab, var(--moss-2) 14%, transparent)' : 'var(--bg-2)',
      color: accent ? 'var(--moss-3)' : 'var(--ink-2)',
      border: `1px solid ${accent ? 'color-mix(in oklab, var(--moss-2) 35%, transparent)' : 'var(--line)'}`,
      fontSize: 10.5, fontFamily: 'var(--font-ui)',
      cursor: onClick ? 'pointer' : 'default',
    }}>{children}</span>
  );
}

// Find groves this peer and you both belong to. In this prototype we don't
// have real membership data; we derive a stable pick from the user id so
// different peers show different overlaps — good enough for review.
function sharedGrovesFor(user) {
  if (user.self) return GROVES.slice(0, 2);
  const seed = user.id.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const pool = GROVES.slice(0, 4);
  return pool.filter((_, i) => (seed + i) % 3 !== 0).slice(0, 3);
}

// ---- platform-agnostic content ----------------------------------------

function ProfileCardContent({ user, platform = 'desktop', AvatarComponent, onAction, onClose }) {
  if (!user) return null;
  const isSelf = !!user.self;
  const isMobile = platform === 'mobile';
  const avSize = isMobile ? 84 : 64;
  const nameSize = isMobile ? 24 : 20;

  const actions = isSelf
    ? [{ id: 'editProfile', label: PROFILE_COPY.editProfile, icon: Icons.Settings, primary: true }]
    : [
        { id: 'message', label: PROFILE_COPY.message, icon: Icons.Inbox, primary: true },
        { id: 'call',    label: PROFILE_COPY.call,    icon: Icons.Phone },
        { id: 'whisper', label: PROFILE_COPY.whisper, icon: Icons.Ear   },
      ];

  const shared = sharedGrovesFor(user);
  const width = isMobile ? undefined : 320;

  return (
    <div style={{
      fontFamily: 'var(--font-ui)', color: 'var(--ink-1)',
      display: 'flex', flexDirection: 'column',
    }}>
      {/* --- personal crest banner --- */}
      <div style={{ position: 'relative', height: isMobile ? 92 : 72,
        borderTopLeftRadius: 'inherit', borderTopRightRadius: 'inherit',
        overflow: 'hidden', background: 'var(--bg-2)' }}>
        <ProfileCrest user={user} height={isMobile ? 92 : 72} width={isMobile ? 440 : 320}/>
        {!isMobile && onClose && (
          <button onClick={onClose} aria-label="close" style={{
            position: 'absolute', top: 8, right: 8,
            width: 26, height: 26, borderRadius: 8,
            background: 'color-mix(in oklab, var(--bg-0) 50%, transparent)',
            color: 'var(--ink-1)', backdropFilter: 'blur(6px)',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icons.X size={13} stroke={1.8}/>
          </button>
        )}
        {user.verified && (
          <span title={PROFILE_COPY.verified} style={{
            position: 'absolute', top: 10, left: 12,
            display: 'inline-flex', alignItems: 'center', gap: 5,
            padding: '3px 8px 3px 7px', borderRadius: 999,
            background: 'color-mix(in oklab, var(--bg-0) 60%, transparent)',
            color: 'var(--moss-3)', fontSize: 10.5, fontFamily: 'var(--font-mono)',
            letterSpacing: 0.3, backdropFilter: 'blur(6px)',
          }}>
            <Icons.Check size={10} stroke={2.4}/> verified
          </span>
        )}
        {!user.verified && !isSelf && (
          <span style={{
            position: 'absolute', top: 10, left: 12,
            display: 'inline-flex', alignItems: 'center', gap: 5,
            padding: '3px 8px 3px 7px', borderRadius: 999,
            background: 'color-mix(in oklab, var(--bg-0) 60%, transparent)',
            color: 'var(--warn)', fontSize: 10.5, fontFamily: 'var(--font-mono)',
            letterSpacing: 0.3, backdropFilter: 'blur(6px)',
          }}>
            <Icons.Shield size={10} stroke={1.8}/> unverified
          </span>
        )}
      </div>

      {/* --- avatar (overlapping) --- */}
      <div style={{
        padding: isMobile ? '0 18px' : '0 16px',
        marginTop: isMobile ? -avSize / 2 - 2 : -avSize / 2 - 2,
        display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 10,
      }}>
        <div style={{ position: 'relative', flexShrink: 0 }}>
          <span style={{
            display: 'inline-block', padding: 3, borderRadius: '50%',
            background: 'var(--bg-1)',
          }}>
            <AvatarComponent user={user} size={avSize} nonInteractive/>
          </span>
          <span style={{
            position: 'absolute', right: 4, bottom: 4,
            width: isMobile ? 16 : 13, height: isMobile ? 16 : 13, borderRadius: '50%',
            background: {
              online: 'var(--moss-2)', idle: 'var(--warn)',
              whisper: 'var(--whisper)', offline: 'var(--ink-4)',
            }[user.status] ?? 'var(--ink-4)',
            boxShadow: '0 0 0 3px var(--bg-1)',
          }}/>
        </div>
      </div>

      {/* --- identity block --- */}
      <div style={{
        padding: isMobile ? '10px 18px 0' : '8px 16px 0',
        display: 'flex', flexDirection: 'column', gap: 2,
      }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, flexWrap: 'wrap' }}>
          <span style={{
            fontFamily: 'var(--font-display)', fontStyle: 'italic',
            fontSize: nameSize, color: 'var(--ink-0)', lineHeight: 1.1,
          }}>{user.name}</span>
          {user.pronouns && (
            <span style={{
              fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--font-ui)',
              padding: '1px 7px', borderRadius: 999,
              border: '1px solid var(--line-soft)',
            }}>{user.pronouns}</span>
          )}
        </div>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: 12,
          color: 'var(--ink-3)', letterSpacing: 0.2,
        }}>
          {user.handle}
          {user.nickname && !isSelf && (
            <>
              <span style={{ margin: '0 6px', color: 'var(--ink-4)' }}>·</span>
              <span style={{ color: 'var(--moss-3)' }}>{PROFILE_COPY.knownAs} </span>
              <span style={{ color: 'var(--ink-2)' }}>{user.nickname}</span>
            </>
          )}
        </div>
        <div style={{ marginTop: 4 }}><StatusPill user={user}/></div>
      </div>

      {/* --- bio --- */}
      {user.bio && (
        <div style={{
          padding: isMobile ? '12px 18px 0' : '10px 16px 0',
          fontSize: isMobile ? 14.5 : 13,
          color: 'var(--ink-1)', lineHeight: 1.55,
          fontFamily: 'var(--font-serif, Georgia), serif',
          fontStyle: 'normal',
        }}>{user.bio}</div>
      )}
      {user.tagline && (
        <div style={{
          padding: isMobile ? '4px 18px 0' : '3px 16px 0',
          fontSize: 11.5, color: 'var(--ink-3)',
          fontFamily: 'var(--font-mono)', letterSpacing: 0.2,
        }}>· {user.tagline}</div>
      )}

      {/* --- pinned fragment --- */}
      {user.pinned && (
        <div style={{
          margin: isMobile ? '14px 18px 0' : '12px 16px 0',
          padding: isMobile ? '10px 14px' : '8px 12px',
          background: 'color-mix(in oklab, var(--bg-2) 70%, transparent)',
          borderLeft: `2px solid ${user.crestColor || 'var(--moss-2)'}`,
          borderRadius: 4,
        }}>
          <div style={{
            fontSize: 9.5, color: 'var(--ink-4)',
            textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: 3,
            fontFamily: 'var(--font-mono)',
          }}>{PROFILE_COPY.pinned}</div>
          <div style={{
            fontFamily: 'var(--font-display)', fontStyle: 'italic',
            fontSize: isMobile ? 15 : 13.5, color: 'var(--ink-1)', lineHeight: 1.45,
          }}>
            {user.pinned.kind === 'quote' ? `" ${user.pinned.body} "` : user.pinned.body}
          </div>
        </div>
      )}

      {/* --- shared groves --- */}
      {shared.length > 0 && !isSelf && (
        <div style={{ padding: isMobile ? '14px 18px 0' : '12px 16px 0' }}>
          <div style={{
            fontSize: 9.5, color: 'var(--ink-4)',
            textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: 6,
            fontFamily: 'var(--font-mono)',
          }}>{PROFILE_COPY.sharedGroves} · {shared.length} {shared.length === 1 ? 'grove' : 'groves'}</div>
          <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
            {shared.map(g => (
              <Chip key={g.id}>
                <span style={{
                  width: 12, height: 12, borderRadius: 3, background: g.accent,
                  color: '#14130f', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: 'var(--font-display)', fontSize: 9, fontWeight: 600, marginRight: 3,
                }}>{g.glyph}</span>
                {g.name.toLowerCase()}
              </Chip>
            ))}
          </div>
        </div>
      )}

      {/* --- elsewhere --- */}
      {user.elsewhere && user.elsewhere.length > 0 && (
        <div style={{ padding: isMobile ? '14px 18px 0' : '12px 16px 0' }}>
          <div style={{
            fontSize: 9.5, color: 'var(--ink-4)',
            textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: 6,
            fontFamily: 'var(--font-mono)',
          }}>{PROFILE_COPY.elsewhere}</div>
          <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
            {user.elsewhere.map((e, i) => (
              <Chip key={i}>{e.label}</Chip>
            ))}
          </div>
        </div>
      )}

      {/* --- meta: since + fingerprint (compact) --- */}
      <div style={{
        padding: isMobile ? '14px 18px 0' : '12px 16px 0',
        display: 'grid', gridTemplateColumns: 'auto 1fr',
        columnGap: 10, rowGap: 5, fontSize: 11, alignItems: 'center',
      }}>
        {user.since && (
          <>
            <span style={{ color: 'var(--ink-4)', textTransform: 'uppercase', letterSpacing: 0.8, fontSize: 9.5, fontFamily: 'var(--font-mono)' }}>
              since
            </span>
            <span style={{ color: 'var(--ink-2)' }}>{user.since}</span>
          </>
        )}
        <span style={{ color: 'var(--ink-4)', textTransform: 'uppercase', letterSpacing: 0.8, fontSize: 9.5, fontFamily: 'var(--font-mono)' }}>
          {PROFILE_COPY.fingerprint}
        </span>
        <span style={{
          fontFamily: 'var(--font-mono)', fontSize: 10.5,
          color: user.verified ? 'var(--moss-3)' : 'var(--warn)',
          letterSpacing: 0.2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }} title={user.fp}>{user.fp}</span>
      </div>

      {/* --- actions --- */}
      <div style={{
        padding: isMobile ? '16px 18px 4px' : '14px 16px 4px',
        display: 'flex', gap: isMobile ? 8 : 6,
        flexDirection: isMobile ? 'column' : 'row',
      }}>
        {actions.map(a => {
          const Ic = a.icon;
          const primary = a.primary;
          return (
            <button key={a.id} onClick={() => onAction?.(a.id, user)} style={{
              flex: 1,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              padding: isMobile ? '13px 14px' : '8px 10px',
              fontSize: isMobile ? 14 : 12.5,
              borderRadius: isMobile ? 12 : 8,
              background: primary ? 'var(--moss-2)' : 'var(--bg-2)',
              color: primary ? '#14130f' : 'var(--ink-0)',
              border: `1px solid ${primary ? 'var(--moss-2)' : 'var(--line)'}`,
              fontFamily: 'var(--font-ui)', fontWeight: primary ? 500 : 400,
              transition: 'filter 120ms, background 120ms',
            }}
            onMouseEnter={e => { e.currentTarget.style.filter = primary ? 'brightness(1.05)' : 'none';
                                 if (!primary) e.currentTarget.style.background = 'var(--bg-3)'; }}
            onMouseLeave={e => { e.currentTarget.style.filter = 'none';
                                 if (!primary) e.currentTarget.style.background = 'var(--bg-2)'; }}>
              <Ic size={isMobile ? 15 : 13} stroke={1.7}/>{a.label}
            </button>
          );
        })}
      </div>

      {/* --- secondary row --- */}
      {!isSelf ? (
        <div style={{
          display: 'flex', justifyContent: 'space-between',
          margin: isMobile ? '8px 18px 18px' : '6px 16px 12px',
          paddingTop: isMobile ? 10 : 8,
          borderTop: '1px solid var(--line-soft)',
          fontSize: 11.5,
        }}>
          <button onClick={() => onAction?.('copyFp', user)} style={{ color: 'var(--ink-2)', padding: '4px 0' }}>
            {PROFILE_COPY.copyFp}
          </button>
          <button onClick={() => onAction?.('nickname', user)} style={{ color: 'var(--ink-2)', padding: '4px 0' }}>
            {user.nickname ? 'change nickname' : PROFILE_COPY.editNickname}
          </button>
          <button onClick={() => onAction?.('block', user)} style={{ color: 'var(--err)', padding: '4px 0' }}>
            {PROFILE_COPY.block}
          </button>
        </div>
      ) : (
        <div style={{
          margin: isMobile ? '8px 18px 18px' : '6px 16px 12px',
          paddingTop: isMobile ? 10 : 8,
          borderTop: '1px solid var(--line-soft)',
          fontSize: 10.5, color: 'var(--ink-3)', fontStyle: 'italic', textAlign: 'center',
        }}>
          {PROFILE_COPY.self} · {user.fp.split('-').slice(0, 3).join(' · ')}
        </div>
      )}
    </div>
  );
}

Object.assign(window, {
  PROFILE_COPY, ROLE_LABEL, LAST_SEEN_BY_STATUS, STATUS_WORD,
  openProfile, closeProfile, useProfileController,
  ProfileCardContent, ProfileCrest,
});
