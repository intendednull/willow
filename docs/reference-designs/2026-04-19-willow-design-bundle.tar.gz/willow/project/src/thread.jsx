// Thread side panel — opens on the right over the members list.

const ThreadPane = ({ onClose, parentMessage }) => {
  const parent = parentMessage ?? MESSAGES.find(m => m.id === 'm5');
  const u = parent ? PEOPLE_BY_ID[parent.from] : null;
  return (
    <aside style={{
      width: 360, background: 'var(--bg-1)', borderLeft: '1px solid var(--line-soft)',
      display: 'flex', flexDirection: 'column', height: '100%',
    }}>
      <div style={{ padding: '12px 14px', borderBottom: '1px solid var(--line-soft)',
        display: 'flex', alignItems: 'center', gap: 8 }}>
        <Icons.Thread size={14}/>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 14, color: 'var(--ink-0)' }}>
            thread
          </div>
          <div style={{ fontSize: 11, color: 'var(--ink-3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {THREAD_COPY.fromLabel('meander', THREAD_MESSAGES.length)}
          </div>
        </div>
        <IconBtn icon={Icons.X} label="close" onClick={onClose} size={28}/>
      </div>
      <div className="scroll" style={{ flex: 1, padding: '10px 0' }}>
        <ThreadParentCard parent={parent} AvatarComponent={Avatar} size="md"/>
        <ThreadReplyList replies={THREAD_MESSAGES} AvatarComponent={Avatar} size="md"/>
      </div>
      <div style={{ padding: '0 12px 12px' }}>
        <div style={{
          background: 'var(--bg-2)', borderRadius: 10, border: '1px solid var(--line)',
          padding: '8px 10px', display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <Icons.Thread size={13}/>
          <input placeholder={THREAD_COPY.composePlaceholder} style={{
            flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 13, color: 'var(--ink-0)',
          }}/>
          <Icons.Send size={13} stroke={1.8}/>
        </div>
        <div style={{ fontSize: 10.5, color: 'var(--ink-3)', marginTop: 6, textAlign: 'center' }}>
          <Icons.Lock size={9} stroke={1.6}/> {THREAD_COPY.sealedFooter(5)}
        </div>
      </div>
    </aside>
  );
};

window.ThreadPane = ThreadPane;
