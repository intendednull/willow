// Governance view — proposals + votes to grant roles, rotate keys, change settings.
// Modeled on willow's event-sourced ProposeAction / VoteOnProposal events.

const PROPOSALS = [
  {
    id: 'p1',
    kind: 'grant-role',
    title: 'grant perrin the "moderator" role',
    by: 'u1',
    at: '2h ago',
    body: 'perrin has been stewarding #reading-room for a month. motion to give them ManageChannels + ManageMessages so they can pin/archive without asking.',
    action: { role: 'moderator', perms: ['ManageChannels', 'ManageMessages'], target: 'u6' },
    quorum: { needed: 4, yes: 3, no: 0, abstain: 1, total: 8 },
    voters: [
      { id: 'u1', vote: 'yes', at: '2h' },
      { id: 'u4', vote: 'yes', at: '1h' },
      { id: 'u8', vote: 'yes', at: '42m' },
      { id: 'u2', vote: 'abstain', at: '18m' },
    ],
    status: 'open',
    closesIn: '22h',
  },
  {
    id: 'p2',
    kind: 'rotate-keys',
    title: 'rotate grove-keys for #meander',
    by: 'u1',
    at: '1d ago',
    body: 'monthly rotation. nico has been offline — their key will be re-sealed once they reconnect.',
    action: { channel: 'c2', keyEpoch: 14 },
    quorum: { needed: 5, yes: 7, no: 0, abstain: 0, total: 8 },
    voters: [],
    status: 'passed',
    closedAt: '6h ago',
  },
  {
    id: 'p3',
    kind: 'create-channel',
    title: 'new channel: #saturday-saw',
    by: 'u2',
    at: '4h ago',
    body: 'ephemeral, expires in 3 days, private to the crew that signed up for the limb-clearing.',
    action: { name: 'saturday-saw', kind: 'ephemeral', expires: '3d', holders: ['u1','u2','u4','u6','u9'] },
    quorum: { needed: 3, yes: 2, no: 1, abstain: 0, total: 5 },
    voters: [],
    status: 'open',
    closesIn: '14h',
  },
  {
    id: 'p4',
    kind: 'revoke-device',
    title: 'revoke kestrel\'s willow·laptop',
    by: 'u4',
    at: 'yesterday',
    body: 'i lost it on the train. re-joining from phone. this revocation wipes its sub-key from all peers.',
    action: { device: 'willow·laptop', peer: 'u4' },
    quorum: { needed: 1, yes: 1, no: 0, abstain: 0, total: 1 },
    voters: [],
    status: 'passed',
    closedAt: '20h ago',
    note: 'self-proposal · auto-passed',
  },
];

const kindMeta = {
  'grant-role':    { icon: Icons.Shield,     color: 'var(--moss-3)',  label: 'role grant' },
  'rotate-keys':   { icon: Icons.Key,        color: 'var(--willow)',  label: 'key rotation' },
  'create-channel':{ icon: Icons.Plus,       color: 'var(--amber)',   label: 'new channel' },
  'revoke-device': { icon: Icons.Device,     color: 'var(--err)',     label: 'revoke device' },
};

const VoteBar = ({ q }) => {
  const yesPct = (q.yes / q.total) * 100;
  const noPct  = (q.no / q.total) * 100;
  const absPct = (q.abstain / q.total) * 100;
  const quoPct = (q.needed / q.total) * 100;
  return (
    <div style={{ position: 'relative', height: 8, borderRadius: 4, background: 'var(--bg-2)', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 0, bottom: 0, left: 0, width: `${yesPct}%`, background: 'var(--moss-2)' }}/>
      <div style={{ position: 'absolute', top: 0, bottom: 0, left: `${yesPct}%`, width: `${absPct}%`, background: 'var(--ink-4)' }}/>
      <div style={{ position: 'absolute', top: 0, bottom: 0, left: `${yesPct+absPct}%`, width: `${noPct}%`, background: 'var(--err)' }}/>
      <div style={{ position: 'absolute', top: -2, bottom: -2, left: `${quoPct}%`, width: 2,
        background: 'var(--ink-0)', boxShadow: '0 0 0 1px var(--bg-1)' }} title={`quorum: ${q.needed}/${q.total}`}/>
    </div>
  );
};

const ProposalCard = ({ p }) => {
  const meta = kindMeta[p.kind];
  const I = meta.icon;
  const passed = p.status === 'passed';
  return (
    <div style={{
      background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 14,
      padding: 18, marginBottom: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
        <div style={{
          width: 36, height: 36, borderRadius: 10, background: 'var(--bg-2)',
          border: '1px solid var(--line)', color: meta.color,
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}>
          <I size={16} stroke={1.6}/>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', rowGap: 8 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 17, color: 'var(--ink-0)', flex: '1 1 auto', minWidth: 200 }}>
              {p.title}
            </span>
            <div style={{ display: 'inline-flex', gap: 6, flexShrink: 0 }}>
              <Tag mono color={meta.color} border="var(--line)">{meta.label}</Tag>
              {passed
                ? <Tag mono color="var(--moss-3)" border="var(--line)"><Icons.Check size={10}/>passed</Tag>
                : <Tag mono color="var(--amber)" border="var(--amber-soft)"><Icons.Hourglass size={10}/>{p.closesIn}</Tag>}
            </div>
          </div>
          <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginTop: 4, display: 'flex', alignItems: 'center', gap: 6 }}>
            <Avatar user={PEOPLE_BY_ID[p.by]} size={16}/>
            <span>{PEOPLE_BY_ID[p.by].name}</span>
            <span style={{ color: 'var(--ink-4)' }}>·</span>
            <span>{p.at}</span>
            {p.note && <><span style={{ color: 'var(--ink-4)' }}>·</span><span style={{ fontStyle: 'italic' }}>{p.note}</span></>}
          </div>
          <div style={{ fontSize: 13.5, color: 'var(--ink-1)', marginTop: 10, lineHeight: 1.55 }}>
            {p.body}
          </div>

          <div style={{ marginTop: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--moss-3)' }}>yes {p.quorum.yes}</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--err)' }}>no {p.quorum.no}</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-3)' }}>abstain {p.quorum.abstain}</span>
              <span style={{ flex: 1 }}/>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-2)' }}>
                quorum {p.quorum.needed}/{p.quorum.total}
              </span>
            </div>
            <VoteBar q={p.quorum}/>
          </div>

          {p.voters.length > 0 && (
            <div style={{ marginTop: 12, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {p.voters.map(v => {
                const u = PEOPLE_BY_ID[v.id];
                const color = v.vote === 'yes' ? 'var(--moss-3)' : v.vote === 'no' ? 'var(--err)' : 'var(--ink-3)';
                return (
                  <span key={v.id} style={{
                    display: 'inline-flex', alignItems: 'center', gap: 6,
                    padding: '3px 8px 3px 3px', borderRadius: 999,
                    background: 'var(--bg-2)', border: '1px solid var(--line)', fontSize: 11,
                  }}>
                    <Avatar user={u} size={18}/>
                    <span style={{ color: 'var(--ink-1)' }}>{u.name}</span>
                    <span style={{ color, fontFamily: 'var(--font-mono)' }}>{v.vote}</span>
                  </span>
                );
              })}
            </div>
          )}

          {!passed && (
            <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
              <button style={{ padding: '7px 12px', borderRadius: 8, background: 'var(--moss-1)', color: 'var(--moss-4)',
                fontSize: 12, fontWeight: 500, display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <Icons.Check size={12} stroke={2.2}/>vote yes
              </button>
              <button style={{ padding: '7px 12px', borderRadius: 8, background: 'var(--bg-2)', border: '1px solid var(--line)',
                color: 'var(--ink-2)', fontSize: 12 }}>
                vote no
              </button>
              <button style={{ padding: '7px 12px', borderRadius: 8, background: 'transparent', border: '1px solid var(--line)',
                color: 'var(--ink-3)', fontSize: 12 }}>
                abstain
              </button>
              <span style={{ flex: 1 }}/>
              <button style={{ padding: '7px 12px', borderRadius: 8, background: 'transparent',
                color: 'var(--ink-3)', fontSize: 12, display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <Icons.Thread size={12}/>discuss
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const GovernanceView = () => (
  <div style={{ flex: 1, background: 'var(--bg-1)', display: 'flex', flexDirection: 'column', minWidth: 0 }}>
    <div style={{ padding: '22px 32px 14px', borderBottom: '1px solid var(--line-soft)',
      background: 'linear-gradient(180deg, rgba(106,141,94,0.05), transparent)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <Icons.Shield size={18}/>
        <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 24, color: 'var(--ink-0)' }}>
          governance
        </div>
        <span style={{ flex: 1 }}/>
        <Tag mono color="var(--moss-3)" border="var(--line)"><Icons.Users size={10}/>quiet grove · 8 voting peers</Tag>
        <button style={{ padding: '7px 12px', borderRadius: 8, background: 'var(--moss-2)', color: '#14130f',
          fontSize: 12, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 6 }}>
          <Icons.Plus size={12} stroke={2.2}/>propose
        </button>
      </div>
      <div style={{ fontSize: 12.5, color: 'var(--ink-2)', marginTop: 6, maxWidth: 680, lineHeight: 1.55 }}>
        every change to a grove — granting a role, rotating keys, creating a channel, revoking a device —
        is an event proposed by someone and voted on by peers. no single admin. outcomes are signed by the grove and replayed by every member.
      </div>
    </div>
    <div className="scroll" style={{ flex: 1, padding: '16px 32px 32px' }}>
      <div style={{ fontSize: 11, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.4, marginBottom: 10 }}>
        open
      </div>
      {PROPOSALS.filter(p => p.status === 'open').map(p => <ProposalCard key={p.id} p={p}/>)}
      <div style={{ fontSize: 11, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.4, margin: '20px 0 10px' }}>
        recently closed
      </div>
      {PROPOSALS.filter(p => p.status === 'passed').map(p => <ProposalCard key={p.id} p={p}/>)}
    </div>
  </div>
);

window.GovernanceView = GovernanceView;
