// Willow icons — thin line, 1.5px stroke, rounded caps, 24x24 viewBox.
// Drawn custom for this prototype; no icon library.

const Ic = ({ children, size = 16, stroke = 1.5, ...rest }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
       {...rest}>
    {children}
  </svg>
);

const Icons = {
  Hash:    (p) => <Ic {...p}><path d="M4 9h16M4 15h16M10 4l-2 16M16 4l-2 16"/></Ic>,
  Mic:     (p) => <Ic {...p}><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M8 21h8"/></Ic>,
  MicOff:  (p) => <Ic {...p}><path d="M3 3l18 18"/><path d="M9 9v2a3 3 0 0 0 5.12 2.12M15 11V6a3 3 0 0 0-6-.58"/><path d="M5 11a7 7 0 0 0 10.6 6M19 11a7 7 0 0 1-.34 2.14M12 18v3M8 21h8"/></Ic>,
  Cam:     (p) => <Ic {...p}><rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3"/></Ic>,
  CamOff:  (p) => <Ic {...p}><path d="M3 3l18 18"/><path d="M3 6v12a0 0 0 0 0 0 0h13v-3M16 10l5-3v10l-5-3"/></Ic>,
  Screen:  (p) => <Ic {...p}><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4M9 10l3-3 3 3M12 7v5"/></Ic>,
  Headset: (p) => <Ic {...p}><path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="13" width="4" height="7" rx="1.5"/><rect x="17" y="13" width="4" height="7" rx="1.5"/><path d="M20 19a3 3 0 0 1-3 3h-3"/></Ic>,
  Leaf:    (p) => <Ic {...p}><path d="M20 4s-10 0-14 4-3 12-3 12 8 1 12-3 5-13 5-13ZM3 20l10-10"/></Ic>,
  Lock:    (p) => <Ic {...p}><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></Ic>,
  Key:     (p) => <Ic {...p}><circle cx="8" cy="14" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l3 3"/></Ic>,
  Shield:  (p) => <Ic {...p}><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3Z"/></Ic>,
  Check:   (p) => <Ic {...p}><path d="M4 12l5 5 11-12"/></Ic>,
  X:       (p) => <Ic {...p}><path d="M5 5l14 14M19 5L5 19"/></Ic>,
  Plus:    (p) => <Ic {...p}><path d="M12 5v14M5 12h14"/></Ic>,
  Search:  (p) => <Ic {...p}><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></Ic>,
  Settings:(p) => <Ic {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.02a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.02a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/></Ic>,
  Hourglass:(p)=> <Ic {...p}><path d="M6 3h12M6 21h12M7 3v3a5 5 0 0 0 10 0V3M7 21v-3a5 5 0 0 1 10 0v3"/></Ic>,
  Link:    (p) => <Ic {...p}><path d="M10 14a4 4 0 0 0 6 0l3-3a4 4 0 1 0-5.6-5.6L12 7M14 10a4 4 0 0 0-6 0l-3 3a4 4 0 1 0 5.6 5.6L12 17"/></Ic>,
  Signal:  (p) => <Ic {...p}><path d="M2 20h2M7 17v3M12 13v7M17 9v11M22 5v15"/></Ic>,
  Bell:    (p) => <Ic {...p}><path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8ZM10 21a2 2 0 0 0 4 0"/></Ic>,
  Thread:  (p) => <Ic {...p}><path d="M4 7h10a4 4 0 0 1 0 8H7l-3 3v-14"/></Ic>,
  Pin:     (p) => <Ic {...p}><path d="M12 3l5 5-2 2 1 5-5-3-5 5v-5l5-1-2-2 3-6Z"/></Ic>,
  Send:    (p) => <Ic {...p}><path d="M4 12l16-8-6 18-3-7-7-3Z"/></Ic>,
  Smile:   (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01"/></Ic>,
  Paperclip:(p)=> <Ic {...p}><path d="M21 12l-8.5 8.5a5 5 0 0 1-7-7L14 5a3 3 0 0 1 4 4l-8.5 8.5a1 1 0 0 1-1.5-1.5L16 8"/></Ic>,
  Gift:    (p) => <Ic {...p}><rect x="3" y="9" width="18" height="11" rx="1"/><path d="M3 13h18M12 9v11M12 9S8 9 8 6a2 2 0 0 1 4-1c0 0 0 4 0 4ZM12 9s4 0 4-3a2 2 0 0 0-4-1"/></Ic>,
  Chevron: (p) => <Ic {...p}><path d="M9 6l6 6-6 6"/></Ic>,
  ChevronDown:(p)=> <Ic {...p}><path d="M6 9l6 6 6-6"/></Ic>,
  Compass: (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><path d="M15 9l-1.5 4.5L9 15l1.5-4.5L15 9Z"/></Ic>,
  Inbox:   (p) => <Ic {...p}><path d="M22 13h-6l-2 3h-4l-2-3H2M5 4h14l3 9v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6l3-9Z"/></Ic>,
  Dot:     (p) => <svg width="6" height="6" viewBox="0 0 6 6" {...p}><circle cx="3" cy="3" r="3" fill="currentColor"/></svg>,
  Spark:   (p) => <Ic {...p}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/></Ic>,
  Phone:   (p) => <Ic {...p}><path d="M5 3h3l2 5-2 1a12 12 0 0 0 7 7l1-2 5 2v3a2 2 0 0 1-2 2A17 17 0 0 1 3 5a2 2 0 0 1 2-2Z"/></Ic>,
  PhoneDown:(p)=> <Ic {...p}><path d="M2 14a15 15 0 0 1 20 0l-2 3-4-1v-3a10 10 0 0 0-8 0v3l-4 1-2-3Z"/></Ic>,
  User:    (p) => <Ic {...p}><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></Ic>,
  Users:   (p) => <Ic {...p}><circle cx="9" cy="8" r="3.5"/><path d="M2 20a7 7 0 0 1 14 0"/><path d="M16 4a3.5 3.5 0 0 1 0 7M22 20a6 6 0 0 0-5-6"/></Ic>,
  Device:  (p) => <Ic {...p}><rect x="3" y="4" width="11" height="16" rx="2"/><rect x="15" y="8" width="6" height="12" rx="1.5"/></Ic>,
  Wifi:    (p) => <Ic {...p}><path d="M2 8a15 15 0 0 1 20 0M5 12a10 10 0 0 1 14 0M8 16a5 5 0 0 1 8 0M12 20h.01"/></Ic>,
  Ghost:   (p) => <Ic {...p}><path d="M5 10a7 7 0 0 1 14 0v10l-2-2-2 2-2-2-2 2-2-2-2 2-2-2V10ZM9 10h.01M15 10h.01"/></Ic>,
  Ear:     (p) => <Ic {...p}><path d="M6 10a6 6 0 1 1 12 0c0 3-3 4-4 6s-1 4-3 4a3 3 0 0 1-3-3"/></Ic>,
  Mute:    (p) => <Ic {...p}><path d="M11 5L6 9H3v6h3l5 4V5Z"/><path d="M15 9l6 6M21 9l-6 6"/></Ic>,
  Volume:  (p) => <Ic {...p}><path d="M11 5L6 9H3v6h3l5 4V5ZM16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/></Ic>,
  Globe:   (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></Ic>,
  Fingerprint:(p)=> <Ic {...p}><path d="M6 11a6 6 0 0 1 12 0v1a9 9 0 0 1-.5 3M9 20c-1-2-1-4-1-6M15 20a15 15 0 0 0 1-5M12 5v0M12 13a3 3 0 0 1 3 3c0 1 0 2-1 4"/></Ic>,
  Dashboard:(p)=> <Ic {...p}><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></Ic>,
  Tree:    (p) => <Ic {...p}><path d="M12 3c-2 3-5 4-5 8a5 5 0 0 0 10 0c0-4-3-5-5-8ZM12 16v5M9 21h6"/></Ic>,
  Arrow:   (p) => <Ic {...p}><path d="M5 12h14M13 6l6 6-6 6"/></Ic>,
  More:    (p) => <Ic {...p}><circle cx="6" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="18" cy="12" r="1.5"/></Ic>,
  Grid:    (p) => <Ic {...p}><rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="8" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/></Ic>,
  Spotlight:(p)=> <Ic {...p}><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></Ic>,
};

window.Icons = Icons;
window.Ic = Ic;
