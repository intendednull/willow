// Tweaks panel — keyboard-accessible, persists via __edit_mode_set_keys.

const TweakRow = ({ label, children }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0',
    borderBottom: '1px solid var(--line-soft)' }}>
    <div style={{ flex: 1, fontSize: 12, color: 'var(--ink-1)' }}>{label}</div>
    <div>{children}</div>
  </div>
);

const Choice = ({ options, value, onChange }) => (
  <div style={{ display: 'inline-flex', background: 'var(--bg-2)', border: '1px solid var(--line)', borderRadius: 8, padding: 2 }}>
    {options.map(o => (
      <button key={o.value} onClick={() => onChange(o.value)} style={{
        padding: '4px 10px', borderRadius: 6, fontSize: 11,
        background: value === o.value ? 'var(--bg-3)' : 'transparent',
        color: value === o.value ? 'var(--ink-0)' : 'var(--ink-3)',
        fontFamily: 'var(--font-mono)',
      }}>{o.label}</button>
    ))}
  </div>
);

const TweaksPanel = ({ open, tweaks, setTweak }) => {
  if (!open) return null;
  return (
    <div style={{
      position: 'fixed', right: 16, bottom: 16, width: 320, zIndex: 100,
      background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 14,
      boxShadow: 'var(--shadow-2)', padding: 14,
      fontFamily: 'var(--font-ui)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
        <Icons.Spark size={14} stroke={1.6}/>
        <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 15, color: 'var(--ink-0)' }}>tweaks</span>
        <span style={{ flex: 1 }}/>
        <span style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)' }}>willow</span>
      </div>
      <div style={{ fontSize: 11, color: 'var(--ink-3)', marginBottom: 8 }}>
        live-edit the prototype. toggle tweaks from the toolbar.
      </div>
      <TweakRow label="accent">
        <Choice value={tweaks.accent} onChange={v => setTweak('accent', v)} options={[
          { value: 'moss', label: 'moss' },
          { value: 'willow', label: 'willow' },
          { value: 'amber', label: 'amber' },
          { value: 'dusk', label: 'dusk' },
        ]}/>
      </TweakRow>
      <TweakRow label="density">
        <Choice value={tweaks.density} onChange={v => setTweak('density', v)} options={[
          { value: 'cozy', label: 'cozy' },
          { value: 'balanced', label: 'balanced' },
          { value: 'dense', label: 'dense' },
        ]}/>
      </TweakRow>
      <TweakRow label="call layout">
        <Choice value={tweaks.callLayout} onChange={v => setTweak('callLayout', v)} options={[
          { value: 'grove', label: 'grove' },
          { value: 'grid', label: 'grid' },
          { value: 'spotlight', label: 'spot' },
        ]}/>
      </TweakRow>
      <TweakRow label="sidebar">
        <Choice value={tweaks.sidebarVariant} onChange={v => setTweak('sidebarVariant', v)} options={[
          { value: 'stems', label: 'stems' },
          { value: 'bark', label: 'bark' },
        ]}/>
      </TweakRow>
      <TweakRow label="crypto visibility">
        <Choice value={tweaks.cryptoVisibility} onChange={v => setTweak('cryptoVisibility', v)} options={[
          { value: 'invisible', label: 'none' },
          { value: 'subtle', label: 'subtle' },
          { value: 'prominent', label: 'loud' },
        ]}/>
      </TweakRow>
      <TweakRow label="wordmark in corner">
        <Choice value={tweaks.showWordmark ? 'on' : 'off'} onChange={v => setTweak('showWordmark', v === 'on')} options={[
          { value: 'on', label: 'on' },
          { value: 'off', label: 'off' },
        ]}/>
      </TweakRow>
    </div>
  );
};

window.TweaksPanel = TweaksPanel;
