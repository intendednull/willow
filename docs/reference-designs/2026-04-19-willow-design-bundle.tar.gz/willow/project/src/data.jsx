// Fake data for the Willow prototype.
// Originals; names are grove/forest-themed to stay on-brand.

const PEERS = [
  { id: 'u1', handle: 'mira.sage',     name: 'Mira',    avatar: '#8aa079', status: 'online',  fp: 'willow-ember-brook-nine-otter-pine', verified: true,  role: 'steward',
    pronouns: 'she/her',  since: 'spring · yr 2',
    bio: "mending rooms, keeping fires. tea at 4.",
    tagline: 'slow correspondence',
    crestPattern: 'fronds',    crestColor: '#8aa079',
    elsewhere: [{ label: 'coast · west' }, { label: 'studio: the long room' }],
    pinned: { kind: 'quote', body: 'the wind through the willows' },
  },
  { id: 'u2', handle: 'ori.birch',     name: 'Ori',     avatar: '#a88fc9', status: 'online',  fp: 'cedar-moss-delta-rune-lamp-harbor',  verified: true,  role: 'member',
    pronouns: 'they/them', since: 'summer · yr 2', nickname: 'ori·b',
    bio: "field recordings, unfinished letters.",
    tagline: 'the big saw',
    crestPattern: 'rings',     crestColor: '#a88fc9',
    elsewhere: [{ label: 'on the road' }],
    pinned: { kind: 'fragment', body: "drag the limb into saturday" },
  },
  { id: 'u3', handle: 'juno.fern',     name: 'Juno',    avatar: '#c99b55', status: 'whisper', fp: 'slate-heron-mint-radar-olive-snow',  verified: false, role: 'member',
    pronouns: 'she/they', since: 'autumn · yr 2',
    bio: "listening more than speaking these days.",
    tagline: 'in the side-channel',
    crestPattern: 'leaf',      crestColor: '#c99b55',
    elsewhere: [],
    pinned: null,
  },
  { id: 'u4', handle: 'kestrel',       name: 'Kes',     avatar: '#6a8d5e', status: 'online',  fp: 'loom-amber-river-quiet-knot-birch',  verified: true,  role: 'member',
    pronouns: 'he/him',   since: 'winter · yr 1', nickname: 'kestrel',
    bio: "carpentry, cartography, light fiction.",
    tagline: 'back saturday morning',
    crestPattern: 'fronds',    crestColor: '#6a8d5e',
    elsewhere: [{ label: 'shed · north field' }],
    pinned: { kind: 'quote', body: 'a map is a kind of letter' },
  },
  { id: 'u5', handle: 'nico.ash',      name: 'Nico',    avatar: '#d6a54a', status: 'offline', fp: 'plume-thorn-gable-quartz-hum-dawn',  verified: false, role: 'member',  queued: 3,
    pronouns: 'he/him',   since: 'spring · yr 3',
    bio: "offline more often than not. i'll find you.",
    tagline: 'queued, patient',
    crestPattern: 'rings',     crestColor: '#d6a54a',
    elsewhere: [{ label: 'inland · no signal' }],
    pinned: null,
  },
  { id: 'u6', handle: 'perrin.willow', name: 'Perrin',  avatar: '#93b582', status: 'online',  fp: 'marsh-ivory-kite-opal-foxglove-tide', verified: true, role: 'member',
    pronouns: 'she/her',  since: 'summer · yr 1', nickname: 'per',
    bio: "coffee crew. bringing coffee.",
    tagline: 'small fires, strong brew',
    crestPattern: 'leaf',      crestColor: '#93b582',
    elsewhere: [{ label: 'kitchen · always' }],
    pinned: { kind: 'fragment', body: 'bringing coffee' },
  },
  { id: 'u7', handle: 'tam.hazel',     name: 'Tam',     avatar: '#c97a5a', status: 'idle',    fp: 'heather-clay-vale-bramble-sun-nest', verified: false, role: 'member',
    pronouns: 'they/he',  since: 'autumn · yr 3',
    bio: "new to this grove. still finding my pace.",
    tagline: 'compare our fingerprints?',
    crestPattern: 'rings',     crestColor: '#c97a5a',
    elsewhere: [],
    pinned: null,
  },
  { id: 'u8', handle: 'wren.sorrel',   name: 'Wren',    avatar: '#a8a290', status: 'online',  fp: 'thistle-pond-lark-beryl-dusk-stem',  verified: true,  role: 'member',
    pronouns: 'she/her',  since: 'winter · yr 2',
    bio: "reader, editor, occasional sender of long letters.",
    tagline: 'one hour, then notes',
    crestPattern: 'fronds',    crestColor: '#a8a290',
    elsewhere: [{ label: 'library · upstairs' }],
    pinned: { kind: 'quote', body: 'attention is the rarest form of generosity' },
  },
  { id: 'u9', handle: 'you',           name: 'You',     avatar: '#b8c67a', status: 'online',  fp: 'willow-copper-reed-glade-slate-moth', verified: true, role: 'member',  self: true,
    pronouns: 'she/her',  since: 'winter · yr 1',
    bio: "keeping a small grove. letters welcome.",
    tagline: 'tap to edit',
    crestPattern: 'leaf',      crestColor: '#b8c67a',
    elsewhere: [{ label: 'home · willow desk' }],
    pinned: { kind: 'quote', body: 'a grove is made of listening' },
  },
];

const GROVES = [ // "servers"
  { id: 'g1', name: 'Quiet Grove',       glyph: 'q', accent: '#6a8d5e', members: 42,  desc: 'Small circle of writers + readers.' },
  { id: 'g2', name: 'Long Table',        glyph: 'L', accent: '#c99b55', members: 118, desc: 'Dinner club + recipe swap.' },
  { id: 'g3', name: 'Fieldnotes',        glyph: 'F', accent: '#a88fc9', members: 23,  desc: 'Research lab, field reports.' },
  { id: 'g4', name: 'Drift Radio',       glyph: '∿', accent: '#d6a54a', members: 67,  desc: 'Music listening parties, live DJs.' },
  { id: 'g5', name: 'North Wind',        glyph: 'N', accent: '#93b582', members: 9,   desc: 'Private — immediate family only.' },
];

const CHANNEL_GROUPS = {
  g1: [
    { label: 'commons', channels: [
      { id: 'c1', name: 'welcome',      kind: 'text',   unread: 0, topic: 'say hi · share your fingerprint' },
      { id: 'c2', name: 'meander',      kind: 'text',   unread: 12, topic: 'general chatter' , current: true },
      { id: 'c3', name: 'reading-room', kind: 'text',   unread: 3 },
      { id: 'c4', name: 'links',        kind: 'text',   unread: 0 },
    ]},
    { label: 'voice', channels: [
      { id: 'v1', name: 'the-porch',    kind: 'voice', active: 4 },
      { id: 'v2', name: 'deep-work',    kind: 'voice', active: 0 },
    ]},
    { label: 'ephemeral', channels: [
      { id: 'e1', name: 'night-session', kind: 'ephemeral', expires: '2h 14m', unread: 2 },
      { id: 'e2', name: 'bookclub-vi',   kind: 'ephemeral', expires: '5d',     unread: 0 },
    ]},
    { label: 'archives', channels: [
      { id: 'a1', name: 'old-letters', kind: 'text', muted: true },
    ]},
  ],
};

const MESSAGES = [
  { id: 'm1',  from: 'u1', t: '10:02', body: "morning grove ☀️  storm finally passed" },
  { id: 'm2',  from: 'u1', t: '10:02', body: "the willow behind the studio lost a limb, nothing serious" , img: true },
  { id: 'm3',  from: 'u4', t: '10:08', body: "we had it too. woke up to leaves everywhere" },
  { id: 'm4',  from: 'u2', t: '10:11', body: "@mira — was that the big one near the shed? i always liked that limb", mentions: ['u1'] },
  { id: 'm5',  from: 'u1', t: '10:12', body: "yeah, that one. i'll drag it into tomorrow's meander" , thread: { count: 7, lastAt: '10:41', participants: ['u2','u4','u6'] } },
  { id: 'sep', kind: 'sep', label: 'today' },
  { id: 'm6',  from: 'u6', t: '09:14', body: "i'm pushing the draft of the reading list, would love two pairs of eyes", reactions: [['🍃',3],['👀',2]] },
  { id: 'm7',  from: 'u8', t: '09:16', body: "on it. give me an hour" },
  { id: 'm8',  from: 'u3', t: '09:22', body: "whispering with ori about something — loop back in 10", whisper: true },
  { id: 'm9',  from: 'u4', t: '09:31', body: "quick q: did anyone else get the sync error overnight? mine retried twice then settled", code: "peer://mira.sage#0a41  retry(2)  ok  rtt=184ms" },
  { id: 'm10', from: 'u1', t: '09:40', body: "yeah, relay-2 was flaky. we're on relay-3 now. fingerprints still match, all good" },
  { id: 'm10b',from: 'u6', t: '09:43', body: "@you do you want me to bring the spare keys for the shed too? they're in your old satchel", mentions: ['u9'] },
  { id: 'm11', from: 'u2', t: '09:55', body: "pinning this so we remember next time →", pin: true },
  { id: 'm12', from: 'u9', t: '10:03', body: "catching up now — was offline last night. willow queued 14 msgs, everything arrived", queueNote: true },
];

const THREAD_MESSAGES = [
  { id: 't1', from: 'u1', t: '10:12', body: "yeah, that one. i'll drag it into tomorrow's meander" },
  { id: 't2', from: 'u2', t: '10:13', body: "do you want help? i can bring the big saw" },
  { id: 't3', from: 'u1', t: '10:15', body: "that would be lovely. maybe saturday morning?" },
  { id: 't4', from: 'u4', t: '10:20', body: "i'll tag along. haven't seen the shed since spring" },
  { id: 't5', from: 'u6', t: '10:29', body: "bringing coffee" },
  { id: 't6', from: 'u2', t: '10:38', body: "i'll start a ride-share thread for it" },
  { id: 't7', from: 'u1', t: '10:41', body: "💚" },
];

const DMS = [
  { id: 'd1', peer: 'u2', last: "do you want help? i can bring the big saw", t: '10:13', unread: 2, verified: true },
  { id: 'd2', peer: 'u6', last: "bringing coffee", t: '10:29', unread: 0, verified: true },
  { id: 'd3', peer: 'u3', last: "can we talk? not in the grove", t: 'yst', unread: 1, verified: false, whisper: true },
  { id: 'd4', peer: 'u5', last: "queued · will send on reconnect", t: '2d', unread: 0, verified: true, queued: 3 },
  { id: 'd5', peer: 'u8', last: "reading-list draft attached", t: '3d', unread: 0, verified: true },
  { id: 'd6', peer: 'u7', last: "pending verification — compare these words", t: '1w', unread: 0, verified: false, pendingVerify: true },
];

const GROUP_DMS = [
  { id: 'gd1', name: 'saturday saw crew', members: ['u1','u2','u4','u6','u9'], last: "bringing coffee", t: '10:29', unread: 0 },
  { id: 'gd2', name: 'long table · hosts', members: ['u1','u8','u9'], last: "menu locked in", t: 'yst', unread: 0 },
];

const PEOPLE_BY_ID = Object.fromEntries(PEERS.map(p => [p.id, p]));

Object.assign(window, {
  PEERS, PEOPLE_BY_ID, GROVES, CHANNEL_GROUPS, MESSAGES, THREAD_MESSAGES, DMS, GROUP_DMS
});
