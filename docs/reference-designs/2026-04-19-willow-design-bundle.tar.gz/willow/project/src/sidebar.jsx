// Left: grove switcher (servers) + channel list.

const GroveSwitcher = ({ groves, currentId, onSelect, onDM, onDiscover, onSettings, dmActive, discoverActive, settingsActive }) => {
  const rail = {
    width: 68, height: '100%', background: 'var(--bg-0)',
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    padding: '14px 0 12px', gap: 6,
    borderRight: '1px solid var(--line-soft)',
  };
  const tile = (opts) => {
    const { active, glyph, accent, onClick, title, kids } = opts;
    return (
      <button onClick={onClick} title={title} style={{
        width: 44, height: 44, borderRadius: active ? 12 : 22,
        background: active ? accent : 'var(--bg-2)',
        color: active ? '#14130f' : 'var(--ink-1)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: 17,
        transition: 'all 180ms cubic-bezier(.2,.9,.3,1)',
        position: 'relative',
      }}
      onMouseEnter={e => { if (!active) { e.currentTarget.style.borderRadius = '14px'; e.currentTarget.style.background = accent; e.currentTarget.style.color = '#14130f'; } }}
      onMouseLeave={e => { if (!active) { e.currentTarget.style.borderRadius = '22px'; e.currentTarget.style.background = 'var(--bg-2)'; e.currentTarget.style.color = 'var(--ink-1)'; } }}
      >
        {kids ?? glyph}
        {active && <span style={{
          position: 'absolute', left: -12, top: 8, bottom: 8, width: 3,
          borderRadius: 2, background: 'var(--ink-0)'
        }}/>}
      </button>
    );
  };

  return (
    <div style={rail}>
      <div style={{ height: 4 }}/>
      {tile({
        active: dmActive, onClick: onDM, title: 'Direct messages', accent: 'var(--moss-2)',
        kids: <Icons.Inbox size={18}/>
      })}
      <div style={{ width: 28, height: 1, background: 'var(--line)', margin: '6px 0' }}/>
      {groves.map(g => (
        <div key={g.id}>{tile({
          active: currentId === g.id && !dmActive && !discoverActive && !settingsActive,
          onClick: () => onSelect(g.id),
          title: g.name, glyph: g.glyph, accent: g.accent,
        })}</div>
      ))}
      {tile({ onClick: () => {}, title: 'New grove', accent: 'var(--moss-2)', kids: <Icons.Plus size={18}/> })}
      {tile({ active: discoverActive, onClick: onDiscover, title: 'Discover', accent: 'var(--amber)', kids: <Icons.Compass size={18}/> })}
      <div style={{ flex: 1 }}/>
      {tile({ active: settingsActive, onClick: onSettings, title: 'Settings', accent: 'var(--ink-2)', kids: <Icons.Settings size={17}/> })}
    </div>
  );
};

const ChannelItem = ({ ch, currentId, onSelect }) => {
  const active = ch.id === currentId;
  const kindIcon = {
    text: Icons.Hash,
    voice: Icons.Volume,
    ephemeral: Icons.Hourglass,
  }[ch.kind] ?? Icons.Hash;
  const K = kindIcon;

  const row = {
    display: 'flex', alignItems: 'center', gap: 8,
    padding: '6px 10px', marginLeft: 4, marginRight: 6,
    borderRadius: 6,
    color: active ? 'var(--ink-0)' : (ch.unread ? 'var(--ink-1)' : 'var(--ink-3)'),
    background: active ? 'var(--bg-3)' : 'transparent',
    cursor: 'pointer', fontSize: 13.5,
    position: 'relative',
  };

  return (
    <div style={row} onClick={() => onSelect(ch.id)}
      onMouseEnter={e => { if (!active) { e.currentTarget.style.background = 'var(--bg-2)'; e.currentTarget.style.color = 'var(--ink-1)'; } }}
      onMouseLeave={e => { if (!active) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = ch.unread ? 'var(--ink-1)' : 'var(--ink-3)'; } }}
    >
      {ch.unread > 0 && !active && (
        <span style={{ position: 'absolute', left: -4, top: '50%', transform: 'translateY(-50%)',
          width: 3, height: 16, borderRadius: 2, background: 'var(--ink-0)' }}/>
      )}
      <K size={14} stroke={1.6}/>
      <span style={{ flex: 1, fontFamily: ch.kind === 'voice' ? 'var(--font-ui)' : 'var(--font-ui)' }}>{ch.name}</span>
      {ch.kind === 'ephemeral' && (
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--whisper)' }}>
          {ch.expires}
        </span>
      )}
      {ch.kind === 'voice' && ch.active > 0 && (
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: 'var(--moss-3)', fontSize: 11 }}>
          <Pulse color="var(--moss-3)"/>{ch.active}
        </span>
      )}
      {ch.unread > 0 && ch.kind !== 'voice' && (
        <span style={{ background: 'var(--moss-2)', color: '#14130f',
          borderRadius: 10, padding: '1px 6px', fontSize: 11, fontWeight: 600,
          minWidth: 18, textAlign: 'center' }}>{ch.unread}</span>
      )}
      {ch.muted && <Icons.Mute size={13} stroke={1.4}/>}
    </div>
  );
};

const ChannelGroup = ({ group, currentId, onSelect }) => {
  const [open, setOpen] = React.useState(true);
  const labelColor = group.label === 'ephemeral' ? 'var(--whisper)'
                   : group.label === 'voice' ? 'var(--moss-3)'
                   : 'var(--ink-3)';
  return (
    <div style={{ marginBottom: 4 }}>
      <button onClick={() => setOpen(o => !o)} style={{
        display: 'flex', alignItems: 'center', gap: 4,
        padding: '10px 12px 6px', width: '100%',
        color: labelColor, textTransform: 'uppercase',
        fontSize: 10.5, fontWeight: 600, letterSpacing: 1.2,
      }}>
        <span style={{ transition: 'transform 140ms', transform: open ? 'rotate(90deg)' : 'none', display: 'inline-flex' }}>
          <Icons.Chevron size={10} stroke={2}/>
        </span>
        <span>{group.label}</span>
        <span style={{ flex: 1 }}/>
        {group.label === 'ephemeral' && <Icons.Hourglass size={11} stroke={1.4}/>}
      </button>
      {open && group.channels.map(ch =>
        <ChannelItem key={ch.id} ch={ch} currentId={currentId} onSelect={onSelect}/>
      )}
    </div>
  );
};

const GroveHeader = ({ grove }) => (
  <div style={{
    padding: '14px 14px 12px', borderBottom: '1px solid var(--line-soft)',
    display: 'flex', flexDirection: 'column', gap: 6,
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{
        width: 26, height: 26, borderRadius: 8, background: grove.accent, color: '#14130f',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: 14,
      }}>{grove.glyph}</div>
      <div style={{ flex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 500, color: 'var(--ink-0)' }}>
            {grove.name}
          </span>
          <span title="a grove is a small private network of peers — no central server"
            style={{
              fontFamily: 'var(--font-display)', fontStyle: 'italic',
              fontSize: 10.5, color: 'var(--moss-3)',
              padding: '1px 5px', borderRadius: 4,
              background: 'color-mix(in oklab, var(--moss-2) 18%, transparent)',
              border: '1px solid var(--moss-1)', letterSpacing: 0.2,
            }}>grove</span>
        </div>
        <div style={{ fontSize: 11, color: 'var(--ink-3)', display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
          <Icons.Users size={10}/>{grove.members} peers
          <span style={{ color: 'var(--ink-4)' }}>·</span>
          <Icons.Lock size={10} stroke={1.4}/> e2e
        </div>
        <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 3,
          fontFamily: 'var(--font-display)', fontStyle: 'italic', letterSpacing: 0.15 }}>
          not a server — held between us
        </div>
      </div>
      <IconBtn icon={Icons.ChevronDown} label="Grove menu" size={26}/>
    </div>
  </div>
);

const UserCard = ({ me, netStats }) => (
  <div style={{
    display: 'flex', alignItems: 'center', gap: 10,
    padding: '10px 10px', margin: '0 6px 6px',
    borderRadius: 10, background: 'var(--bg-2)',
    border: '1px solid var(--line-soft)',
  }}>
    <div style={{ position: 'relative' }}>
      <Avatar user={me} size={30}/>
      <span style={{ position: 'absolute', right: -2, bottom: -2 }}>
        <StatusDot status="online" size={10}/>
      </span>
    </div>
    <div style={{ minWidth: 0, flex: 1 }}>
      <div style={{ fontSize: 13, color: 'var(--ink-0)', fontWeight: 500, display: 'flex', alignItems: 'center', gap: 4 }}>
        {me.name}
        <VerifiedBadge size={10}/>
      </div>
      <div style={{ fontSize: 10.5, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)',
        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
        {me.fp.split('-').slice(0,3).join('·')}
      </div>
    </div>
    <IconBtn icon={Icons.Mic} label="Mic" size={26}/>
    <IconBtn icon={Icons.Headset} label="Deafen" size={26}/>
  </div>
);

const NetStatus = () => (
  <div style={{
    padding: '8px 14px', borderTop: '1px solid var(--line-soft)',
    display: 'flex', alignItems: 'center', gap: 10,
    fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)',
  }}>
    <Pulse/>
    <span style={{ color: 'var(--moss-3)' }}>7 peers</span>
    <span>·</span>
    <span>relay-3</span>
    <span>·</span>
    <span>184ms</span>
  </div>
);

const ChannelSidebar = ({ grove, channels, currentId, onSelect, me }) => (
  <aside style={{
    width: 232, background: 'var(--bg-1)', height: '100%',
    display: 'flex', flexDirection: 'column',
    borderRight: '1px solid var(--line-soft)',
  }}>
    <GroveHeader grove={grove}/>
    <div className="scroll" style={{ flex: 1, padding: '6px 0' }}>
      {channels.map((g, i) => <ChannelGroup key={i} group={g} currentId={currentId} onSelect={onSelect}/>)}
    </div>
    <UserCard me={me}/>
    <NetStatus/>
  </aside>
);

Object.assign(window, { GroveSwitcher, ChannelSidebar });
