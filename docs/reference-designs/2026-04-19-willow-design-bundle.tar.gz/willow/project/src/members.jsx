// Members list — right side pane.

const MemberRow = ({ user }) => {
  const statusText = {
    online: 'online',
    idle: 'idle',
    offline: 'offline',
    whisper: 'whispering',
  }[user.status];
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10, padding: '6px 12px',
      borderRadius: 8, cursor: 'pointer', opacity: user.status === 'offline' ? 0.55 : 1,
    }}
    onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-2)'}
    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
    >
      <div style={{ position: 'relative' }}>
        <Avatar user={user} size={28}/>
        <span style={{ position: 'absolute', right: -2, bottom: -2 }}>
          <StatusDot status={user.status} size={9}/>
        </span>
      </div>
      <div style={{ minWidth: 0, flex: 1 }}>
        <div style={{ fontSize: 13, color: 'var(--ink-0)', display: 'flex', alignItems: 'center', gap: 4 }}>
          {user.name}
          {user.verified && <VerifiedBadge size={9}/>}
          {user.role === 'steward' && (
            <Tag color="var(--willow)" bg="transparent" border="var(--amber-soft)">
              <Icons.Leaf size={9}/>steward
            </Tag>
          )}
        </div>
        <div style={{ fontSize: 11, color: user.status === 'whisper' ? 'var(--whisper)' : 'var(--ink-3)',
          fontFamily: user.status === 'whisper' ? 'var(--font-display)' : 'inherit',
          fontStyle: user.status === 'whisper' ? 'italic' : 'normal' }}>
          {statusText}
          {user.queued > 0 && <span style={{ color: 'var(--amber)', marginLeft: 6, fontFamily: 'var(--font-mono)' }}>· {user.queued} queued</span>}
        </div>
      </div>
    </div>
  );
};

const MembersPane = () => {
  const stewards = PEERS.filter(p => p.role === 'steward');
  const online   = PEERS.filter(p => p.role !== 'steward' && (p.status === 'online' || p.status === 'whisper'));
  const idle     = PEERS.filter(p => p.status === 'idle');
  const offline  = PEERS.filter(p => p.status === 'offline');

  const Section = ({ label, list }) => list.length > 0 && (
    <div style={{ marginBottom: 10 }}>
      <div style={{ padding: '12px 14px 6px', fontSize: 10.5, color: 'var(--ink-3)',
        textTransform: 'uppercase', letterSpacing: 1.2, fontWeight: 600 }}>
        {label} — {list.length}
      </div>
      {list.map(u => <MemberRow key={u.id} user={u}/>)}
    </div>
  );

  return (
    <aside style={{
      width: 232, background: 'var(--bg-1)', borderLeft: '1px solid var(--line-soft)',
      display: 'flex', flexDirection: 'column', height: '100%',
    }}>
      <div style={{ padding: '14px 14px 10px', borderBottom: '1px solid var(--line-soft)',
        display: 'flex', alignItems: 'center', gap: 8 }}>
        <Icons.Users size={14}/>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontStyle: 'italic', color: 'var(--ink-0)' }}>
          the grove
        </span>
        <span style={{ flex: 1 }}/>
        <Tag mono>9</Tag>
      </div>
      <div className="scroll" style={{ flex: 1, padding: '4px 6px' }}>
        <Section label="stewards" list={stewards}/>
        <Section label="online" list={online}/>
        <Section label="idle" list={idle}/>
        <Section label="offline" list={offline}/>
      </div>
    </aside>
  );
};

window.MembersPane = MembersPane;
