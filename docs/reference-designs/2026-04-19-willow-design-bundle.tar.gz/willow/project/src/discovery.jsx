// Discovery — browse groves you can join by invite/fingerprint.

const GroveCard = ({ grove, featured }) => (
  <div style={{
    background: 'var(--bg-1)', border: '1px solid var(--line)',
    borderRadius: 14, overflow: 'hidden',
    gridColumn: featured ? 'span 2' : 'span 1',
    display: 'flex', flexDirection: 'column',
  }}>
    <div style={{ height: featured ? 140 : 90, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0,
        background: `radial-gradient(circle at 30% 30%, ${grove.accent}55, var(--bg-0))` }}/>
      <div style={{ position: 'absolute', left: 16, top: 16,
        width: 44, height: 44, borderRadius: 12, background: grove.accent, color: '#14130f',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 500 }}>
        {grove.glyph}
      </div>
      <div style={{ position: 'absolute', right: 12, top: 12,
        fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-2)',
        background: 'rgba(20,19,15,0.65)', padding: '3px 8px', borderRadius: 6 }}>
        <Icons.Lock size={10}/> invite-only
      </div>
    </div>
    <div style={{ padding: 14, display: 'flex', flexDirection: 'column', flex: 1 }}>
      <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 17, color: 'var(--ink-0)' }}>
        {grove.name}
      </div>
      <div style={{ fontSize: 12.5, color: 'var(--ink-2)', marginTop: 4, lineHeight: 1.5 }}>
        {grove.desc}
      </div>
      <div style={{ flex: 1 }}/>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 12 }}>
        <Tag mono><Icons.Users size={10}/>{grove.members}</Tag>
        <Tag mono><Icons.Leaf size={10}/>4 mutuals</Tag>
        <span style={{ flex: 1 }}/>
        <button style={{
          padding: '6px 12px', borderRadius: 8, background: 'var(--moss-1)',
          color: 'var(--moss-4)', fontSize: 12, fontWeight: 500,
          display: 'inline-flex', alignItems: 'center', gap: 6,
        }}>
          <Icons.Arrow size={12}/>request
        </button>
      </div>
    </div>
  </div>
);

const DiscoverView = () => (
  <div style={{ flex: 1, background: 'var(--bg-1)', display: 'flex', flexDirection: 'column', minWidth: 0 }}>
    <div style={{
      padding: '28px 32px 20px',
      borderBottom: '1px solid var(--line-soft)',
      background: 'linear-gradient(180deg, rgba(106,141,94,0.06), transparent)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <Icons.Compass size={20}/>
        <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 28, color: 'var(--ink-0)' }}>
          find a grove
        </span>
      </div>
      <div style={{ fontSize: 13, color: 'var(--ink-2)', marginTop: 6, maxWidth: 620 }}>
        willow has no directory and no servers — groves are surfaced through the people you already know.
        paste an invite fingerprint to join one directly, or browse what your peers are in.
      </div>

      <div style={{ marginTop: 18, display: 'flex', gap: 10 }}>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 10,
          background: 'var(--bg-2)', border: '1px solid var(--line)', borderRadius: 10, padding: '8px 12px' }}>
          <Icons.Fingerprint size={16}/>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--ink-3)' }}>
            willow://grove/
          </span>
          <input placeholder="paste invite fingerprint — e.g. heather-clay-vale-bramble-sun-nest"
            style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none',
              fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--ink-0)' }}/>
          <button style={{
            padding: '6px 12px', borderRadius: 8, background: 'var(--moss-2)', color: '#14130f',
            fontSize: 12, fontWeight: 600,
          }}>join</button>
        </div>
      </div>
    </div>

    <div className="scroll" style={{ flex: 1, padding: '20px 32px 32px' }}>
      <div style={{ fontSize: 11, color: 'var(--ink-3)',
        textTransform: 'uppercase', letterSpacing: 1.4, marginBottom: 10 }}>
        via mira · ori · perrin
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        <GroveCard featured grove={{ name: 'slow correspondence', glyph: 'S', accent: '#c99b55',
          members: 14, desc: 'once-a-week letters, long-form. reading prompts on sunday.' }}/>
        <GroveCard grove={{ name: 'field lab', glyph: 'F', accent: '#6a8d5e',
          members: 39, desc: 'birding, mycology, weather notes. share your recordings.' }}/>
        <GroveCard grove={{ name: 'night kitchen', glyph: 'N', accent: '#a88fc9',
          members: 51, desc: 'after-hours cooks trading scraps + techniques.' }}/>
        <GroveCard grove={{ name: 'paper architects', glyph: '△', accent: '#93b582',
          members: 22, desc: 'sketch club — weekly prompts, no critique unless asked.' }}/>
        <GroveCard grove={{ name: 'harbor', glyph: 'H', accent: '#d6a54a',
          members: 8, desc: 'a private place. by invitation after three mutual verifications.' }}/>
        <GroveCard grove={{ name: 'stray frequencies', glyph: '∿', accent: '#c97a5a',
          members: 103, desc: 'late-night listening sessions, shared decks, unsigned artists.' }}/>
      </div>

      <div style={{ fontSize: 11, color: 'var(--ink-3)', textTransform: 'uppercase',
        letterSpacing: 1.4, marginTop: 28, marginBottom: 10 }}>
        ephemeral · started in the last 24h
      </div>
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
        {[
          { n: 'storm watch', exp: '6h' }, { n: 'exam week', exp: '3d' },
          { n: 'bookclub vi · session 3', exp: '4h' }, { n: 'moving weekend', exp: '2d' },
        ].map(x => (
          <div key={x.n} style={{
            padding: '10px 14px', borderRadius: 10,
            background: 'var(--bg-2)', border: '1px dashed var(--line)',
            display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <Icons.Hourglass size={14} stroke={1.6} style={{ color: 'var(--whisper)' }}/>
            <div>
              <div style={{ fontSize: 13, color: 'var(--ink-0)' }}>{x.n}</div>
              <div style={{ fontSize: 11, color: 'var(--whisper)', fontFamily: 'var(--font-mono)' }}>expires in {x.exp}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

window.DiscoverView = DiscoverView;
