// Main chat area — channel header, messages, composer.

const ChannelHeader = ({ channel, onToggleMembers, onToggleThread, onOpenCall }) => (
  <div style={{
    height: 52, padding: '0 16px',
    borderBottom: '1px solid var(--line-soft)',
    display: 'flex', alignItems: 'center', gap: 12,
    background: 'var(--bg-1)',
  }}>
    <Icons.Hash size={17} stroke={1.6}/>
    <div style={{
      fontFamily: 'var(--font-display)', fontSize: 17, color: 'var(--ink-0)', fontStyle: 'italic', fontWeight: 500, flexShrink: 0,
    }}>{channel.name}</div>
    <div style={{ width: 1, height: 16, background: 'var(--line)', flexShrink: 0 }}/>
    <div style={{ fontSize: 12.5, color: 'var(--ink-3)', minWidth: 0, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
      {channel.topic ?? 'general chatter'}
    </div>
    <Tag mono border="var(--line)" color="var(--ink-2)" bg="transparent">
      <Icons.Lock size={10} stroke={1.6}/>
      7 holders
    </Tag>
    <IconBtn icon={Icons.Phone} label="Join voice" onClick={onOpenCall}/>
    <IconBtn icon={Icons.Thread} label="Threads" onClick={onToggleThread}/>
    <IconBtn icon={Icons.Pin} label="Pinned"/>
    <IconBtn icon={Icons.Users} label="Members" onClick={onToggleMembers}/>
    <IconBtn icon={Icons.Search} label="Search"/>
  </div>
);

const DaySeparator = ({ label }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '18px 0 10px', padding: '0 24px' }}>
    <div style={{ flex: 1, height: 1, background: 'var(--line)' }}/>
    <span style={{ fontSize: 11, color: 'var(--ink-3)', letterSpacing: 1.2, textTransform: 'uppercase',
      fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 400 }}>
      — {label} —
    </span>
    <div style={{ flex: 1, height: 1, background: 'var(--line)' }}/>
  </div>
);

// Mention parsing, pills, message body, reactions, hover bar live in src/shared/messaging.jsx.
// This file just consumes them via window globals.

const ThreadStub = ({ thread, onOpen }) => (
  <button onClick={onOpen} style={{
    display: 'inline-flex', alignItems: 'center', gap: 8,
    padding: '6px 10px 6px 8px', marginTop: 8,
    borderRadius: 8, background: 'var(--bg-2)',
    border: '1px solid var(--line)', color: 'var(--ink-1)', fontSize: 12.5,
    cursor: 'pointer',
  }}>
    <Icons.Thread size={14} stroke={1.6}/>
    <span style={{ display: 'inline-flex' }}>
      {thread.participants.slice(0,3).map((id, i) => (
        <span key={id} style={{ marginLeft: i ? -8 : 0 }}><Avatar user={PEOPLE_BY_ID[id]} size={18}/></span>
      ))}
    </span>
    <span style={{ color: 'var(--moss-3)', fontWeight: 500 }}>{thread.count} replies</span>
    <span style={{ color: 'var(--ink-3)' }}>· last at {thread.lastAt}</span>
    <span style={{ flex: 1 }}/>
    <span style={{ color: 'var(--ink-3)' }}>open thread</span>
    <Icons.Chevron size={12}/>
  </button>
);

// WhisperBadge / QueuedBadge come from shared/messaging.jsx

const Message = ({ m, prev, onOpenThread }) => {
  const u = PEOPLE_BY_ID[m.from];
  const compact = prev && prev.from === m.from && prev.kind !== 'sep'
                && !m.whisper && !m.queueNote && !m.pin;

  if (m.kind === 'sep') return <DaySeparator label={m.label}/>;

  const mentionsMe = messageMentionsMe(m);

  return (
    <div className="msg-row" style={{
      display: 'flex', gap: 12,
      padding: compact ? '1px 24px' : '8px 24px',
      marginTop: compact ? 0 : 4,
      position: 'relative',
      ...mentionHighlightStyle(mentionsMe),
    }}
    onMouseEnter={e => {
      if (!mentionsMe) e.currentTarget.style.background = 'rgba(255,255,255,0.015)';
      const act = e.currentTarget.querySelector('.msg-actions');
      if (act) act.style.display = 'inline-flex';
    }}
    onMouseLeave={e => {
      if (!mentionsMe) e.currentTarget.style.background = 'transparent';
      const act = e.currentTarget.querySelector('.msg-actions');
      if (act) act.style.display = 'none';
    }}
    >
      <div style={{ width: 38, flexShrink: 0, paddingTop: 2 }}>
        {!compact
          ? <Avatar user={u} size={34}/>
          : <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: 'transparent',
              paddingLeft: 2, display: 'block', width: 34, textAlign: 'center' }}>{m.t}</span>}
      </div>
      <div style={{ minWidth: 0, flex: 1 }}>
        {!compact && (
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 2 }}>
            <PeerName user={u} style={{ fontFamily: 'var(--font-display)', fontSize: 15, color: 'var(--ink-0)', fontWeight: 500 }}>
              {u.name}
            </PeerName>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-2)' }}>
              {u.handle}
            </span>
            {u.verified && <VerifiedBadge size={9}/>}
            <span style={{ fontSize: 11, color: 'var(--ink-3)' }}>{m.t}</span>
            {m.pin && <PinBadge/>}
            {m.whisper && <WhisperBadge/>}
            {m.queueNote && <QueuedBadge/>}
          </div>
        )}
        <div style={{ fontSize: 14.5, color: m.whisper ? 'var(--ink-2)' : 'var(--ink-1)',
          lineHeight: 1.5, fontStyle: m.whisper ? 'italic' : 'normal' }}>
          <MessageBody body={m.body} whisper={m.whisper}/>
        </div>
        {m.img && (
          <div style={{ marginTop: 8, maxWidth: 380 }}>
            <LeafPlaceholder w={380} h={200} seed={parseInt(m.id.replace(/\D/g,''), 10) || 0}/>
            <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 4, fontFamily: 'var(--font-mono)' }}>
              IMG_2108.jpg · 1.2MB · e2e encrypted
            </div>
          </div>
        )}
        {m.code && (
          <pre style={{
            marginTop: 8, padding: '8px 12px', background: 'var(--bg-0)',
            border: '1px solid var(--line)', borderRadius: 8,
            fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--ink-2)',
            maxWidth: 520, whiteSpace: 'pre-wrap',
          }}>{m.code}</pre>
        )}
        {m.reactions && <ReactionList list={m.reactions}/>}
        {m.thread && <ThreadStub thread={m.thread} onOpen={onOpenThread}/>}
      </div>
      <HoverReactionBar compact={compact} onOpenThread={onOpenThread}/>
    </div>
  );
};

const Composer = ({ channel }) => (
  <div style={{ padding: '0 16px 16px' }}>
    <div style={{
      background: 'var(--bg-2)', borderRadius: 12, border: '1px solid var(--line)',
      padding: '8px 10px', display: 'flex', flexDirection: 'column', gap: 8,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <IconBtn icon={Icons.Plus} label="Attach" size={28}/>
        <input
          placeholder={`message #${channel.name} — encrypted to 7 peers`}
          style={{
            flex: 1, background: 'transparent', border: 'none', outline: 'none',
            fontSize: 14, color: 'var(--ink-0)',
          }}
        />
        <IconBtn icon={Icons.Gift} label="Gift" size={28}/>
        <IconBtn icon={Icons.Smile} label="Emoji" size={28}/>
        <button style={{
          display: 'inline-flex', alignItems: 'center', gap: 6,
          padding: '6px 10px', borderRadius: 8,
          background: 'var(--moss-1)', color: 'var(--moss-4)',
          fontSize: 12, fontWeight: 500,
        }}>
          <Icons.Send size={13} stroke={1.8}/>send
        </button>
      </div>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        fontSize: 11, color: 'var(--ink-3)', paddingLeft: 6,
      }}>
        <Icons.Lock size={10} stroke={1.6}/>
        <span>sealed with grove-keys</span>
        <span style={{ color: 'var(--ink-4)' }}>·</span>
        <Icons.Ear size={10} stroke={1.6}/>
        <span>hold <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--whisper)' }}>shift</span> to whisper</span>
        <span style={{ flex: 1 }}/>
        <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', color: 'var(--ink-2)' }}>
          juno is whispering
        </span>
        <span style={{
          display: 'inline-flex', gap: 2,
        }}>
          {[0,1,2].map(i => (
            <span key={i} style={{
              width: 3, height: 3, borderRadius: '50%', background: 'var(--whisper)',
              animation: `willowPulse 1200ms ${i * 200}ms infinite ease-in-out`,
            }}/>
          ))}
        </span>
      </div>
    </div>
  </div>
);

const ChatView = ({ channel, onToggleMembers, onToggleThread, onOpenCall, onOpenThreadFor }) => (
  <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minWidth: 0, background: 'var(--bg-1)' }}>
    <ChannelHeader channel={channel}
      onToggleMembers={onToggleMembers}
      onToggleThread={onToggleThread}
      onOpenCall={onOpenCall}/>
    <div className="scroll" style={{ flex: 1, padding: '16px 0' }}>
      <ChannelPreamble channel={channel}/>
      {MESSAGES.map((m, i) => (
        <Message key={m.id} m={m} prev={MESSAGES[i-1]} onOpenThread={() => onOpenThreadFor(m)}/>
      ))}
    </div>
    <Composer channel={channel}/>
  </div>
);

const ChannelPreamble = ({ channel }) => (
  <div style={{ padding: '28px 24px 16px', borderBottom: '1px dashed var(--line)', marginBottom: 12 }}>
    <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      width: 52, height: 52, borderRadius: 14, background: 'var(--bg-2)',
      border: '1px solid var(--line)', color: 'var(--willow)' }}>
      <Icons.Hash size={24} stroke={1.4}/>
    </div>
    <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontStyle: 'italic', color: 'var(--ink-0)', marginTop: 12 }}>
      welcome to #{channel.name}
    </div>
    <div style={{ fontSize: 13.5, color: 'var(--ink-2)', marginTop: 4, maxWidth: 560 }}>
      {channel.topic} · messages are end-to-end encrypted to everyone in the grove, stored locally on each device.
      no server sees the plaintext.
    </div>
    <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
      <Tag mono><Icons.Key size={10}/> grove-keys</Tag>
      <Tag mono><Icons.Users size={10}/> 7 holders</Tag>
      <Tag mono color="var(--moss-3)"><Icons.Check size={10}/> all verified</Tag>
    </div>
  </div>
);

Object.assign(window, { ChatView, ChannelHeader, Message });
