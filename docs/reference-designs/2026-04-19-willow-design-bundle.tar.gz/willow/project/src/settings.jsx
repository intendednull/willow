// Settings — encryption, devices, peers.

const SettingsNav = ({ current, onSelect }) => {
  const groups = [
    { label: 'account', items: [
      { id: 'profile', name: 'profile', icon: Icons.User },
      { id: 'devices', name: 'devices', icon: Icons.Device },
    ]},
    { label: 'privacy', items: [
      { id: 'keys', name: 'keys & encryption', icon: Icons.Key },
      { id: 'peers', name: 'peers & trust', icon: Icons.Fingerprint },
      { id: 'network', name: 'network', icon: Icons.Wifi },
    ]},
    { label: 'app', items: [
      { id: 'appearance', name: 'appearance', icon: Icons.Spark },
      { id: 'notifications', name: 'notifications', icon: Icons.Bell },
    ]},
  ];
  return (
    <aside style={{
      width: 232, background: 'var(--bg-1)', borderRight: '1px solid var(--line-soft)',
      padding: '18px 0', height: '100%', overflow: 'auto',
    }} className="scroll">
      <div style={{ padding: '0 16px 12px' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 18, color: 'var(--ink-0)' }}>
          settings
        </div>
      </div>
      {groups.map(g => (
        <div key={g.label} style={{ marginBottom: 10 }}>
          <div style={{ padding: '10px 16px 4px', fontSize: 10.5, color: 'var(--ink-3)',
            textTransform: 'uppercase', letterSpacing: 1.2 }}>{g.label}</div>
          {g.items.map(it => {
            const I = it.icon;
            const active = current === it.id;
            return (
              <button key={it.id} onClick={() => onSelect(it.id)} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                width: 'calc(100% - 12px)', margin: '2px 6px', padding: '7px 10px',
                borderRadius: 8, background: active ? 'var(--bg-3)' : 'transparent',
                color: active ? 'var(--ink-0)' : 'var(--ink-2)', fontSize: 13,
              }}>
                <I size={14} stroke={1.5}/>{it.name}
              </button>
            );
          })}
        </div>
      ))}
    </aside>
  );
};

const Section = ({ title, subtitle, children }) => (
  <div style={{ marginBottom: 32, maxWidth: 720 }}>
    <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 22, color: 'var(--ink-0)' }}>{title}</div>
    {subtitle && <div style={{ fontSize: 13, color: 'var(--ink-2)', marginTop: 4, lineHeight: 1.5 }}>{subtitle}</div>}
    <div style={{ marginTop: 14 }}>{children}</div>
  </div>
);

const Row = ({ label, hint, right, mono }) => (
  <div style={{
    display: 'flex', alignItems: 'center', gap: 14, padding: '12px 16px',
    borderBottom: '1px solid var(--line-soft)',
  }}>
    <div style={{ flex: 1 }}>
      <div style={{ fontSize: 13.5, color: 'var(--ink-0)' }}>{label}</div>
      {hint && <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginTop: 2,
        fontFamily: mono ? 'var(--font-mono)' : 'inherit' }}>{hint}</div>}
    </div>
    <div>{right}</div>
  </div>
);

const Switch = ({ on }) => (
  <div style={{
    width: 36, height: 20, borderRadius: 10, background: on ? 'var(--moss-2)' : 'var(--bg-3)',
    position: 'relative', cursor: 'pointer', transition: 'background 180ms',
  }}>
    <div style={{
      position: 'absolute', top: 2, left: on ? 18 : 2, width: 16, height: 16, borderRadius: '50%',
      background: on ? '#14130f' : 'var(--ink-1)', transition: 'left 180ms',
    }}/>
  </div>
);

const Card = ({ children }) => (
  <div style={{ background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 12, overflow: 'hidden' }}>
    {children}
  </div>
);

const KeysSettings = () => (
  <>
    <Section title="your identity"
      subtitle="these keys were made on this device and never leave it. use your fingerprint so other people can verify you.">
      <Card>
        <div style={{ padding: 18 }}>
          <div style={{ fontSize: 11, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.2 }}>
            long-term fingerprint
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 6, marginTop: 10 }}>
            {'willow copper reed glade slate moth'.split(' ').map((w, i) => (
              <div key={i} style={{
                padding: '8px 10px', background: 'var(--bg-2)', borderRadius: 8,
                border: '1px solid var(--line)', fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--ink-0)',
                display: 'flex', flexDirection: 'column', gap: 2,
              }}>
                <span style={{ fontSize: 9, color: 'var(--ink-4)' }}>{i+1}</span>
                {w}
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <button style={{ padding: '6px 12px', borderRadius: 8, background: 'var(--bg-2)',
              border: '1px solid var(--line)', fontSize: 12, color: 'var(--ink-1)',
              display: 'inline-flex', alignItems: 'center', gap: 6 }}>
              <Icons.Link size={12}/>copy as text
            </button>
            <button style={{ padding: '6px 12px', borderRadius: 8, background: 'var(--bg-2)',
              border: '1px solid var(--line)', fontSize: 12, color: 'var(--ink-1)',
              display: 'inline-flex', alignItems: 'center', gap: 6 }}>
              <Icons.Spark size={12}/>show qr
            </button>
            <span style={{ flex: 1 }}/>
            <span style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)' }}>ed25519 · x25519 · chacha20-poly1305</span>
          </div>
        </div>
      </Card>
    </Section>

    <Section title="per-channel keys"
      subtitle="by default everyone in a grove holds the keys. you can narrow who can read which channel.">
      <Card>
        <Row label="#meander · grove-keys"
             hint="7 holders · everyone in quiet grove · rotated weekly"
             right={<Tag mono color="var(--moss-3)" border="var(--line)">default</Tag>}/>
        <Row label="#reading-room · custom-keys"
             hint="3 holders · mira · perrin · wren"
             right={<Tag mono color="var(--amber)" border="var(--amber-soft)">narrowed</Tag>}/>
        <Row label="#night-session · ephemeral-keys"
             hint="burns in 2h 14m · keys erased from all devices when expired"
             right={<Tag mono color="var(--whisper)" border="color-mix(in oklab, var(--whisper) 30%, var(--line))">ephemeral</Tag>}/>
        <Row label="#old-letters · archived-keys"
             hint="sealed 14 jan · read-only · key held by you alone"
             right={<Tag mono color="var(--ink-2)" border="var(--line)">archived</Tag>}/>
      </Card>
    </Section>

    <Section title="forward secrecy">
      <Card>
        <Row label="rotate message keys"
             hint="new key every 24h, or every 100 messages"
             right={<Switch on/>}/>
        <Row label="delete decrypted media after 7 days"
             hint="original files stay encrypted on disk"
             right={<Switch on/>}/>
        <Row label="burn after reading (per message)"
             hint="sender decides; receiver's device respects"
             right={<Switch/>}/>
      </Card>
    </Section>
  </>
);

const DevicesSettings = () => (
  <>
    <Section title="your devices"
      subtitle="each device has its own sub-key. revoke a device and its messages vanish from the grove in seconds.">
      <Card>
        {[
          { n: 'willow·desk', os: 'macOS 15 · this device', here: true, last: 'now', ver: true },
          { n: 'willow·phone', os: 'iOS 18 · added 3 weeks ago', here: false, last: '2h ago', ver: true },
          { n: 'willow·cabin', os: 'Linux · added 14 feb', here: false, last: '4d ago', ver: true },
        ].map((d, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px',
            borderBottom: '1px solid var(--line-soft)',
          }}>
            <div style={{ width: 34, height: 34, borderRadius: 10, background: 'var(--bg-2)', border: '1px solid var(--line)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--moss-3)' }}>
              <Icons.Device size={16}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13.5, color: 'var(--ink-0)', display: 'flex', alignItems: 'center', gap: 6 }}>
                {d.n}
                {d.here && <Tag mono color="var(--moss-3)" border="var(--line)">this device</Tag>}
                {d.ver && <VerifiedBadge size={9}/>}
              </div>
              <div style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>{d.os} · last seen {d.last}</div>
            </div>
            <button style={{ padding: '6px 10px', borderRadius: 8, background: 'transparent',
              border: '1px solid var(--line)', color: d.here ? 'var(--ink-3)' : 'var(--err)', fontSize: 12,
              opacity: d.here ? 0.5 : 1, cursor: d.here ? 'default' : 'pointer' }}>
              {d.here ? 'active' : 'revoke'}
            </button>
          </div>
        ))}
      </Card>

      <div style={{ marginTop: 12, padding: '14px 16px', borderRadius: 12,
        background: 'var(--bg-1)', border: '1px dashed var(--line)',
        display: 'flex', alignItems: 'center', gap: 12 }}>
        <Icons.Plus size={16}/>
        <div>
          <div style={{ fontSize: 13, color: 'var(--ink-0)' }}>add a new device</div>
          <div style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>scan a qr on the new device · keys stream over local network</div>
        </div>
      </div>
    </Section>
  </>
);

const PeersSettings = () => (
  <Section title="peers & trust" subtitle="who you've verified, and how.">
    <Card>
      {PEERS.filter(p => !p.self).map(p => (
        <div key={p.id} style={{
          display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px',
          borderBottom: '1px solid var(--line-soft)',
        }}>
          <Avatar user={p} size={30}/>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13.5, color: 'var(--ink-0)', display: 'flex', alignItems: 'center', gap: 6 }}>
              {p.name}
              <span style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)' }}>{p.handle}</span>
              {p.verified && <VerifiedBadge size={9}/>}
            </div>
            <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)', marginTop: 2 }}>
              {p.fp}
            </div>
          </div>
          <Tag mono color={p.verified ? 'var(--moss-3)' : 'var(--amber)'} border="var(--line)">
            {p.verified ? 'verified · in person' : 'unverified'}
          </Tag>
        </div>
      ))}
    </Card>
  </Section>
);

const NetworkSettings = () => (
  <>
    <Section title="network" subtitle="willow prefers direct p2p; relays are only used when no hole-punch is possible.">
      <Card>
        <Row label="direct peers" hint="3 of 7 right now · nat-traversal succeeded" right={<Pulse color="var(--moss-3)"/>}/>
        <Row label="via relay" hint="4 of 7 · traffic still e2e encrypted · relay sees only ciphertext"
             right={<span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-2)' }}>relay-3 · 184ms</span>}/>
        <Row label="offline queue"
             hint="willow holds encrypted messages for peers until they come online"
             mono right={<span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--amber)' }}>12 out · 3 in</span>}/>
        <Row label="relay-over-tor" hint="route through tor when no direct peer is available" right={<Switch/>}/>
      </Card>
    </Section>
  </>
);

const SettingsView = ({ onClose }) => {
  const [section, setSection] = React.useState('keys');
  return (
    <div style={{ flex: 1, display: 'flex', minWidth: 0, background: 'var(--bg-0)' }}>
      <SettingsNav current={section} onSelect={setSection}/>
      <div style={{ flex: 1, background: 'var(--bg-0)', overflow: 'auto', position: 'relative' }} className="scroll">
        <div style={{ position: 'sticky', top: 0, zIndex: 2,
          padding: '14px 32px', background: 'var(--bg-0)', borderBottom: '1px solid var(--line-soft)',
          display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ flex: 1 }}/>
          <IconBtn icon={Icons.X} label="close" onClick={onClose}/>
        </div>
        <div style={{ padding: '28px 32px 60px' }}>
          {section === 'keys' && <KeysSettings/>}
          {section === 'devices' && <DevicesSettings/>}
          {section === 'peers' && <PeersSettings/>}
          {section === 'network' && <NetworkSettings/>}
          {section === 'profile' && <Section title="profile"><Card><Row label="name" hint="shown to verified peers" right={<span style={{ fontFamily: 'var(--font-mono)', color: 'var(--ink-1)' }}>you</span>}/><Row label="handle" right={<span style={{ fontFamily: 'var(--font-mono)', color: 'var(--ink-1)' }}>@you</span>}/></Card></Section>}
          {section === 'appearance' && <Section title="appearance" subtitle="use the tweaks panel (top-right) for live edits."><Card><Row label="theme" right={<Tag>dark</Tag>}/><Row label="accent" right={<Tag color="#14130f" bg="var(--moss-2)">moss</Tag>}/></Card></Section>}
          {section === 'notifications' && <Section title="notifications"><Card><Row label="sound on new message" right={<Switch on/>}/><Row label="desktop notifications" right={<Switch on/>}/><Row label="quiet hours" hint="22:00 – 08:00" right={<Switch/>}/></Card></Section>}
        </div>
      </div>
    </div>
  );
};

window.SettingsView = SettingsView;
