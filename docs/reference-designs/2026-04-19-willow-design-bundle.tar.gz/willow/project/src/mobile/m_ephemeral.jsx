// Ephemeral channel creation — lock-screen style countdown.

const { useState: useS_eph, useEffect: useE_eph } = React;

const EphemeralScreen = ({ platform, onBack }) => {
  const [hours, setHours] = useS_eph(6);
  const [name, setName] = useS_eph('night-session');
  const [now, setNow] = useS_eph(Date.now());
  useE_eph(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  // Fake expiry for the preview clock
  const expiry = now + hours * 3600 * 1000;
  const total = hours * 3600;
  const remaining = Math.max(0, Math.round((expiry - now) / 1000));
  const hh = String(Math.floor(remaining / 3600)).padStart(2, '0');
  const mm = String(Math.floor((remaining % 3600) / 60)).padStart(2, '0');
  const ss = String(remaining % 60).padStart(2, '0');
  const pct = 1 - remaining / total;

  return (
    <MScreen style={{ background: 'var(--bg-0)' }}>
      <MTopBar platform={platform} style={{ background: 'transparent', borderBottom: 'none' }}
        left={<button onClick={onBack} style={{ padding: 6, color: 'var(--ink-1)' }}>
          <Icons.Chevron size={20} style={{ transform: 'rotate(180deg)' }}/></button>}
        title={
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icons.Hourglass size={14} stroke={1.6}/>
            <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 15, color: 'var(--amber)' }}>
              ephemeral channel
            </span>
          </div>
        }
        subtitle="self-destructs · keys erased after"
      />
      <MBody pad="20px 18px">
        <div style={{ textAlign: 'center', padding: '8px 0 20px' }}>
          {/* Lock-screen style time */}
          <div style={{
            fontFamily: 'var(--font-display)', fontStyle: 'italic',
            fontSize: 72, lineHeight: 1, color: 'var(--amber)', letterSpacing: -2, fontWeight: 300,
          }}>
            {hh}<span style={{ color: 'var(--amber-soft)' }}>:</span>{mm}
            <span style={{ fontSize: 32, color: 'var(--amber-soft)' }}>:{ss}</span>
          </div>
          <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 6, fontFamily: 'var(--font-mono)',
            textTransform: 'uppercase', letterSpacing: 1.8 }}>
            until keys burn
          </div>

          {/* Progress ring */}
          <svg width="180" height="10" viewBox="0 0 180 10" style={{ marginTop: 14, display: 'block', margin: '14px auto 0' }}>
            <rect x="0" y="4" width="180" height="2" rx="1" fill="var(--bg-2)"/>
            <rect x="0" y="3" width={180 * pct} height="4" rx="2" fill="var(--amber)"/>
            {[0, 0.25, 0.5, 0.75, 1].map(p => (
              <rect key={p} x={180 * p - 0.5} y={1} width="1" height="8" fill="var(--line)"/>
            ))}
          </svg>
        </div>

        <div style={{ padding: 14, borderRadius: 14, background: 'var(--bg-1)', border: '1px solid var(--line)' }}>
          <label style={{ fontSize: 10.5, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.2,
            display: 'block', marginBottom: 6 }}>channel name</label>
          <input value={name} onChange={e => setName(e.target.value)} style={{
            width: '100%', background: 'var(--bg-2)', border: '1px solid var(--line)',
            borderRadius: 10, padding: '10px 12px', color: 'var(--ink-0)', fontSize: 14,
            outline: 'none', fontFamily: 'var(--font-mono)',
          }}/>
          <label style={{ fontSize: 10.5, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.2,
            display: 'block', margin: '14px 0 6px' }}>duration</label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 6 }}>
            {[1, 6, 24, 72, 168].map(h => {
              const active = h === hours;
              return (
                <button key={h} onClick={() => setHours(h)} style={{
                  padding: '10px 6px', borderRadius: 10,
                  background: active ? 'var(--amber)' : 'var(--bg-2)',
                  border: `1px solid ${active ? 'var(--amber)' : 'var(--line)'}`,
                  color: active ? '#14130f' : 'var(--ink-1)',
                  fontSize: 11.5, fontFamily: 'var(--font-mono)',
                }}>
                  {h < 24 ? `${h}h` : `${h/24}d`}
                </button>
              );
            })}
          </div>

          <div style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 8,
            padding: '10px 12px', borderRadius: 10, background: 'var(--bg-2)',
            border: '1px dashed var(--amber-soft)' }}>
            <Icons.Key size={13} stroke={1.6} style={{ color: 'var(--amber)' }}/>
            <div style={{ flex: 1, fontSize: 11.5, color: 'var(--ink-2)', lineHeight: 1.5 }}>
              a single-use key is forged now and burned when the timer ends. messages can't be recovered.
            </div>
          </div>
        </div>

        <button style={{
          width: '100%', marginTop: 16, padding: 14, borderRadius: 12,
          background: 'var(--amber)', color: '#14130f',
          fontSize: 14, fontWeight: 600,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
        }}>
          <Icons.Hourglass size={14} stroke={2}/> open #{name}
        </button>
        <button style={{
          width: '100%', marginTop: 8, padding: 10, fontSize: 12,
          color: 'var(--ink-3)',
        }}>cancel</button>
      </MBody>
    </MScreen>
  );
};

window.EphemeralScreen = EphemeralScreen;
