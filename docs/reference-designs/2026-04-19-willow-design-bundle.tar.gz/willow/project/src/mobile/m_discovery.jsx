// Discovery — find groves to join. P2p flavor: not a directory, but "groves your peers are in".

const DiscoveryScreen = ({ platform, onBack }) => (
  <MScreen>
    <MTopBar platform={platform}
      left={<button onClick={onBack} style={{ padding: 6, color: 'var(--ink-1)' }}><Icons.Chevron size={20} style={{ transform: 'rotate(180deg)' }}/></button>}
      title="discover"
      subtitle="groves shared by people you trust"
    />
    <MBody pad="14px 0 20px">
      <div style={{ padding: '0 14px 8px', display: 'flex', gap: 6 }}>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 6,
          background: 'var(--bg-2)', borderRadius: 10, padding: '8px 12px', border: '1px solid var(--line)' }}>
          <Icons.Search size={13} stroke={1.8}/>
          <input placeholder="paste an invite or search…" style={{
            flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 13, color: 'var(--ink-0)',
          }}/>
        </div>
        <button style={{ width: 42, height: 40, borderRadius: 10, background: 'var(--bg-2)',
          border: '1px solid var(--line)', color: 'var(--willow)',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icons.Plus size={16} stroke={1.8}/>
        </button>
      </div>

      {/* start a grove card */}
      <div style={{ margin: '8px 14px 14px', padding: 16, borderRadius: 14,
        background: 'var(--bg-2)', border: '1px solid var(--line)',
        display: 'flex', gap: 14, alignItems: 'center' }}>
        <div style={{ width: 46, height: 46, borderRadius: 12,
          background: 'linear-gradient(135deg, var(--moss-1), var(--bg-1))',
          color: 'var(--willow)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icons.Tree size={22} stroke={1.6}/>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 17, color: 'var(--ink-0)' }}>
            plant a grove
          </div>
          <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 2 }}>
            pick who holds a key. no one else will know it exists.
          </div>
        </div>
        <Icons.Chevron size={14}/>
      </div>

      <SectionHeader label="groves your peers are in"/>
      {[
        { name: 'Fox Bureau',      glyph: 'F', accent: '#c99b55', sharedBy: ['u1','u4'], members: 18, desc: 'Small group · field notes and dispatches.' },
        { name: 'Low Tide Radio',  glyph: '∿', accent: '#a88fc9', sharedBy: ['u2'],      members: 44, desc: 'Weekly listening parties.' },
        { name: 'Orchard',         glyph: 'O', accent: '#93b582', sharedBy: ['u6','u8'], members: 12, desc: 'Cooking · preserves · very seasonal.' },
      ].map((g, i) => (
        <div key={i} style={{
          display: 'flex', alignItems: 'center', gap: 12,
          padding: '12px 16px', borderBottom: '1px solid var(--line-soft)',
        }}>
          <div style={{
            width: 42, height: 42, borderRadius: 12, background: g.accent, color: '#14130f',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 20, fontWeight: 500,
          }}>{g.glyph}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 14, color: 'var(--ink-0)' }}>{g.name}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {g.desc}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
              <div style={{ display: 'flex' }}>
                {g.sharedBy.map((id, i) => (
                  <span key={id} style={{ marginLeft: i ? -6 : 0 }}><MAvatar user={PEOPLE_BY_ID[id]} size={16}/></span>
                ))}
              </div>
              <span style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>
                {g.sharedBy.map(id => PEOPLE_BY_ID[id].name).join(' · ')} · {g.members} members
              </span>
            </div>
          </div>
          <button style={{
            padding: '6px 10px', borderRadius: 8, background: 'var(--bg-2)',
            border: '1px solid var(--line)', color: 'var(--moss-3)', fontSize: 11.5,
          }}>ask for key</button>
        </div>
      ))}

      <div style={{ padding: '14px 16px', fontSize: 11, color: 'var(--ink-3)',
        display: 'flex', gap: 8, alignItems: 'flex-start', lineHeight: 1.55 }}>
        <Icons.Lock size={12}/>
        <span>joining requires an existing holder to hand you a key. willow has no public directory.</span>
      </div>
    </MBody>
  </MScreen>
);

window.DiscoveryScreen = DiscoveryScreen;
