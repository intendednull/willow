// Home screen — grove switcher as a side drawer, channel list as the main view.
// The first screen the user lands on: current grove's channels.

const { useState: useS_home } = React;

const ChannelRow = ({ ch, onTap, platform }) => {
  const kind = ch.kind;
  const glyph = kind === 'voice' ? <Icons.Volume size={14} stroke={1.6}/>
               : kind === 'ephemeral' ? <Icons.Hourglass size={14} stroke={1.6}/>
               : <Icons.Hash size={14} stroke={1.6}/>;
  const tint = kind === 'ephemeral' ? 'var(--amber)' : kind === 'voice' ? 'var(--willow)' : 'var(--ink-3)';
  return (
    <button onClick={onTap} style={{
      width: '100%', display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 16px', textAlign: 'left', color: 'var(--ink-1)',
      borderBottom: '1px solid var(--line-soft)', minHeight: 58,
    }}>
      <span style={{ width: 22, color: tint, display: 'inline-flex', justifyContent: 'center' }}>{glyph}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 15, color: ch.unread ? 'var(--ink-0)' : 'var(--ink-1)',
            fontWeight: ch.unread ? 500 : 400 }}>{ch.name}</span>
          {kind === 'ephemeral' && (
            <MTag mono bg="transparent" border="var(--amber-soft)" color="var(--amber)">
              <Icons.Hourglass size={9}/> {ch.expires}
            </MTag>
          )}
          {kind === 'voice' && ch.active > 0 && (
            <MTag mono bg="color-mix(in oklab, var(--moss-2) 18%, var(--bg-2))" color="var(--moss-3)" border="var(--moss-1)">
              <span style={{ width:6, height:6, borderRadius:'50%', background:'var(--moss-3)',
                animation: 'willowPulse 1200ms infinite' }}/> {ch.active} listening
            </MTag>
          )}
        </div>
        {ch.topic && (
          <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 2,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{ch.topic}</div>
        )}
      </div>
      {ch.unread > 0 && (
        <span style={{
          minWidth: 20, height: 20, padding: '0 6px', borderRadius: 10,
          background: 'var(--moss-2)', color: '#14130f',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 11, fontWeight: 600,
        }}>{ch.unread}</span>
      )}
    </button>
  );
};

const GroveRail = ({ groves, currentId, onSelect, onDiscover }) => (
  <div style={{
    width: 64, background: 'var(--bg-0)', borderRight: '1px solid var(--line-soft)',
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    padding: '12px 0 10px', gap: 8, flexShrink: 0, overflow: 'auto',
  }} className="noscroll">
    {groves.map(g => {
      const active = g.id === currentId;
      return (
        <button key={g.id} onClick={() => onSelect(g.id)} style={{
          position: 'relative', width: 44, height: 44, borderRadius: active ? 14 : 22,
          background: active ? g.accent : 'var(--bg-2)',
          color: active ? '#14130f' : 'var(--ink-1)',
          fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 18, fontWeight: 500,
          transition: 'border-radius 180ms', border: `1px solid ${active ? g.accent : 'var(--line)'}`,
        }}>
          {g.glyph}
          {active && (
            <span style={{
              position: 'absolute', left: -10, top: '50%', transform: 'translateY(-50%)',
              width: 4, height: 22, borderRadius: 2, background: 'var(--ink-0)',
            }}/>
          )}
        </button>
      );
    })}
    <div style={{ width: 24, height: 1, background: 'var(--line)', margin: '2px 0' }}/>
    <button onClick={onDiscover} style={{
      width: 44, height: 44, borderRadius: 22,
      background: 'var(--bg-2)', color: 'var(--moss-3)',
      border: '1px dashed var(--line)',
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <Icons.Plus size={16} stroke={1.8}/>
    </button>
  </div>
);

const GroveDrawer = ({ open, onClose, groves, currentId, onSelect, onDiscover }) => (
  <>
    {open && <div onClick={onClose} style={{
      position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.55)', zIndex: 20,
      transition: 'opacity 200ms',
    }}/>}
    <div style={{
      position: 'absolute', top: 0, bottom: 0, left: 0, width: 280,
      background: 'var(--bg-1)', zIndex: 21,
      transform: open ? 'translateX(0)' : 'translateX(-100%)',
      transition: 'transform 240ms cubic-bezier(0.2, 0.8, 0.2, 1)',
      display: 'flex', borderRight: '1px solid var(--line-soft)',
      boxShadow: open ? '10px 0 40px rgba(0,0,0,0.4)' : 'none',
    }}>
      <GroveRail groves={groves} currentId={currentId} onSelect={onSelect} onDiscover={onDiscover}/>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <div style={{ padding: '14px 14px 10px', borderBottom: '1px solid var(--line-soft)' }}>
          <MWordmark size={16}/>
          <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 6 }}>3 groves · 6 peers online</div>
        </div>
        <div className="scroll" style={{ flex: 1, padding: '8px 6px' }}>
          {GROVES.map(g => (
            <button key={g.id} onClick={() => { onSelect(g.id); onClose(); }} style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 10px', borderRadius: 10, textAlign: 'left',
              background: g.id === currentId ? 'var(--bg-3)' : 'transparent', marginBottom: 2,
            }}>
              <span style={{
                width: 30, height: 30, borderRadius: 9, background: g.accent, color: '#14130f',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 15, fontWeight: 500,
              }}>{g.glyph}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, color: 'var(--ink-0)' }}>{g.name}</div>
                <div style={{ fontSize: 11, color: 'var(--ink-3)',
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{g.members} members</div>
              </div>
            </button>
          ))}
        </div>
        <div style={{
          padding: '10px 14px', borderTop: '1px solid var(--line-soft)',
          display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--ink-2)',
        }}>
          <MAvatar user={PEOPLE_BY_ID['u9']} size={28}/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ color: 'var(--ink-0)', fontSize: 12 }}>you</div>
            <div style={{ fontSize: 10, color: 'var(--moss-3)', fontFamily: 'var(--font-mono)' }}>willow · phone</div>
          </div>
          <Icons.Settings size={14}/>
        </div>
      </div>
    </div>
  </>
);

const HomeScreen = ({ platform, grove, channels, onOpenChannel, onOpenGroveList, onOpenSearch }) => {
  return (
    <MScreen>
      <MTopBar platform={platform}
        left={
          <button onClick={onOpenGroveList} style={{
            width: 32, height: 32, borderRadius: 9, background: grove.accent, color: '#14130f',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 16, fontWeight: 500,
          }}>{grove.glyph}</button>
        }
        title={grove.name}
        subtitle={`${grove.members} members · 6 online`}
        right={
          <div style={{ display: 'flex', gap: 4 }}>
            <button onClick={onOpenSearch} style={{ padding: 8, color: 'var(--ink-2)' }}>
              <Icons.Search size={18}/>
            </button>
            <button style={{ padding: 8, color: 'var(--ink-2)' }}>
              <Icons.Bell size={18}/>
            </button>
          </div>
        }
      />
      <MBody>
        {/* Peers online strip */}
        <div style={{ padding: '10px 14px 4px', display: 'flex', alignItems: 'center', gap: 10,
          borderBottom: '1px solid var(--line-soft)', overflowX: 'auto' }} className="noscroll">
          {PEERS.filter(p => p.status === 'online' || p.status === 'idle').slice(0, 6).map(p => (
            <div key={p.id} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, flexShrink: 0 }}>
              <div style={{ position: 'relative' }}>
                <MAvatar user={p} size={42}/>
                <span style={{ position: 'absolute', right: -2, bottom: -2 }}><MDot status={p.status}/></span>
              </div>
              <span style={{ fontSize: 10, color: 'var(--ink-2)', maxWidth: 48,
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</span>
            </div>
          ))}
        </div>

        <SectionHeader label="commons"/>
        {channels.find(g => g.label === 'commons')?.channels.map(ch =>
          <ChannelRow key={ch.id} ch={ch} platform={platform} onTap={() => onOpenChannel(ch)}/>
        )}

        <SectionHeader label="voice" trailing={<Icons.Plus size={13}/>}/>
        {channels.find(g => g.label === 'voice')?.channels.map(ch =>
          <ChannelRow key={ch.id} ch={ch} platform={platform} onTap={() => onOpenChannel(ch)}/>
        )}

        <SectionHeader label="ephemeral" trailing={
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--amber)' }}>self-destructs</span>
        }/>
        {channels.find(g => g.label === 'ephemeral')?.channels.map(ch =>
          <ChannelRow key={ch.id} ch={ch} platform={platform} onTap={() => onOpenChannel(ch)}/>
        )}

        {/* Key holders status */}
        <div style={{ padding: '18px 16px 14px', margin: '12px 12px 18px',
          background: 'var(--bg-2)', borderRadius: 14, border: '1px solid var(--line)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Icons.Lock size={13} stroke={1.6}/>
            <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 14, color: 'var(--ink-0)' }}>
              this grove is held by 7 people
            </div>
          </div>
          <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginTop: 4, lineHeight: 1.55 }}>
            every message is sealed with keys that live on each device. no server in the middle.
          </div>
          <div style={{ display: 'flex', marginTop: 10 }}>
            {PEERS.slice(0, 6).map((p, i) => (
              <span key={p.id} style={{ marginLeft: i ? -10 : 0 }}>
                <MAvatar user={p} size={26} ring={'var(--bg-2)'}/>
              </span>
            ))}
            <span style={{
              marginLeft: -10, width: 26, height: 26, borderRadius: '50%',
              background: 'var(--bg-3)', color: 'var(--ink-2)',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 10, border: '2px solid var(--bg-2)',
            }}>+1</span>
          </div>
        </div>
      </MBody>
    </MScreen>
  );
};

const SectionHeader = ({ label, trailing }) => (
  <div style={{
    padding: '14px 16px 6px', display: 'flex', alignItems: 'center', gap: 8,
    background: 'var(--bg-1)',
  }}>
    <span style={{ fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase',
      letterSpacing: 1.4, fontFamily: 'var(--font-display)', fontStyle: 'italic' }}>{label}</span>
    <div style={{ flex: 1, height: 1, background: 'var(--line-soft)' }}/>
    {trailing && <span style={{ color: 'var(--ink-3)' }}>{trailing}</span>}
  </div>
);

Object.assign(window, { HomeScreen, GroveDrawer, ChannelRow, SectionHeader });
