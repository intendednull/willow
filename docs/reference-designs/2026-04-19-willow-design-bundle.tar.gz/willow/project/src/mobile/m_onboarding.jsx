// Onboarding — keys + SAS verify with long-press-to-confirm.

const { useState: useS_onb } = React;

const OnboardingScreen = ({ platform, onDone }) => {
  const [matched, setMatched] = useS_onb(false);
  const { progress, handlers } = useLongPress(() => setMatched(true), 900);

  return (
    <MScreen style={{ background: 'var(--bg-0)' }}>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none',
        background: 'radial-gradient(400px 260px at 50% 10%, rgba(106,141,94,0.12), transparent 60%), radial-gradient(360px 240px at 80% 90%, rgba(201,155,85,0.08), transparent 60%)' }}/>
      <div style={{ padding: '14px 16px 0', display: 'flex', alignItems: 'center', gap: 8 }}>
        <MWordmark size={16}/>
        <span style={{ flex: 1 }}/>
        <MTag mono>step 3 · 4</MTag>
      </div>
      <MBody pad="20px 18px">
        <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 28, color: 'var(--ink-0)', lineHeight: 1.1 }}>
          {SAS_COPY.title}
        </div>
        <div style={{ fontSize: 13, color: 'var(--ink-2)', marginTop: 6, lineHeight: 1.55 }}>
          {SAS_COPY.intro}
        </div>

        {/* Your card */}
        <div style={{ marginTop: 18, padding: 14, borderRadius: 14,
          background: 'var(--bg-1)', border: '1px solid var(--line)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <MAvatar user={PEOPLE_BY_ID['u9']} size={32}/>
            <div>
              <div style={{ fontSize: 13, color: 'var(--ink-0)' }}>you · willow·phone</div>
              <div style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>just now</div>
            </div>
          </div>
          <FingerprintLabel which="you" size="sm"/>
          <FingerprintGrid words={SAS_YOU_WORDS} size="sm"/>
        </div>

        {/* Friend card */}
        <div style={{ marginTop: 10, padding: 14, borderRadius: 14,
          background: 'var(--bg-1)', border: `1px solid ${matched ? 'var(--moss-2)' : 'var(--line)'}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <MAvatar user={PEOPLE_BY_ID['u2']} size={32}/>
            <div>
              <div style={{ fontSize: 13, color: 'var(--ink-0)' }}>ori · willow·phone</div>
              <div style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>via nearby share</div>
            </div>
            <span style={{ flex: 1 }}/>
            {matched && <MVerified size={11}/>}
          </div>
          <FingerprintLabel which="peer" size="sm"/>
          <FingerprintGrid words={SAS_PEER_MATCHED_WORDS} size="sm"/>
          <div style={{ marginTop: 14 }}>
            <button {...handlers} style={{
              width: '100%', padding: '14px', borderRadius: 12,
              background: matched ? 'var(--moss-2)' : 'var(--bg-2)',
              border: `1px solid ${matched ? 'var(--moss-2)' : 'var(--line)'}`,
              color: matched ? '#14130f' : 'var(--ink-0)', fontSize: 14, fontWeight: 500,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              position: 'relative', overflow: 'hidden',
              userSelect: 'none', WebkitUserSelect: 'none',
            }}>
              <span style={{
                position: 'absolute', left: 0, top: 0, bottom: 0,
                width: `${progress * 100}%`, background: 'color-mix(in oklab, var(--moss-2) 70%, transparent)',
                transition: progress === 0 ? 'width 300ms' : 'none',
              }}/>
              <span style={{ position: 'relative', zIndex: 1, display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                {matched ? <><Icons.Check size={14} stroke={2.2}/> verified</> : <>
                  <Icons.Fingerprint size={14}/> hold to confirm they match
                </>}
              </span>
            </button>
            {!matched && (
              <button style={{
                width: '100%', marginTop: 8, padding: '10px', borderRadius: 10,
                background: 'transparent', border: '1px solid var(--line)', color: 'var(--ink-2)', fontSize: 12,
              }}>{SAS_COPY.noMatchCta}</button>
            )}
          </div>
        </div>

        <div style={{ marginTop: 16, display: 'flex', gap: 8, alignItems: 'flex-start',
          fontSize: 11, color: 'var(--ink-3)', lineHeight: 1.55 }}>
          <Icons.Shield size={14} stroke={1.6}/>
          <span>{SAS_COPY.reassurance}</span>
        </div>

        <button onClick={onDone} disabled={!matched} style={{
          width: '100%', marginTop: 18, padding: 14, borderRadius: 12,
          background: matched ? 'var(--bg-3)' : 'var(--bg-2)',
          color: matched ? 'var(--ink-0)' : 'var(--ink-3)',
          border: '1px solid var(--line)', fontSize: 14,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          opacity: matched ? 1 : 0.7,
        }}>
          continue <Icons.Arrow size={14}/>
        </button>
      </MBody>
    </MScreen>
  );
};

window.OnboardingScreen = OnboardingScreen;
