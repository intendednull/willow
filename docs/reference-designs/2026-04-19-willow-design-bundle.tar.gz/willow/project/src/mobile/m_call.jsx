// Call screen — voice/video with screen share + whisper panel + control dock.

const { useState: useS_call } = React;

const CallTileM = ({ user, speaking, isScreen, isSelf, whispering, size }) => {
  const ring = speaking ? 'var(--moss-3)' : whispering ? 'var(--whisper)' : 'transparent';
  return (
    <div style={{
      position: 'relative', borderRadius: 14, overflow: 'hidden',
      background: 'var(--bg-2)', border: `2px solid ${ring}`,
      transition: 'border-color 180ms',
      width: '100%', aspectRatio: size === 'big' ? '16/10' : '1',
      minHeight: size === 'big' ? 180 : 0,
    }}>
      <div style={{ position: 'absolute', inset: 0,
        background: `radial-gradient(circle at 30% 30%, ${user.avatar}2c, var(--bg-0))` }}/>
      {isScreen ? (
        <ScreenShareContent compact={true}/>
      ) : (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{
            width: size === 'big' ? 80 : 40, height: size === 'big' ? 80 : 40, borderRadius: '50%',
            background: user.avatar, color: '#14130f',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: size === 'big' ? 36 : 18, fontWeight: 500,
            boxShadow: speaking ? `0 0 0 6px ${user.avatar}33, 0 0 0 10px ${user.avatar}11` : 'none',
            transition: 'box-shadow 200ms',
          }}>{user.name[0]}</div>
        </div>
      )}
      <div style={{
        position: 'absolute', left: 6, bottom: 6, right: 6,
        display: 'flex', alignItems: 'center', gap: 4,
      }}>
        <span style={{
          padding: '2px 6px', borderRadius: 5, background: 'rgba(20,19,15,0.78)',
          backdropFilter: 'blur(8px)', color: 'var(--ink-0)', fontSize: 10,
          display: 'inline-flex', alignItems: 'center', gap: 4,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '70%',
        }}>
          {user.name}{isSelf && <span style={{ color: 'var(--ink-3)' }}>· you</span>}
          {whispering && <Icons.Ear size={9} stroke={1.8}/>}
        </span>
        <span style={{ flex: 1 }}/>
        {user.muted && (
          <span style={{ padding: 3, borderRadius: 5, background: 'rgba(201,122,90,0.25)', color: 'var(--err)' }}>
            <Icons.MicOff size={9}/>
          </span>
        )}
      </div>
    </div>
  );
};

const CallCtrl = ({ icon, label, active, tone, onClick, danger }) => {
  const Ic = icon;
  const bg = danger ? 'var(--err)'
    : active ? (tone === 'whisper' ? 'color-mix(in oklab, var(--whisper) 30%, var(--bg-2))' : 'var(--bg-3)')
    : 'var(--bg-2)';
  const fg = danger ? '#14130f'
    : active ? (tone === 'whisper' ? 'var(--whisper)' : 'var(--ink-0)')
    : 'var(--ink-1)';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
      <button onClick={onClick} style={{
        width: 50, height: 50, borderRadius: '50%',
        background: bg, color: fg, border: '1px solid var(--line)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Ic size={20} stroke={1.7}/>
      </button>
      <span style={{ fontSize: 9.5, color: 'var(--ink-3)' }}>{label}</span>
    </div>
  );
};

const WhisperSheet = ({ onClose }) => (
  <div onClick={onClose} style={{ position: 'absolute', inset: 0, zIndex: 30,
    background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'flex-end' }}>
    <div onClick={e => e.stopPropagation()} style={{
      width: '100%', background: 'linear-gradient(180deg, color-mix(in oklab, var(--whisper) 16%, var(--bg-1)), var(--bg-1) 80%)',
      borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 18,
      borderTop: '1px solid color-mix(in oklab, var(--whisper) 30%, var(--line))',
    }}>
      <div style={{ width: 36, height: 4, borderRadius: 2, background: 'var(--ink-4)', margin: '0 auto 14px' }}/>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
        <Icons.Ear size={14} stroke={1.6}/>
        <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 17, color: 'var(--whisper)' }}>
          whispering with ori
        </span>
        <span style={{ flex: 1 }}/>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-3)' }}>02:14</span>
      </div>
      <div style={{ fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.55 }}>
        side-channel inside the grove. its own ephemeral key; nobody else on the call can hear it.
      </div>
      <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 10,
        padding: '10px 12px', borderRadius: 12, background: 'var(--bg-2)', border: '1px solid var(--line)' }}>
        <MAvatar user={PEOPLE_BY_ID['u2']} size={32}/>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, color: 'var(--ink-0)' }}>ori.birch</div>
          <div style={{ fontSize: 11, color: 'var(--whisper)', fontStyle: 'italic', fontFamily: 'var(--font-display)' }}>
            speaking softly…
          </div>
        </div>
        <span style={{ display: 'inline-flex', gap: 2, alignItems: 'end', height: 14 }}>
          {[8,6,10,4,7].map((h,i)=> (
            <span key={i} style={{ width: 3, height: h, background: 'var(--whisper)', borderRadius: 1.5,
              animation: `willowPulse 900ms ${i * 120}ms infinite` }}/>
          ))}
        </span>
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
        <button style={{ flex: 1, padding: '10px', borderRadius: 10, background: 'var(--bg-2)',
          border: '1px solid var(--line)', color: 'var(--ink-1)', fontSize: 12.5 }}>invite someone</button>
        <button style={{ flex: 1, padding: '10px', borderRadius: 10, background: 'transparent',
          border: '1px solid color-mix(in oklab, var(--whisper) 40%, var(--line))', color: 'var(--whisper)', fontSize: 12.5 }}>
          leave whisper
        </button>
      </div>
    </div>
  </div>
);

const HandoffSheet = ({ onClose }) => (
  <div onClick={onClose} style={{ position: 'absolute', inset: 0, zIndex: 30,
    background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'flex-end' }}>
    <div onClick={e => e.stopPropagation()} style={{
      width: '100%', background: 'var(--bg-1)', borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 18,
      borderTop: '1px solid var(--line)',
    }}>
      <div style={{ width: 36, height: 4, borderRadius: 2, background: 'var(--ink-4)', margin: '0 auto 14px' }}/>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
        <Icons.Device size={14}/>
        <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 17, color: 'var(--ink-0)' }}>{HANDOFF_COPY.title}</span>
      </div>
      <div style={{ fontSize: 12, color: 'var(--ink-3)', marginBottom: 10 }}>
        {HANDOFF_COPY.subtitle}
      </div>
      {HANDOFF_DEVICES_MOBILE.map(d => (
        <button key={d.n} disabled={d.here} style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 10,
          padding: '11px 12px', borderRadius: 12, marginBottom: 6,
          background: 'var(--bg-2)', border: '1px solid var(--line)',
          color: d.here ? 'var(--ink-3)' : 'var(--ink-0)', textAlign: 'left',
          opacity: d.here ? 0.65 : 1,
        }}>
          <Icons.Device size={14}/>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }}>{d.n}</div>
            <div style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>{d.meta}</div>
          </div>
          {d.here ? <MTag mono color="var(--moss-3)" border="var(--line)">here</MTag> : <Icons.Chevron size={12}/>}
        </button>
      ))}
    </div>
  </div>
);

const CallScreen = ({ platform, channel, onHangup }) => {
  const [sheet, setSheet] = useS_call(null);
  const sharer = PEOPLE_BY_ID['u6'];
  const others = [PEERS[0], PEERS[1], PEERS[2], PEERS[3], PEOPLE_BY_ID['u9']];
  return (
    <MScreen style={{ background: 'var(--bg-0)' }}>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none',
        background: 'radial-gradient(500px 300px at 30% 0%, rgba(106,141,94,0.10), transparent 60%), radial-gradient(400px 300px at 70% 100%, rgba(168,143,201,0.06), transparent 60%)' }}/>
      <MTopBar platform={platform} style={{ background: 'transparent', borderBottom: 'none' }}
        left={
          <button onClick={onHangup} style={{ padding: 6, color: 'var(--ink-1)' }}>
            <Icons.Chevron size={20} stroke={1.8} style={{ transform: 'rotate(180deg)' }}/>
          </button>
        }
        title={
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icons.Volume size={14} stroke={1.6}/>
            <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 15, color: 'var(--ink-0)' }}>
              {channel?.name ?? 'the-porch'}
            </span>
            <MTag mono>5 · 42:18</MTag>
          </div>
        }
        subtitle={
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Icons.Lock size={9}/> 2 direct · 3 relay
          </span>
        }
        right={<button style={{ padding: 8, color: 'var(--ink-2)' }}><Icons.Grid size={18}/></button>}
      />
      <div style={{ flex: 1, padding: '8px 12px 12px', display: 'flex', flexDirection: 'column', gap: 8, overflow: 'auto' }}>
        {/* Whisper pill */}
        <button onClick={() => setSheet('whisper')} style={{ alignSelf: 'flex-start' }}>
          <WhisperPill/>
        </button>
        {/* Big tile — sharer */}
        <CallTileM user={sharer} isScreen speaking size="big"/>
        {/* Participants grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
          {others.map((u, i) => (
            <CallTileM key={u.id} user={{ ...u, muted: i === 2 }}
              speaking={i === 0} whispering={i === 2} isSelf={u.id === 'u9'}/>
          ))}
        </div>
      </div>
      {/* Dock */}
      <div style={{
        padding: '12px 10px 14px', background: 'color-mix(in oklab, var(--bg-1) 90%, transparent)',
        backdropFilter: 'blur(20px)', borderTop: '1px solid var(--line-soft)',
        display: 'flex', justifyContent: 'space-around', alignItems: 'flex-start',
      }}>
        <CallCtrl icon={Icons.Mic} label="mute"/>
        <CallCtrl icon={Icons.Cam} label="camera"/>
        <CallCtrl icon={Icons.Screen} label="share" active/>
        <CallCtrl icon={Icons.Ear} label="whisper" tone="whisper" active onClick={() => setSheet('whisper')}/>
        <CallCtrl icon={Icons.Device} label="handoff" onClick={() => setSheet('handoff')}/>
        <CallCtrl icon={Icons.PhoneDown} label="leave" danger onClick={onHangup}/>
      </div>
      {sheet === 'whisper' && <WhisperSheet onClose={() => setSheet(null)}/>}
      {sheet === 'handoff' && <HandoffSheet onClose={() => setSheet(null)}/>}
    </MScreen>
  );
};

window.CallScreen = CallScreen;
