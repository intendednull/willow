// Sync queue screen — shown when the user pulls down the pull banner far enough
// or taps the "3 queued" status. Original view: per-peer reachability + outbound.

const SyncQueueScreen = ({ platform, onBack }) => (
  <MScreen>
    <MTopBar platform={platform}
      left={<button onClick={onBack} style={{ padding: 6, color: 'var(--ink-1)' }}><Icons.Chevron size={20} style={{ transform: 'rotate(180deg)' }}/></button>}
      title="sync queue"
      subtitle="what's pending · what's reachable"
      right={<button style={{ padding: 8, color: 'var(--moss-3)' }}><Icons.Signal size={18}/></button>}
    />
    <MBody>
      <div style={{ padding: 16, margin: 14, borderRadius: 14,
        background: 'var(--bg-2)', border: '1px solid var(--line)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 10, height: 10, borderRadius: '50%', background: 'var(--moss-3)',
            animation: 'willowPulse 1200ms infinite' }}/>
          <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 15, color: 'var(--ink-0)' }}>
            reaching out…
          </span>
          <span style={{ flex: 1 }}/>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-2)' }}>3 / 8 peers</span>
        </div>
        <div style={{ marginTop: 10, height: 6, borderRadius: 3, background: 'var(--bg-0)', overflow: 'hidden' }}>
          <div style={{ height: '100%', width: '42%', background: 'var(--moss-2)' }}/>
        </div>
      </div>

      <SectionHeader label="queued — will deliver when peer is reachable"/>
      {[
        { peer: 'u5', preview: "queued · 'bringing the big saw if you need it'", age: '2d' },
        { peer: 'u7', preview: 'reaction 🍃 · on draft', age: '1d' },
        { peer: 'u3', preview: "whisper · 'can we talk? not in the grove'", age: '6h', whisper: true },
      ].map((q, i) => {
        const u = PEOPLE_BY_ID[q.peer];
        return (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '12px 16px', borderBottom: '1px solid var(--line-soft)',
          }}>
            <MAvatar user={u} size={34}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontSize: 13.5, color: 'var(--ink-0)' }}>{u.name}</span>
                <MTag mono color="var(--amber)" border="var(--amber-soft)"><Icons.Hourglass size={8}/>waiting</MTag>
              </div>
              <div style={{ fontSize: 11.5, color: q.whisper ? 'var(--whisper)' : 'var(--ink-3)',
                fontStyle: q.whisper ? 'italic' : 'normal',
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {q.preview}
              </div>
            </div>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-3)' }}>{q.age}</span>
          </div>
        );
      })}

      <SectionHeader label="recent · arrived from queue"/>
      {[
        { peer: 'u9', preview: '14 messages synced overnight', meta: 'from 4 peers' },
        { peer: 'u8', preview: 'reading-list draft attached', meta: '3 min ago' },
      ].map((q, i) => {
        const u = PEOPLE_BY_ID[q.peer];
        return (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '12px 16px', borderBottom: '1px solid var(--line-soft)',
          }}>
            <MAvatar user={u} size={32}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontSize: 13, color: 'var(--ink-1)' }}>{u.name}</span>
                <MTag mono color="var(--moss-3)" border="var(--line)"><Icons.Check size={8}/>synced</MTag>
              </div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{q.preview} · {q.meta}</div>
            </div>
          </div>
        );
      })}

      <div style={{ padding: '18px 16px', fontSize: 11, color: 'var(--ink-3)',
        display: 'flex', gap: 8, alignItems: 'flex-start', lineHeight: 1.55 }}>
        <Icons.Signal size={12}/>
        <span>willow holds unsent messages on this device and tries again automatically. nothing is stored on a server.</span>
      </div>
    </MBody>
  </MScreen>
);

window.SyncQueueScreen = SyncQueueScreen;
