// DMs list + DM thread (two screens).

const { useState: useS_dm } = React;

const DMListRow = ({ dm, onOpen }) => {
  if (dm.members) {
    const firstTwo = dm.members.slice(0,2).map(id => PEOPLE_BY_ID[id]);
    return (
      <button onClick={() => onOpen(dm)} style={{
        width: '100%', display: 'flex', alignItems: 'center', gap: 12,
        padding: '10px 14px', textAlign: 'left',
        borderBottom: '1px solid var(--line-soft)', minHeight: 62,
      }}>
        <div style={{ display: 'flex', width: 46 }}>
          {firstTwo.map((u, i) => <span key={u.id} style={{ marginLeft: i ? -12 : 0 }}><MAvatar user={u} size={34}/></span>)}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, color: 'var(--ink-0)', display: 'flex', alignItems: 'center', gap: 4 }}>
            {dm.name}
            <MTag mono><Icons.Users size={9}/>{dm.members.length}</MTag>
          </div>
          <div style={{ fontSize: 11.5, color: 'var(--ink-3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{dm.last}</div>
        </div>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-3)' }}>{dm.t}</span>
      </button>
    );
  }
  const u = PEOPLE_BY_ID[dm.peer];
  return (
    <button onClick={() => onOpen(dm)} style={{
      width: '100%', display: 'flex', alignItems: 'center', gap: 12,
      padding: '10px 14px', textAlign: 'left',
      borderBottom: '1px solid var(--line-soft)', minHeight: 62,
    }}>
      <div style={{ position: 'relative' }}>
        <MAvatar user={u} size={38}/>
        <span style={{ position: 'absolute', right: -2, bottom: -2 }}><MDot status={u.status}/></span>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span style={{ fontSize: 14, color: 'var(--ink-0)' }}>{u.name}</span>
          {dm.verified ? <MVerified size={9}/> : (
            <span style={{ width: 13, height: 13, borderRadius: '50%',
              border: '1.2px dashed var(--amber)', color: 'var(--amber)', fontSize: 8.5,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>?</span>
          )}
          {dm.whisper && <Icons.Ear size={11} stroke={1.6} style={{ color: 'var(--whisper)' }}/>}
          <span style={{ flex: 1 }}/>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-3)' }}>{dm.t}</span>
        </div>
        <div style={{ fontSize: 11.5, color: dm.unread ? 'var(--ink-1)' : 'var(--ink-3)',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
          {dm.queued > 0 && <MTag mono color="var(--amber)" border="var(--amber-soft)"><Icons.Hourglass size={8}/>{dm.queued}</MTag>}
          {dm.pendingVerify && <MTag mono color="var(--amber)" border="var(--amber-soft)"><Icons.Fingerprint size={8}/>verify</MTag>}
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{dm.last}</span>
        </div>
      </div>
      {dm.unread > 0 && (
        <span style={{
          minWidth: 18, height: 18, padding: '0 5px', borderRadius: 9,
          background: 'var(--moss-2)', color: '#14130f',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 10.5, fontWeight: 600,
        }}>{dm.unread}</span>
      )}
    </button>
  );
};

const DMListScreen = ({ platform, onOpen, onBack }) => (
  <MScreen>
    <MTopBar platform={platform}
      left={<button onClick={onBack} style={{ padding: 6, color: 'var(--ink-1)' }}><Icons.Chevron size={20} style={{ transform: 'rotate(180deg)' }}/></button>}
      title="letters"
      subtitle="direct · e2e, device-local"
      right={<button style={{ padding: 8, color: 'var(--moss-3)' }}><Icons.Plus size={18} stroke={2}/></button>}
    />
    <MBody>
      <div style={{ padding: '8px 14px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6,
          background: 'var(--bg-2)', borderRadius: 10, padding: '8px 12px', border: '1px solid var(--line)' }}>
          <Icons.Search size={13} stroke={1.8}/>
          <input placeholder="search letters…" style={{
            flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 13, color: 'var(--ink-0)',
          }}/>
        </div>
      </div>
      <SectionHeader label="direct"/>
      {DMS.map(dm => <DMListRow key={dm.id} dm={dm} onOpen={onOpen}/>)}
      <SectionHeader label="small circles"/>
      {GROUP_DMS.map(dm => <DMListRow key={dm.id} dm={dm} onOpen={onOpen}/>)}
      <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 8,
        color: 'var(--ink-3)', fontSize: 11.5 }}>
        <Icons.Fingerprint size={12}/>
        <span>start a letter by fingerprint — nearby share, QR, or six-word code</span>
      </div>
    </MBody>
  </MScreen>
);

const DMThreadScreen = ({ platform, dm, onBack }) => {
  const peer = dm?.peer ? PEOPLE_BY_ID[dm.peer] : null;
  return (
    <MScreen>
      <MTopBar platform={platform}
        left={<button onClick={onBack} style={{ padding: 6, color: 'var(--ink-1)' }}><Icons.Chevron size={20} style={{ transform: 'rotate(180deg)' }}/></button>}
        title={
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {peer && <MAvatar user={peer} size={26}/>}
            <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 15, color: 'var(--ink-0)' }}>
              {peer?.name ?? dm?.name ?? '…'}
            </span>
            {peer?.verified && <MVerified size={9}/>}
          </div>
        }
        subtitle={peer ? 'direct · no relay' : 'small circle'}
        right={
          <div style={{ display: 'flex', gap: 2 }}>
            <button style={{ padding: 8, color: 'var(--ink-2)' }}><Icons.Phone size={18}/></button>
            <button style={{ padding: 8, color: 'var(--ink-2)' }}><Icons.Cam size={18}/></button>
          </div>
        }
      />
      <MBody>
        <div style={{ textAlign: 'center', padding: '18px 20px 20px' }}>
          <MMark size={34}/>
          <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 16, color: 'var(--ink-0)', marginTop: 6 }}>
            you met {peer?.name ?? '…'} in person
          </div>
          <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>
            keys verified 14 feb · no one between you
          </div>
        </div>
        {[
          { from: 'u2', t: '10:02', body: 'woke up to leaves everywhere. did the shed survive?' },
          { from: 'u9', t: '10:04', body: 'shed ok — the willow lost a limb. mira posted photos in #meander' },
          { from: 'u2', t: '10:13', body: 'do you want help? i can bring the big saw' },
          { from: 'u9', t: '10:14', body: 'yes please 🫶' },
        ].map((m, i) => {
          const u = PEOPLE_BY_ID[m.from];
          const self = m.from === 'u9';
          return (
            <div key={i} style={{ display: 'flex', gap: 8, justifyContent: self ? 'flex-end' : 'flex-start',
              padding: '0 12px', marginBottom: 8 }}>
              {!self && <MAvatar user={u} size={26}/>}
              <div style={{ maxWidth: '76%' }}>
                <div style={{
                  padding: '8px 12px', borderRadius: 14,
                  background: self ? 'var(--moss-1)' : 'var(--bg-2)',
                  color: self ? 'var(--moss-4)' : 'var(--ink-1)',
                  border: '1px solid var(--line)',
                  fontSize: 13.5, lineHeight: 1.45,
                  borderBottomRightRadius: self ? 4 : 14,
                  borderBottomLeftRadius: self ? 14 : 4,
                }}>{m.body}</div>
                <div style={{ fontSize: 9.5, color: 'var(--ink-3)', marginTop: 2,
                  textAlign: self ? 'right' : 'left', fontFamily: 'var(--font-mono)' }}>
                  {m.t} {self && '· sealed'}
                </div>
              </div>
            </div>
          );
        })}
      </MBody>
      <div style={{ padding: '8px 10px 10px', background: 'var(--bg-1)', borderTop: '1px solid var(--line-soft)' }}>
        <div style={{
          background: 'var(--bg-2)', borderRadius: 20, border: '1px solid var(--line)',
          padding: '6px 8px 6px 12px', display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <button style={{ color: 'var(--ink-2)', padding: 4 }}><Icons.Paperclip size={17}/></button>
          <input placeholder={`write to ${peer?.name ?? '…'}…`} style={{
            flex: 1, background: 'transparent', border: 'none', outline: 'none',
            fontSize: 14, color: 'var(--ink-0)', padding: '6px 2px',
          }}/>
          <button style={{
            width: 32, height: 32, borderRadius: '50%',
            background: 'var(--moss-2)', color: '#14130f',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          }}><Icons.Send size={14} stroke={2}/></button>
        </div>
      </div>
    </MScreen>
  );
};

Object.assign(window, { DMListScreen, DMThreadScreen });
