// Mobile primitives for Willow.
// A single MobileFrame renders BOTH an iOS-style and Android-style phone chrome,
// wrapping a SharedCanvas (the actual app). This keeps every screen written once.

const { useState, useEffect, useRef, useLayoutEffect, useMemo } = React;

// ---- Chrome pieces (trimmed, in-brand) ----

const NotchBar = ({ time = '9:41', platform = 'ios' }) => {
  const tint = 'var(--ink-0)';
  return (
    <div style={{
      height: platform === 'ios' ? 54 : 40,
      padding: platform === 'ios' ? '0 30px' : '0 16px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      color: tint, fontFamily: 'var(--font-ui)', fontSize: 14, fontWeight: 500,
      flexShrink: 0, position: 'relative', zIndex: 5,
    }}>
      <span style={{ letterSpacing: 0.2 }}>{time}</span>
      {platform === 'ios' && (
        <div style={{
          position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%)',
          width: 120, height: 34, borderRadius: 22, background: '#000',
        }}/>
      )}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        {/* signal */}
        <svg width="16" height="11" viewBox="0 0 16 11" style={{ opacity: 0.9 }}>
          <rect x="0" y="7" width="2.4" height="4" rx="0.5" fill={tint}/>
          <rect x="4" y="5" width="2.4" height="6" rx="0.5" fill={tint}/>
          <rect x="8" y="2.5" width="2.4" height="8.5" rx="0.5" fill={tint}/>
          <rect x="12" y="0" width="2.4" height="11" rx="0.5" fill={tint}/>
        </svg>
        {/* willow p2p indicator — three hanging strokes instead of wifi */}
        <svg width="14" height="11" viewBox="0 0 14 11">
          <path d="M2 2 C 2 6 2 9 2 10" stroke="var(--moss-3)" strokeWidth="1.4" strokeLinecap="round"/>
          <path d="M7 2 C 7 6 7 9 7 10" stroke="var(--moss-3)" strokeWidth="1.4" strokeLinecap="round"/>
          <path d="M12 2 C 12 6 12 9 12 10" stroke="var(--moss-3)" strokeWidth="1.4" strokeLinecap="round" opacity="0.5"/>
        </svg>
        {/* battery */}
        <svg width="24" height="11" viewBox="0 0 24 11">
          <rect x="0.5" y="0.5" width="20" height="10" rx="2.5" fill="none" stroke={tint} strokeOpacity="0.5"/>
          <rect x="2" y="2" width="14" height="7" rx="1" fill={tint}/>
          <rect x="21.5" y="4" width="1.5" height="3" rx="0.5" fill={tint} fillOpacity="0.5"/>
        </svg>
      </div>
    </div>
  );
};

const HomeIndicator = ({ dark = true, platform = 'ios' }) => (
  <div style={{
    height: platform === 'ios' ? 34 : 22,
    display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
    padding: platform === 'ios' ? '0 0 8px' : '0 0 6px',
    flexShrink: 0, background: 'transparent',
  }}>
    <div style={{
      width: platform === 'ios' ? 134 : 108, height: platform === 'ios' ? 5 : 3,
      borderRadius: 100, background: dark ? 'rgba(255,255,255,0.55)' : 'rgba(0,0,0,0.35)',
    }}/>
  </div>
);

// ---- The phone frame (iOS and Android variants) ----

const MobileFrame = ({ platform = 'ios', label, children }) => {
  const w = platform === 'ios' ? 390 : 412;
  const h = platform === 'ios' ? 844 : 880;
  const radius = platform === 'ios' ? 54 : 38;
  return (
    <div style={{
      display: 'inline-flex', flexDirection: 'column', alignItems: 'center', gap: 14,
    }}>
      <div style={{
        fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 15,
        color: 'var(--ink-3)', letterSpacing: 0.4,
      }}>{label}</div>
      <div style={{
        width: w, height: h, borderRadius: radius, overflow: 'hidden',
        background: 'var(--bg-0)', position: 'relative',
        boxShadow: platform === 'ios'
          ? '0 0 0 10px #1a1915, 0 0 0 11px #2a2822, 0 40px 100px rgba(0,0,0,0.55)'
          : '0 0 0 8px #24221d, 0 0 0 9px #3a372f, 0 40px 100px rgba(0,0,0,0.5)',
      }}>
        <NotchBar platform={platform}/>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
          paddingTop: platform === 'ios' ? 54 : 40 }}>
          <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
            {typeof children === 'function' ? children({ platform }) : children}
          </div>
          <HomeIndicator platform={platform}/>
        </div>
      </div>
    </div>
  );
};

// ---- Common atoms ----

const MAvatar = ({ user, size = 32, ring, nonInteractive }) => {
  if (!user) return null;
  const interactive = !nonInteractive && !!window.openProfile;
  return (
    <span
      onClick={interactive ? (e) => { e.stopPropagation(); window.openProfile(user.id, e.currentTarget); } : undefined}
      style={{
        width: size, height: size, borderRadius: '50%', background: user.avatar,
        color: '#14130f', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: size * 0.44,
        border: ring ? `2px solid ${ring}` : 'none', flexShrink: 0,
        cursor: interactive ? 'pointer' : 'default',
      }}>{user.name[0]}</span>
  );
};

const MPeerName = ({ user, children, style }) => {
  if (!user) return children ?? null;
  const interactive = !!window.openProfile;
  return (
    <span
      onClick={interactive ? (e) => { e.stopPropagation(); window.openProfile(user.id, e.currentTarget); } : undefined}
      style={{
        cursor: interactive ? 'pointer' : 'inherit',
        borderRadius: 4,
        padding: interactive ? '0 2px' : 0,
        margin: interactive ? '0 -2px' : 0,
        ...style,
      }}
    >
      {children ?? user.name}
    </span>
  );
};

const MDot = ({ status, size = 9 }) => {
  const map = { online:'var(--moss-2)', idle:'var(--warn)', offline:'var(--ink-4)', whisper:'var(--whisper)' };
  return <span style={{
    width: size, height: size, borderRadius: '50%',
    background: map[status] ?? 'var(--ink-4)',
    boxShadow: '0 0 0 2px var(--bg-0)', display: 'inline-block',
  }}/>;
};

const MTag = ({ children, color = 'var(--ink-2)', bg = 'var(--bg-2)', border = 'transparent', mono }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 4,
    padding: '2px 7px', borderRadius: 999,
    background: bg, color, border: `1px solid ${border}`,
    fontFamily: mono ? 'var(--font-mono)' : 'var(--font-ui)',
    fontSize: 10.5, lineHeight: 1.2, letterSpacing: mono ? 0.2 : 0,
  }}>{children}</span>
);

const MVerified = ({ size = 10 }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    width: size + 4, height: size + 4, borderRadius: '50%',
    background: 'var(--moss-1)', color: 'var(--moss-4)',
  }}>
    <Icons.Check size={size - 2} stroke={2.4}/>
  </span>
);

// Willow mark (small)
const MMark = ({ size = 20, color = 'var(--willow)' }) => (
  <svg width={size} height={size} viewBox="0 0 32 32">
    <circle cx="16" cy="16" r="15" fill="none" stroke={color} strokeOpacity="0.35"/>
    <path d="M16 5 C16 9 16 12 16 14" stroke={color} strokeWidth="1.4" strokeLinecap="round" fill="none"/>
    <path d="M16 13 C12 15 9 19 8 26" stroke={color} strokeWidth="1.3" strokeLinecap="round" fill="none"/>
    <path d="M16 13 C17 17 17 22 16 27" stroke={color} strokeWidth="1.3" strokeLinecap="round" fill="none"/>
    <path d="M16 13 C20 15 23 19 24 26" stroke={color} strokeWidth="1.3" strokeLinecap="round" fill="none"/>
  </svg>
);

const MWordmark = ({ size = 18 }) => (
  <span style={{ display: 'inline-flex', alignItems: 'baseline', gap: 6 }}>
    <span style={{ transform: 'translateY(3px)' }}><MMark size={size * 1.05}/></span>
    <span style={{
      fontFamily: 'var(--font-display)', fontWeight: 400, fontStyle: 'italic',
      fontSize: size, color: 'var(--ink-0)',
    }}>willow</span>
  </span>
);

// ---- Mobile nav bars ----

const MTopBar = ({ left, title, subtitle, right, platform = 'ios', onTap, compact, style }) => (
  <div onClick={onTap} style={{
    padding: compact ? '8px 12px' : platform === 'ios' ? '10px 14px' : '10px 12px',
    display: 'flex', alignItems: 'center', gap: 10,
    background: 'var(--bg-1)', borderBottom: '1px solid var(--line-soft)',
    minHeight: 52, flexShrink: 0, ...style,
  }}>
    {left}
    <div style={{ flex: 1, minWidth: 0 }}>
      {typeof title === 'string' ? (
        <div style={{
          fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 500,
          fontSize: 17, color: 'var(--ink-0)', lineHeight: 1.2,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>{title}</div>
      ) : title}
      {subtitle && <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{subtitle}</div>}
    </div>
    {right}
  </div>
);

const MTabBar = ({ tabs, active, onChange, platform = 'ios' }) => (
  <div style={{
    background: platform === 'ios' ? 'color-mix(in oklab, var(--bg-1) 85%, transparent)' : 'var(--bg-1)',
    backdropFilter: platform === 'ios' ? 'blur(16px)' : 'none',
    borderTop: '1px solid var(--line-soft)',
    padding: platform === 'ios' ? '8px 8px 6px' : '4px 8px',
    display: 'flex', justifyContent: 'space-around', flexShrink: 0,
  }}>
    {tabs.map(t => {
      const Ic = t.icon;
      const act = t.id === active;
      return (
        <button key={t.id} onClick={() => onChange(t.id)} style={{
          flex: 1, padding: platform === 'ios' ? '4px 6px 2px' : '6px 6px',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
          color: act ? 'var(--moss-3)' : 'var(--ink-3)',
          position: 'relative',
        }}>
          {act && platform === 'android' && (
            <span style={{
              position: 'absolute', top: 2, width: 54, height: 28,
              background: 'color-mix(in oklab, var(--moss-2) 22%, transparent)',
              borderRadius: 14, zIndex: 0,
            }}/>
          )}
          <span style={{ position: 'relative', zIndex: 1 }}>
            <Ic size={platform === 'ios' ? 22 : 20} stroke={act ? 1.8 : 1.5}/>
          </span>
          <span style={{
            position: 'relative', zIndex: 1,
            fontSize: platform === 'ios' ? 10 : 11,
            fontWeight: act ? 500 : 400,
            letterSpacing: 0.1,
          }}>{t.label}</span>
          {t.badge && (
            <span style={{
              position: 'absolute', top: 0, right: '25%',
              minWidth: 14, height: 14, padding: '0 4px', borderRadius: 7,
              background: 'var(--err)', color: '#14130f',
              fontSize: 9, fontWeight: 600,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            }}>{t.badge}</span>
          )}
        </button>
      );
    })}
  </div>
);

// ---- Screen scaffold ----
// A full-height column with optional top bar, scrollable body, and optional bottom element (tab bar or composer).
const MScreen = ({ children, style }) => (
  <div style={{
    height: '100%', display: 'flex', flexDirection: 'column',
    background: 'var(--bg-1)', position: 'relative', ...style,
  }}>{children}</div>
);

const MBody = ({ children, style, onScroll, innerRef, pad }) => (
  <div ref={innerRef} onScroll={onScroll} className="scroll" style={{
    flex: 1, overflowY: 'auto', overflowX: 'hidden',
    padding: pad ?? 0, ...style,
  }}>{children}</div>
);

// Swipe-hint wrapper: listens for horizontal drag, calls onSwipe(dx) and onRelease
const useSwipe = (onRelease, threshold = 60) => {
  const stateRef = useRef({ startX: 0, startY: 0, dx: 0, active: false });
  const [dx, setDx] = useState(0);
  const onTouchStart = (e) => {
    const t = e.touches[0];
    stateRef.current = { startX: t.clientX, startY: t.clientY, dx: 0, active: true };
  };
  const onTouchMove = (e) => {
    if (!stateRef.current.active) return;
    const t = e.touches[0];
    const ddx = t.clientX - stateRef.current.startX;
    const ddy = t.clientY - stateRef.current.startY;
    if (Math.abs(ddy) > Math.abs(ddx) * 1.2) { stateRef.current.active = false; setDx(0); return; }
    stateRef.current.dx = ddx;
    setDx(ddx);
  };
  const onTouchEnd = () => {
    if (!stateRef.current.active) return;
    const d = stateRef.current.dx;
    stateRef.current.active = false;
    setDx(0);
    if (Math.abs(d) > threshold) onRelease?.(d > 0 ? 1 : -1);
  };
  return { dx, handlers: { onTouchStart, onTouchMove, onTouchEnd } };
};

// Long-press hook — for SAS verify long-press etc.
const useLongPress = (onLong, ms = 700) => {
  const tRef = useRef(null);
  const [progress, setProgress] = useState(0);
  const start = () => {
    const t0 = performance.now();
    const tick = () => {
      const p = Math.min(1, (performance.now() - t0) / ms);
      setProgress(p);
      if (p < 1) tRef.current = requestAnimationFrame(tick);
      else { onLong?.(); setTimeout(() => setProgress(0), 600); }
    };
    tRef.current = requestAnimationFrame(tick);
  };
  const cancel = () => {
    if (tRef.current) cancelAnimationFrame(tRef.current);
    tRef.current = null; setProgress(0);
  };
  return {
    progress,
    handlers: {
      onMouseDown: start, onMouseUp: cancel, onMouseLeave: cancel,
      onTouchStart: start, onTouchEnd: cancel, onTouchCancel: cancel,
    },
  };
};

Object.assign(window, {
  MobileFrame, NotchBar, HomeIndicator,
  MAvatar, MPeerName, MDot, MTag, MVerified, MMark, MWordmark,
  MTopBar, MTabBar, MScreen, MBody,
  useSwipe, useLongPress,
});
