// Thread view — full screen modal on mobile (unlike desktop's side panel).

const ThreadScreen = ({ platform, parent, onBack }) => {
  const p = parent ?? MESSAGES.find(m => m.id === 'm5');
  const pu = p ? PEOPLE_BY_ID[p.from] : null;
  return (
    <MScreen>
      <MTopBar platform={platform}
        left={
          <button onClick={onBack} style={{ padding: 6, color: 'var(--ink-1)' }}>
            <Icons.Chevron size={20} stroke={1.8} style={{ transform: 'rotate(180deg)' }}/>
          </button>
        }
        title={
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icons.Thread size={14} stroke={1.6}/>
            <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 15, color: 'var(--ink-0)' }}>thread</span>
          </div>
        }
        subtitle={THREAD_COPY.fromLabel('meander', THREAD_MESSAGES.length)}
        right={<button style={{ padding: 8, color: 'var(--ink-2)' }}><Icons.More size={18}/></button>}
      />
      <MBody>
        <ThreadParentCard parent={p} AvatarComponent={MAvatar} size="sm"/>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '0 16px 10px' }}>
          <div style={{ flex: 1, height: 1, background: 'var(--line)' }}/>
          <span style={{ fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.2,
            fontFamily: 'var(--font-display)', fontStyle: 'italic' }}>— replies —</span>
          <div style={{ flex: 1, height: 1, background: 'var(--line)' }}/>
        </div>
        <ThreadReplyList replies={THREAD_MESSAGES} AvatarComponent={MAvatar} size="sm"/>
        <div style={{ height: 20 }}/>
      </MBody>
      <div style={{ padding: '8px 10px 10px', background: 'var(--bg-1)', borderTop: '1px solid var(--line-soft)' }}>
        <div style={{
          background: 'var(--bg-2)', borderRadius: 20, border: '1px solid var(--line)',
          padding: '6px 8px 6px 12px', display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <Icons.Thread size={14} stroke={1.6}/>
          <input placeholder={THREAD_COPY.composePlaceholder} style={{
            flex: 1, background: 'transparent', border: 'none', outline: 'none',
            fontSize: 13.5, color: 'var(--ink-0)', padding: '6px 4px',
          }}/>
          <button style={{
            width: 32, height: 32, borderRadius: '50%',
            background: 'var(--moss-2)', color: '#14130f',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          }}><Icons.Send size={14} stroke={2}/></button>
        </div>
        <div style={{ fontSize: 10, color: 'var(--ink-3)', marginTop: 6, textAlign: 'center' }}>
          <Icons.Lock size={9} stroke={1.6}/> {THREAD_COPY.sealedFooter(5)}
        </div>
      </div>
    </MScreen>
  );
};

window.ThreadScreen = ThreadScreen;
