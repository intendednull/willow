// Channel chat screen — the main messaging view.
// Features: swipe-right on a message to start/open a thread, pull-down for sync queue, whisper styling.

const { useState: useS_chat, useRef: useR_chat, useEffect: useE_chat } = React;

// A single message, with swipe-to-thread gesture.
const MobileMessage = ({ m, prev, onOpenThread, showSwipeHint }) => {
  if (m.kind === 'sep') return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, margin: '16px 16px 8px' }}>
      <div style={{ flex: 1, height: 1, background: 'var(--line)' }}/>
      <span style={{ fontSize: 10, color: 'var(--ink-3)', letterSpacing: 1.4, textTransform: 'uppercase',
        fontFamily: 'var(--font-display)', fontStyle: 'italic' }}>— {m.label} —</span>
      <div style={{ flex: 1, height: 1, background: 'var(--line)' }}/>
    </div>
  );
  const u = PEOPLE_BY_ID[m.from];
  const compact = prev && prev.from === m.from && prev.kind !== 'sep' && !m.whisper && !m.queueNote && !m.pin;
  const mentionsMe = messageMentionsMe(m);

  const [dx, setDx] = useS_chat(0);
  const startRef = useR_chat({ x: 0, y: 0, active: false });
  const onTouchStart = (e) => {
    const t = e.touches[0];
    startRef.current = { x: t.clientX, y: t.clientY, active: true };
  };
  const onTouchMove = (e) => {
    if (!startRef.current.active) return;
    const t = e.touches[0];
    const ddx = t.clientX - startRef.current.x;
    const ddy = t.clientY - startRef.current.y;
    if (Math.abs(ddy) > Math.abs(ddx) * 1.2) { startRef.current.active = false; setDx(0); return; }
    if (ddx > 0) setDx(Math.min(100, ddx));
  };
  const onTouchEnd = () => {
    if (!startRef.current.active) return;
    const d = dx; startRef.current.active = false; setDx(0);
    if (d > 60) onOpenThread?.(m);
  };

  const revealed = Math.min(1, dx / 60);

  return (
    <div style={{ position: 'relative' }}>
      {/* Thread-swipe reveal backing */}
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', alignItems: 'center', padding: '0 16px',
        color: 'var(--moss-3)', pointerEvents: 'none',
        opacity: revealed,
      }}>
        <Icons.Thread size={18} stroke={1.8}/>
        <span style={{ marginLeft: 8, fontSize: 12, fontFamily: 'var(--font-display)', fontStyle: 'italic' }}>
          open thread
        </span>
      </div>
      <div
        onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}
        style={{
          transform: `translateX(${dx}px)`,
          transition: dx === 0 ? 'transform 200ms ease-out' : 'none',
          display: 'flex', gap: 10,
          padding: compact ? '1px 14px' : '6px 14px',
          marginTop: compact ? 0 : 3,
          background: 'var(--bg-1)',
          ...mentionHighlightStyle(mentionsMe),
        }}
      >
        <div style={{ width: 32, flexShrink: 0, paddingTop: 2 }}>
          {!compact && <MAvatar user={u} size={30}/>}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          {!compact && (
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 1, flexWrap: 'wrap' }}>
              <MPeerName user={u} style={{ fontFamily: 'var(--font-display)', fontSize: 14, color: 'var(--ink-0)', fontWeight: 500 }}>
                {u.name}
              </MPeerName>
              {u.verified && <MVerified size={9}/>}
              <span style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>{m.t}</span>
              {m.pin && <PinBadge compact/>}
              {m.whisper && <WhisperBadge compact/>}
              {m.queueNote && <QueuedBadge compact/>}
            </div>
          )}
          <div style={{
            fontSize: 14, color: m.whisper ? 'var(--ink-2)' : 'var(--ink-1)',
            fontStyle: m.whisper ? 'italic' : 'normal', lineHeight: 1.45,
            wordBreak: 'break-word',
          }}><MessageBody body={m.body}/></div>
          {m.img && (
            <div style={{ marginTop: 6, borderRadius: 12, overflow: 'hidden', maxWidth: 280, border: '1px solid var(--line)' }}>
              <LeafPlaceholder w={280} h={160} seed={(parseInt(m.id.replace(/\D/g,''),10) || 0) + 1}/>
            </div>
          )}
          {m.code && (
            <pre style={{
              marginTop: 6, padding: '6px 10px', background: 'var(--bg-0)',
              border: '1px solid var(--line)', borderRadius: 8,
              fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-2)',
              overflow: 'auto', whiteSpace: 'pre-wrap', margin: '6px 0 0',
            }}>{m.code}</pre>
          )}
          {m.reactions && <ReactionList list={m.reactions} compact showAdd={false}/>}
          {m.thread && (
            <button onClick={() => onOpenThread?.(m)} style={{
              marginTop: 6, display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '5px 9px', borderRadius: 8, background: 'var(--bg-2)',
              border: '1px solid var(--line)', color: 'var(--moss-3)', fontSize: 11.5,
            }}>
              <Icons.Thread size={11}/>
              <span>{m.thread.count} replies</span>
              <span style={{ color: 'var(--ink-3)' }}>· last {m.thread.lastAt}</span>
              <Icons.Chevron size={10} stroke={1.8}/>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

// The sync queue pull-down — visible when user pulls the list down from the top.
const SyncPullBanner = ({ pull }) => {
  const p = Math.min(1, pull / 80);
  return (
    <div style={{
      position: 'absolute', top: 0, left: 0, right: 0,
      height: pull, overflow: 'hidden',
      background: `linear-gradient(180deg, color-mix(in oklab, var(--moss-1) ${20*p}%, var(--bg-0)), var(--bg-1))`,
      display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      padding: '0 0 10px',
      pointerEvents: 'none',
    }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8,
          fontSize: 11, color: 'var(--moss-3)', fontFamily: 'var(--font-mono)' }}>
          <Icons.Signal size={12} stroke={1.8}/>
          {p < 1 ? 'pull to show offline queue' : 'release · sync queue'}
        </div>
        <div style={{ fontSize: 10, color: 'var(--ink-3)', marginTop: 2 }}>
          3 messages queued · 2 peers reachable
        </div>
      </div>
    </div>
  );
};

const Composer = ({ channel, platform, onOpenWhisper }) => (
  <div style={{ padding: '8px 10px 10px', background: 'var(--bg-1)',
    borderTop: '1px solid var(--line-soft)' }}>
    <div style={{
      background: 'var(--bg-2)', borderRadius: 22, border: '1px solid var(--line)',
      padding: '6px 8px 6px 12px', display: 'flex', alignItems: 'center', gap: 6,
    }}>
      <button style={{ color: 'var(--ink-2)', padding: 6 }}><Icons.Plus size={18} stroke={1.8}/></button>
      <input
        placeholder={`message #${channel.name}`}
        style={{
          flex: 1, background: 'transparent', border: 'none', outline: 'none',
          fontSize: 14, color: 'var(--ink-0)', padding: '6px 4px',
        }}
      />
      <button onClick={onOpenWhisper} style={{ color: 'var(--whisper)', padding: 6 }}>
        <Icons.Ear size={18} stroke={1.6}/>
      </button>
      <button style={{
        width: 34, height: 34, borderRadius: '50%',
        background: 'var(--moss-2)', color: '#14130f',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      }}><Icons.Send size={15} stroke={2}/></button>
    </div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6, padding: '0 4px',
      fontSize: 10.5, color: 'var(--ink-3)' }}>
      <Icons.Lock size={9} stroke={1.6}/>
      <span>sealed to 7 peers in grove</span>
      <span style={{ color: 'var(--ink-4)' }}>·</span>
      <Icons.Ear size={9} stroke={1.6} style={{ color: 'var(--whisper)' }}/>
      <span>tap <span style={{ color: 'var(--whisper)' }}>ear</span> to whisper</span>
    </div>
  </div>
);

const ChatScreen = ({ platform, grove, channel, onBack, onOpenThread, onOpenMembers, onOpenCall, onOpenWhisper }) => {
  const bodyRef = useR_chat(null);
  const [pull, setPull] = useS_chat(0);
  const pullRef = useR_chat({ startY: 0, atTop: false, active: false });

  const onTouchStart = (e) => {
    const el = bodyRef.current;
    if (!el) return;
    pullRef.current = { startY: e.touches[0].clientY, atTop: el.scrollTop <= 0, active: true };
  };
  const onTouchMove = (e) => {
    const s = pullRef.current;
    if (!s.active || !s.atTop) return;
    const dy = e.touches[0].clientY - s.startY;
    if (dy > 0) setPull(Math.min(120, dy * 0.6));
  };
  const onTouchEnd = () => { pullRef.current.active = false; setPull(0); };

  return (
    <MScreen>
      <MTopBar platform={platform}
        left={
          <button onClick={onBack} style={{ padding: 6, color: 'var(--ink-1)' }}>
            <Icons.Chevron size={20} stroke={1.8} style={{ transform: 'rotate(180deg)' }}/>
          </button>
        }
        title={
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icons.Hash size={14} stroke={1.6}/>
            <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 16, color: 'var(--ink-0)' }}>
              {channel.name}
            </span>
          </div>
        }
        subtitle={
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Icons.Lock size={9} stroke={1.6}/>
            <span>7 holders · sealed</span>
          </span>
        }
        right={
          <div style={{ display: 'flex', gap: 2 }}>
            <button onClick={onOpenCall} style={{ padding: 8, color: 'var(--ink-2)' }}><Icons.Phone size={18}/></button>
            <button onClick={onOpenMembers} style={{ padding: 8, color: 'var(--ink-2)' }}><Icons.Users size={18}/></button>
          </div>
        }
      />
      <div style={{ position: 'relative', flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <SyncPullBanner pull={pull}/>
        <div
          ref={bodyRef}
          onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}
          className="scroll"
          style={{
            flex: 1, overflowY: 'auto', overflowX: 'hidden',
            paddingTop: 10, paddingBottom: 10,
            transform: `translateY(${pull}px)`,
            transition: pull === 0 ? 'transform 220ms ease-out' : 'none',
            background: 'var(--bg-1)',
          }}
        >
          {/* Channel preamble */}
          <div style={{ padding: '6px 16px 14px', textAlign: 'left', borderBottom: '1px dashed var(--line)', marginBottom: 6 }}>
            <div style={{
              width: 44, height: 44, borderRadius: 12, background: 'var(--bg-2)',
              border: '1px solid var(--line)', color: 'var(--willow)',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icons.Hash size={20} stroke={1.4}/>
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 22, color: 'var(--ink-0)', marginTop: 8 }}>
              welcome to #{channel.name}
            </div>
            <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 4, lineHeight: 1.5 }}>
              {channel.topic ?? 'general chatter'} · messages sealed to everyone in the grove, stored on each device.
            </div>
          </div>
          {MESSAGES.map((m, i) => (
            <MobileMessage key={m.id} m={m} prev={MESSAGES[i-1]} onOpenThread={onOpenThread}/>
          ))}
          <div style={{ padding: '8px 14px', color: 'var(--ink-3)', fontSize: 11,
            display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ display: 'inline-flex', gap: 3 }}>
              {[0,1,2].map(i => (
                <span key={i} style={{
                  width: 4, height: 4, borderRadius: '50%', background: 'var(--ink-3)',
                  animation: `willowPulse 1200ms ${i * 200}ms infinite ease-in-out`,
                }}/>
              ))}
            </span>
            <span style={{ fontStyle: 'italic', fontFamily: 'var(--font-display)' }}>ori is writing…</span>
          </div>
        </div>
      </div>
      <Composer channel={channel} platform={platform} onOpenWhisper={onOpenWhisper}/>
    </MScreen>
  );
};

Object.assign(window, { ChatScreen, MobileMessage });
