// Main mobile app — routes between screens, renders iOS + Android frames side by side,
// provides the Tweaks panel, variation switcher.

const { useState: useSA, useEffect: useEA, useMemo: useMA } = React;

// ---- Tweaks state ----
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "moss",
  "variation": "all",
  "showBoth": true,
  "iosDark": true,
  "androidDark": true
}/*EDITMODE-END*/;

const ACCENTS = {
  moss:   { willow: '#b8c67a', moss2: '#6a8d5e', moss3: '#93b582', label: 'moss' },
  cedar:  { willow: '#d0a878', moss2: '#a47848', moss3: '#c99b55', label: 'cedar' },
  lichen: { willow: '#89b6a5', moss2: '#5a9580', moss3: '#86c1ae', label: 'lichen' },
  ember:  { willow: '#d48a6a', moss2: '#b5644a', moss3: '#d98a68', label: 'ember' },
};

// Variation screens — for single-screen deep-dives
const VARIATIONS = [
  { id: 'all',         label: 'tour'        },
  { id: 'home',        label: 'home · channels' },
  { id: 'chat',        label: 'channel chat' },
  { id: 'thread',      label: 'thread'      },
  { id: 'call',        label: 'call'        },
  { id: 'dms',         label: 'letters'     },
  { id: 'onboarding',  label: 'onboarding'  },
  { id: 'settings',    label: 'settings'    },
  { id: 'discovery',   label: 'discover'    },
  { id: 'ephemeral',   label: 'ephemeral'   },
  { id: 'sync',        label: 'sync queue'  },
];

// What each variation shows in its phone window
const variationToScreen = (v, platform, nav) => {
  const grove = GROVES[0];
  const channelGroups = CHANNEL_GROUPS[grove.id];
  const currentChannel = channelGroups?.[0]?.channels?.[0] ?? { id:'c1', name:'meander', topic:'general chatter' };
  switch (v) {
    case 'home':        return <HomeScreen platform={platform} grove={grove} channels={channelGroups}
                                 onOpenChannel={()=>{}} onOpenGroveList={()=>{}} onOpenSearch={()=>{}}/>;
    case 'chat':        return <ChatScreen platform={platform} grove={grove} channel={currentChannel}
                                 onBack={()=>{}} onOpenThread={()=>{}} onOpenMembers={()=>{}}
                                 onOpenCall={()=>{}} onOpenWhisper={()=>{}}/>;
    case 'thread':      return <ThreadScreen platform={platform} parent={MESSAGES.find(m=>m.id==='m5')} onBack={()=>{}}/>;
    case 'call':        return <CallScreen platform={platform} channel={{ name:'the-porch' }} onHangup={()=>{}}/>;
    case 'dms':         return <DMListScreen platform={platform} onBack={()=>{}} onOpen={()=>{}}/>;
    case 'onboarding':  return <OnboardingScreen platform={platform} onDone={()=>{}}/>;
    case 'settings':    return <SettingsScreen platform={platform} onBack={()=>{}}/>;
    case 'discovery':   return <DiscoveryScreen platform={platform} onBack={()=>{}}/>;
    case 'ephemeral':   return <EphemeralScreen platform={platform} onBack={()=>{}}/>;
    case 'sync':        return <SyncQueueScreen platform={platform} onBack={()=>{}}/>;
    default:            return null;
  }
};

// "tour" is a mini-router living inside each frame — tap through the app.
const TourPhone = ({ platform }) => {
  const [route, setRoute] = useSA({ name: 'home' });
  const [drawer, setDrawer] = useSA(false);
  const grove = GROVES[0];
  const channelGroups = CHANNEL_GROUPS[grove.id];

  const go = (name, data) => setRoute({ name, data });

  let screen;
  switch (route.name) {
    case 'home':
      screen = <HomeScreen platform={platform} grove={grove} channels={channelGroups}
                 onOpenChannel={(ch) => go('chat', { channel: ch })}
                 onOpenGroveList={() => setDrawer(true)}
                 onOpenSearch={() => go('discovery')}/>;
      break;
    case 'chat':
      screen = <ChatScreen platform={platform} grove={grove} channel={route.data?.channel ?? channelGroups[0].channels[0]}
                 onBack={() => go('home')}
                 onOpenThread={(m) => go('thread', { parent: m })}
                 onOpenMembers={() => go('settings')}
                 onOpenCall={() => go('call', { channel: { name:'the-porch' } })}
                 onOpenWhisper={() => go('call', { channel: { name:'the-porch' } })}/>;
      break;
    case 'thread':
      screen = <ThreadScreen platform={platform} parent={route.data?.parent} onBack={() => go('chat')}/>;
      break;
    case 'call':
      screen = <CallScreen platform={platform} channel={route.data?.channel ?? { name:'the-porch' }}
                 onHangup={() => go('home')}/>;
      break;
    case 'dms':
      screen = <DMListScreen platform={platform}
                 onOpen={(dm) => go('dm', { dm })} onBack={() => go('home')}/>;
      break;
    case 'dm':
      screen = <DMThreadScreen platform={platform} dm={route.data?.dm} onBack={() => go('dms')}/>;
      break;
    case 'onboarding':
      screen = <OnboardingScreen platform={platform} onDone={() => go('home')}/>;
      break;
    case 'settings':
      screen = <SettingsScreen platform={platform} onBack={() => go('home')}/>;
      break;
    case 'discovery':
      screen = <DiscoveryScreen platform={platform} onBack={() => go('home')}/>;
      break;
    case 'ephemeral':
      screen = <EphemeralScreen platform={platform} onBack={() => go('home')}/>;
      break;
    case 'sync':
      screen = <SyncQueueScreen platform={platform} onBack={() => go('home')}/>;
      break;
    default:
      screen = null;
  }

  const tabs = [
    { id: 'home',       label: 'groves',    icon: Icons.Hash,        badge: null },
    { id: 'dms',        label: 'letters',   icon: Icons.Thread,      badge: 3 },
    { id: 'discovery',  label: 'discover',  icon: Icons.Compass,     badge: null },
    { id: 'settings',   label: 'you',       icon: Icons.User,        badge: null },
  ];
  const activeTab = ['home','dms','discovery','settings'].includes(route.name) ? route.name : 'home';
  const showTabs = ['home','dms','discovery','settings'].includes(route.name);

  return (
    <MScreen>
      <div style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', position: 'relative' }}>
        {screen}
        <GroveDrawer open={drawer} onClose={() => setDrawer(false)}
          groves={GROVES} currentId={grove.id}
          onSelect={() => setDrawer(false)}
          onDiscover={() => { setDrawer(false); go('discovery'); }}/>
        <ProfileSheetHost/>
      </div>
      {showTabs && (
        <MTabBar platform={platform} tabs={tabs} active={activeTab} onChange={(id) => go(id)}/>
      )}
    </MScreen>
  );
};

// ---- Frame with label & screen content ----
const LabeledPhone = ({ platform, label, variation }) => (
  <MobileFrame platform={platform} label={label}>
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', position: 'relative' }}>
      {variation === 'all'
        ? <TourPhone platform={platform}/>
        : variationToScreen(variation, platform)}
      {variation !== 'all' && <ProfileSheetHost/>}
    </div>
  </MobileFrame>
);

// ---- Tweaks panel ----
const TweaksPanel = ({ open, values, setValue }) => {
  if (!open) return null;
  return (
    <div style={{
      position: 'fixed', right: 20, bottom: 20, zIndex: 50,
      width: 300, background: 'var(--bg-1)',
      border: '1px solid var(--line)', borderRadius: 14,
      boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
      fontFamily: 'var(--font-ui)', color: 'var(--ink-1)',
    }}>
      <div style={{ padding: '12px 14px', borderBottom: '1px solid var(--line)' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 16, color: 'var(--ink-0)' }}>
          Tweaks
        </div>
        <div style={{ fontSize: 10.5, color: 'var(--ink-3)', marginTop: 2 }}>accent · variation · layout</div>
      </div>
      <div style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div>
          <div style={{ fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: 6 }}>accent</div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {Object.entries(ACCENTS).map(([k, a]) => (
              <button key={k} onClick={() => setValue('accent', k)} style={{
                padding: '6px 10px', borderRadius: 999, fontSize: 11.5,
                background: values.accent === k ? a.moss2 : 'var(--bg-2)',
                color: values.accent === k ? '#14130f' : 'var(--ink-1)',
                border: `1px solid ${values.accent === k ? a.moss2 : 'var(--line)'}`,
                display: 'inline-flex', alignItems: 'center', gap: 6,
              }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: a.willow }}/>
                {a.label}
              </button>
            ))}
          </div>
        </div>
        <div>
          <div style={{ fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: 6 }}>variation</div>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            {VARIATIONS.map(v => (
              <button key={v.id} onClick={() => setValue('variation', v.id)} style={{
                padding: '5px 9px', borderRadius: 7, fontSize: 11,
                background: values.variation === v.id ? 'var(--bg-3)' : 'var(--bg-2)',
                color: values.variation === v.id ? 'var(--ink-0)' : 'var(--ink-2)',
                border: '1px solid var(--line)',
              }}>{v.label}</button>
            ))}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <label style={{ fontSize: 11.5, color: 'var(--ink-2)', display: 'inline-flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
            <input type="checkbox" checked={values.showBoth} onChange={e => setValue('showBoth', e.target.checked)}/>
            show both platforms
          </label>
        </div>
        <div style={{ fontSize: 10.5, color: 'var(--ink-3)', lineHeight: 1.5,
          padding: '8px 10px', background: 'var(--bg-2)', borderRadius: 8, border: '1px solid var(--line)' }}>
          <Icons.Hash size={10}/> tip: tap around inside the phone — it's fully interactive
        </div>
      </div>
    </div>
  );
};

// ---- Gallery header ----
const Header = ({ tweaks, setValue }) => (
  <div style={{
    maxWidth: 1800, margin: '0 auto', padding: '32px 36px 10px',
    display: 'flex', alignItems: 'flex-end', gap: 18, flexWrap: 'wrap',
  }}>
    <div style={{ flex: 1, minWidth: 300 }}>
      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 11.5,
        color: 'var(--moss-3)', fontFamily: 'var(--font-mono)', marginBottom: 6 }}>
        <Icons.Lock size={11}/> mobile · p2p · encrypted
      </div>
      <h1 style={{
        fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 400,
        fontSize: 54, lineHeight: 1, color: 'var(--ink-0)', margin: 0, letterSpacing: -0.5,
      }}>
        willow <span style={{ color: 'var(--ink-3)' }}>on the phone</span>
      </h1>
      <p style={{ fontSize: 14.5, color: 'var(--ink-2)', maxWidth: 620, lineHeight: 1.55, marginTop: 10 }}>
        small group chat on your device. groves and channels, threads, voice with screen-sharing, whispered side-channels,
        ephemeral rooms, and a sync queue that waits patiently for peers.
      </p>
    </div>
    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', maxWidth: 560 }}>
      {VARIATIONS.slice(0, 7).map(v => (
        <button key={v.id} onClick={() => setValue('variation', v.id)} style={{
          padding: '7px 11px', borderRadius: 999, fontSize: 11.5,
          background: tweaks.variation === v.id ? 'var(--bg-3)' : 'transparent',
          color: tweaks.variation === v.id ? 'var(--ink-0)' : 'var(--ink-2)',
          border: `1px solid ${tweaks.variation === v.id ? 'var(--line)' : 'var(--line-soft)'}`,
        }}>{v.label}</button>
      ))}
    </div>
  </div>
);

// ---- Root ----
const App = () => {
  const [tweaks, setTweaks] = useSA(TWEAK_DEFAULTS);
  const [tweaksOpen, setTweaksOpen] = useSA(false);

  const setValue = (k, v) => {
    const next = { ...tweaks, [k]: v };
    setTweaks(next);
    window.parent?.postMessage({ type: '__edit_mode_set_keys', edits: { [k]: v } }, '*');
  };

  // Tweaks mode protocol
  useEA(() => {
    const onMsg = (e) => {
      const d = e.data;
      if (!d || typeof d !== 'object') return;
      if (d.type === '__activate_edit_mode') setTweaksOpen(true);
      else if (d.type === '__deactivate_edit_mode') setTweaksOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent?.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  // Apply accent tweak via CSS variables at root
  useEA(() => {
    const a = ACCENTS[tweaks.accent] ?? ACCENTS.moss;
    const r = document.documentElement;
    r.style.setProperty('--willow', a.willow);
    r.style.setProperty('--moss-2', a.moss2);
    r.style.setProperty('--moss-3', a.moss3);
  }, [tweaks.accent]);

  const variation = tweaks.variation ?? 'all';
  const showBoth = tweaks.showBoth !== false;

  return (
    <div style={{ minHeight: '100vh', paddingBottom: 80 }}>
      <Header tweaks={tweaks} setValue={setValue}/>

      <div style={{
        maxWidth: 1800, margin: '0 auto', padding: '18px 36px 40px',
        display: 'flex', gap: 56, alignItems: 'flex-start', justifyContent: 'center', flexWrap: 'wrap',
      }}>
        <div data-screen-label="iOS · Willow">
          <LabeledPhone platform="ios" label="iPhone · iOS" variation={variation}/>
        </div>
        {showBoth && (
          <div data-screen-label="Android · Willow">
            <LabeledPhone platform="android" label="Pixel · Android" variation={variation}/>
          </div>
        )}
      </div>

      {/* bottom context strip */}
      <div style={{
        maxWidth: 1100, margin: '10px auto 0', padding: '18px 28px',
        background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 16,
        display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 18,
      }}>
        {[
          { i: Icons.Lock,     t: 'sealed by default',     b: 'every grove has its own keys, held on each device.' },
          { i: Icons.Ear,      t: 'whispers',              b: 'inside a call or channel, carve out a private side-channel with its own key.' },
          { i: Icons.Hourglass,t: 'ephemeral',             b: 'channels that self-destruct — keys burned when the timer ends.' },
          { i: Icons.Signal,   t: 'patient sync',          b: 'messages wait on your device until a peer is reachable. nothing is stored server-side.' },
        ].map((c, i) => {
          const Ic = c.i;
          return (
            <div key={i}>
              <div style={{ color: 'var(--moss-3)' }}><Ic size={16} stroke={1.6}/></div>
              <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 14,
                color: 'var(--ink-0)', marginTop: 6 }}>{c.t}</div>
              <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 3, lineHeight: 1.5 }}>{c.b}</div>
            </div>
          );
        })}
      </div>

      <TweaksPanel open={tweaksOpen} values={tweaks} setValue={setValue}/>
    </div>
  );
};

const root = ReactDOM.createRoot(document.getElementById('app-root'));
root.render(<App/>);
