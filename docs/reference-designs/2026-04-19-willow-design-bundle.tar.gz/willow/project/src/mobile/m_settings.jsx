// Settings — encryption, devices, peers.

const SettingsScreen = ({ platform, onBack }) => (
  <MScreen>
    <MTopBar platform={platform}
      left={<button onClick={onBack} style={{ padding: 6, color: 'var(--ink-1)' }}><Icons.Chevron size={20} style={{ transform: 'rotate(180deg)' }}/></button>}
      title="settings"
      subtitle="you · willow·phone"
    />
    <MBody>
      {/* profile card */}
      <div style={{ padding: '18px 16px 14px', display: 'flex', alignItems: 'center', gap: 12,
        borderBottom: '1px solid var(--line-soft)' }}>
        <MAvatar user={PEOPLE_BY_ID['u9']} size={52}/>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 19, color: 'var(--ink-0)' }}>you</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-3)' }}>you · willow·phone</div>
          <div style={{ marginTop: 4, display: 'inline-flex', alignItems: 'center', gap: 4,
            fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--moss-3)' }}>
            <Icons.Fingerprint size={10}/> willow · copper · reed
          </div>
        </div>
      </div>

      <SectionHeader label="encryption"/>
      <SRow icon={<Icons.Key size={14}/>} title="your keys" detail="created 14 feb · rotated 2d ago"/>
      <SRow icon={<Icons.Fingerprint size={14}/>} title="your fingerprint" detail="6-word code"/>
      <SRow icon={<Icons.Shield size={14}/>} title="per-channel crypto" detail="grove · thread · whisper"/>

      <SectionHeader label="devices"/>
      <div style={{ padding: '4px 0' }}>
        {[
          { n: 'willow · phone', here: true, meta: 'this device · last key rotation 2d' },
          { n: 'willow · desk', here: false, meta: 'online · ethernet' },
          { n: 'willow · cabin', here: false, meta: 'last seen 3m ago · wifi' },
        ].map(d => (
          <div key={d.n} style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '12px 16px', borderBottom: '1px solid var(--line-soft)',
          }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: 'var(--bg-2)',
              color: 'var(--moss-3)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icons.Device size={15}/>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12.5, color: 'var(--ink-0)' }}>{d.n}</div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{d.meta}</div>
            </div>
            {d.here ? <MTag mono color="var(--moss-3)" border="var(--line)">here</MTag>
                   : <Icons.Chevron size={12} stroke={1.8} style={{ color: 'var(--ink-3)' }}/>}
          </div>
        ))}
        <button style={{
          width: '100%', padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10,
          color: 'var(--moss-3)', fontSize: 13.5, textAlign: 'left',
        }}>
          <Icons.Plus size={14}/> add a device
        </button>
      </div>

      <SectionHeader label="peers & relays"/>
      <SRow icon={<Icons.Users size={14}/>} title="verified peers" detail="5 / 8"/>
      <SRow icon={<Icons.Globe size={14}/>} title="relays" detail="3 known · relay-3 active"/>
      <SRow icon={<Icons.Signal size={14}/>} title="connection" detail="direct p2p · 2 · relay · 3"/>

      <SectionHeader label="quiet"/>
      <SRow icon={<Icons.Ghost size={14}/>} title="ephemeral by default" detail="new channels self-destruct"
        right={<Toggle on/>}/>
      <SRow icon={<Icons.Bell size={14}/>} title="notifications" detail="only from verified peers"/>

      <div style={{ padding: '20px 16px 26px', textAlign: 'center', color: 'var(--ink-3)', fontSize: 11 }}>
        willow · 0.4 · peer-to-peer · no server knows your plaintext
      </div>
    </MBody>
  </MScreen>
);

const SRow = ({ icon, title, detail, right }) => (
  <div style={{
    display: 'flex', alignItems: 'center', gap: 12,
    padding: '12px 16px', borderBottom: '1px solid var(--line-soft)', minHeight: 56,
  }}>
    <div style={{ width: 30, height: 30, borderRadius: 8, background: 'var(--bg-2)',
      color: 'var(--moss-3)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
      {icon}
    </div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 14, color: 'var(--ink-0)' }}>{title}</div>
      {detail && <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 1 }}>{detail}</div>}
    </div>
    {right ?? <Icons.Chevron size={12} stroke={1.8} style={{ color: 'var(--ink-3)' }}/>}
  </div>
);

const Toggle = ({ on }) => (
  <span style={{
    width: 36, height: 22, borderRadius: 11, padding: 2,
    background: on ? 'var(--moss-2)' : 'var(--bg-3)',
    display: 'inline-flex', alignItems: 'center', transition: 'background 160ms',
  }}>
    <span style={{
      width: 18, height: 18, borderRadius: '50%', background: '#f1ede2',
      transform: on ? 'translateX(14px)' : 'translateX(0)',
      transition: 'transform 160ms',
    }}/>
  </span>
);

Object.assign(window, { SettingsScreen, SRow, Toggle });
