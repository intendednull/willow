// Mobile profile sheet — a bottom sheet that wraps ProfileCardContent.
// Listens on useProfileController(); wrap the app with <ProfileSheetHost/>.

const { useState: useSSh, useEffect: useESh, useRef: useRSh } = React;

function ProfileSheetHost() {
  const ctrl = useProfileController();
  const [visible, setVisible] = useSSh(false);

  // Mount → animate in; on close event, animate out then unmount
  useESh(() => {
    if (ctrl) {
      setVisible(false);
      const r = requestAnimationFrame(() => setVisible(true));
      return () => cancelAnimationFrame(r);
    }
  }, [ctrl?.user?.id]);

  if (!ctrl) return null;

  const onAction = (id, user) => {
    if (id === 'copyFp' && navigator.clipboard) {
      navigator.clipboard.writeText(user.fp || '').catch(() => {});
    }
    closeProfile();
  };

  return (
    <div
      onClick={closeProfile}
      style={{
        position: 'absolute', inset: 0, zIndex: 120,
        background: visible ? 'rgba(0,0,0,0.45)' : 'rgba(0,0,0,0)',
        transition: 'background 180ms ease',
        display: 'flex', alignItems: 'flex-end',
      }}>
      <div
        onClick={(e) => e.stopPropagation()}
        role="dialog" aria-label={`profile — ${ctrl.user.name}`}
        style={{
          width: '100%', background: 'var(--bg-1)',
          borderTopLeftRadius: 22, borderTopRightRadius: 22,
          padding: '8px 0 20px',
          transform: visible ? 'translateY(0)' : 'translateY(100%)',
          transition: 'transform 220ms cubic-bezier(.2,.8,.2,1)',
          boxShadow: '0 -20px 60px rgba(0,0,0,0.5)',
        }}>
        {/* drag handle */}
        <div style={{
          width: 44, height: 5, borderRadius: 3, background: 'var(--line)',
          margin: '6px auto 4px',
        }}/>
        <ProfileCardContent
          user={ctrl.user}
          platform="mobile"
          AvatarComponent={MAvatar}
          onAction={onAction}
        />
      </div>
    </div>
  );
}

Object.assign(window, { ProfileSheetHost });
