// Top-level app: screen switcher, tweaks wiring, theme variables.

const { useState, useEffect } = React;

const ACCENTS = {
  moss:   { '--moss-2': '#6a8d5e', '--moss-3': '#93b582', '--moss-4': '#c3d8b2', '--moss-1': '#425c3d', '--moss-0': '#2a3a28' },
  willow: { '--moss-2': '#a7b86a', '--moss-3': '#c1d18a', '--moss-4': '#e4ecb8', '--moss-1': '#5a663a', '--moss-0': '#353b22' },
  amber:  { '--moss-2': '#c99b55', '--moss-3': '#e0b57a', '--moss-4': '#f2d8a8', '--moss-1': '#7a5a2e', '--moss-0': '#3a2c18' },
  dusk:   { '--moss-2': '#a88fc9', '--moss-3': '#c2adda', '--moss-4': '#e0d4ef', '--moss-1': '#5a4a72', '--moss-0': '#2d2438' },
};

const DENSITY = {
  cozy:     { '--msg-pad': '10px 24px' },
  balanced: { '--msg-pad': '8px 24px' },
  dense:    { '--msg-pad': '4px 24px' },
};

const DEFAULTS_EL = document.getElementById('tweakable-defaults');
const INITIAL_TWEAKS = DEFAULTS_EL ? JSON.parse(DEFAULTS_EL.textContent) : {};

// ---- Corner wordmark + status strip ----

const CornerMark = ({ show }) => show ? (
  <div style={{
    position: 'fixed', left: 84, bottom: 14, zIndex: 50, pointerEvents: 'none', opacity: 0.5,
  }}>
    <Wordmark size={12} showMark={false}/>
  </div>
) : null;

// Left side-rail for app-level nav sections.
const AppRail = ({ view, setView, tweaks }) => {
  const items = [
    { id: 'chat', label: 'grove', icon: Icons.Tree },
    { id: 'dms', label: 'letters', icon: Icons.Inbox },
    { id: 'call', label: 'call', icon: Icons.Phone },
    { id: 'governance', label: 'govern', icon: Icons.Shield },
    { id: 'manage', label: 'manage', icon: Icons.Users },
    { id: 'events', label: 'events', icon: Icons.Dashboard },
    { id: 'discover', label: 'discover', icon: Icons.Compass },
    { id: 'onboarding', label: 'onboard', icon: Icons.Key },
    { id: 'settings', label: 'settings', icon: Icons.Settings },
  ];
  return (
    <div style={{
      position: 'fixed', right: 16, bottom: 68, zIndex: 90,
      background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 12,
      padding: 6, display: 'flex', gap: 4, boxShadow: 'var(--shadow-2)',
    }}>
      {items.map(it => {
        const I = it.icon;
        const active = view === it.id;
        return (
          <button key={it.id} onClick={() => setView(it.id)} style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '6px 10px', borderRadius: 8,
            background: active ? 'var(--bg-3)' : 'transparent',
            color: active ? 'var(--ink-0)' : 'var(--ink-2)',
            fontSize: 11.5,
          }}>
            <I size={13} stroke={1.6}/>{it.label}
          </button>
        );
      })}
    </div>
  );
};

function App() {
  const [tweaks, setTweaks] = useState(INITIAL_TWEAKS);
  const [tweaksOpen, setTweaksOpen] = useState(false);
  const [view, setView] = useState('chat'); // chat | dms | call | discover | onboarding | settings
  const [showMembers, setShowMembers] = useState(true);
  const [showThread, setShowThread] = useState(false);
  const [threadParent, setThreadParent] = useState(null);
  const [currentGrove, setCurrentGrove] = useState('g1');
  const [currentChannel, setCurrentChannel] = useState('c2');

  // Apply accent & density as CSS vars on :root
  useEffect(() => {
    const root = document.documentElement;
    const accent = ACCENTS[tweaks.accent] ?? ACCENTS.moss;
    Object.entries(accent).forEach(([k, v]) => root.style.setProperty(k, v));
    const dens = DENSITY[tweaks.density] ?? DENSITY.balanced;
    Object.entries(dens).forEach(([k, v]) => root.style.setProperty(k, v));
  }, [tweaks.accent, tweaks.density]);

  // Edit-mode protocol
  useEffect(() => {
    const onMessage = (e) => {
      if (!e.data) return;
      if (e.data.type === '__activate_edit_mode') setTweaksOpen(true);
      if (e.data.type === '__deactivate_edit_mode') setTweaksOpen(false);
    };
    window.addEventListener('message', onMessage);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMessage);
  }, []);

  const setTweak = (k, v) => {
    setTweaks(t => {
      const next = { ...t, [k]: v };
      window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [k]: v } }, '*');
      return next;
    });
  };

  const grove = GROVES.find(g => g.id === currentGrove) ?? GROVES[0];
  const channels = CHANNEL_GROUPS[currentGrove] ?? CHANNEL_GROUPS.g1;
  const channel = channels.flatMap(g => g.channels).find(c => c.id === currentChannel)
               ?? channels[0].channels[0];
  const me = PEOPLE_BY_ID['u9'];

  const selectChannel = (id) => {
    const ch = channels.flatMap(g => g.channels).find(c => c.id === id);
    setCurrentChannel(id);
    if (ch?.kind === 'voice') setView('call'); else setView('chat');
  };

  const openThreadFor = (m) => { setThreadParent(m); setShowThread(true); setShowMembers(false); };

  return (
    <>
      <div data-screen-label={view} style={{ display: 'flex', height: '100vh', width: '100vw' }}>
        {view !== 'onboarding' && (
          <GroveSwitcher
            groves={GROVES}
            currentId={currentGrove}
            onSelect={(id) => { setCurrentGrove(id); setView('chat'); }}
            onDM={() => setView('dms')}
            onDiscover={() => setView('discover')}
            onSettings={() => setView('settings')}
            dmActive={view === 'dms'}
            discoverActive={view === 'discover'}
            settingsActive={view === 'settings'}
          />
        )}

        {view === 'chat' && (
          <>
            <ChannelSidebar
              grove={grove}
              channels={channels}
              currentId={channel.id}
              onSelect={selectChannel}
              me={me}
            />
            <ChatView
              channel={channel}
              onToggleMembers={() => { setShowMembers(m => !m); setShowThread(false); }}
              onToggleThread={() => { setShowThread(t => !t); setShowMembers(false); }}
              onOpenCall={() => setView('call')}
              onOpenThreadFor={openThreadFor}
            />
            {showThread && <ThreadPane onClose={() => setShowThread(false)} parentMessage={threadParent}/>}
            {showMembers && !showThread && <MembersPane/>}
          </>
        )}

        {view === 'dms' && <DMsView/>}
        {view === 'call' && (
          <>
            <ChannelSidebar grove={grove} channels={channels} currentId={channel.id} onSelect={selectChannel} me={me}/>
            <CallView onClose={() => setView('chat')} layout={tweaks.callLayout} channel={channel}/>
          </>
        )}
        {view === 'governance' && <GovernanceView/>}
        {view === 'manage' && <RolesInvitesFilesView/>}
        {view === 'events' && <EventLogView/>}
        {view === 'discover' && <DiscoverView/>}
        {view === 'onboarding' && <OnboardingView/>}
        {view === 'settings' && <SettingsView onClose={() => setView('chat')}/>}
      </div>

      <CornerMark show={tweaks.showWordmark && view !== 'onboarding'}/>
      <AppRail view={view} setView={setView} tweaks={tweaks}/>
      <TweaksPanel open={tweaksOpen} tweaks={tweaks} setTweak={setTweak}/>
      <ProfilePopoverHost/>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('app-root')).render(<App/>);
