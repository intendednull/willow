// Voice/video call view — integrated, uncluttered. Ambient info lives in:
//  - header chip (whisper state + speaking ticker)
//  - control-bar popovers (whisper panel, handoff panel, stats panel)
// The stage itself is now the full width of the view.

const CallTile = ({ user, speaking, isScreen, isSelf, big, whispering }) => {
  const ring = speaking ? 'var(--moss-3)' : whispering ? 'var(--whisper)' : 'transparent';
  return (
    <div style={{
      position: 'relative', borderRadius: 14, overflow: 'hidden',
      background: 'var(--bg-2)', border: `2px solid ${ring}`,
      transition: 'border-color 180ms',
      aspectRatio: big ? '16/9' : '4/3',
      minHeight: big ? 'auto' : 120,
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: `radial-gradient(circle at 30% 30%, ${user.avatar}22, var(--bg-0))`,
      }}/>
      {isScreen ? (
        <ScreenShareContent compact={false}/>
      ) : (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{
            width: big ? 120 : 72, height: big ? 120 : 72, borderRadius: '50%',
            background: user.avatar, color: '#14130f',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: big ? 56 : 32, fontWeight: 400,
            boxShadow: speaking ? `0 0 0 8px ${user.avatar}33, 0 0 0 14px ${user.avatar}11` : 'none',
            transition: 'box-shadow 200ms',
          }}>{user.name[0]}</div>
        </div>
      )}
      <div style={{
        position: 'absolute', left: 10, bottom: 10, right: 10,
        display: 'flex', alignItems: 'center', gap: 6,
      }}>
        <span style={{
          padding: '3px 8px', borderRadius: 6, background: 'rgba(20,19,15,0.78)',
          backdropFilter: 'blur(8px)', color: 'var(--ink-0)', fontSize: 12,
          display: 'inline-flex', alignItems: 'center', gap: 6,
        }}>
          {user.name}{isSelf && <span style={{ color: 'var(--ink-3)' }}>· you</span>}
          {user.verified && <VerifiedBadge size={9}/>}
          {whispering && <Icons.Ear size={11} stroke={1.6}/>}
        </span>
        {isScreen && (
          <span style={{ padding: '3px 8px', borderRadius: 6, background: 'rgba(106,141,94,0.25)',
            color: 'var(--moss-4)', fontSize: 11, fontFamily: 'var(--font-mono)',
            display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <Icons.Screen size={11} stroke={1.6}/>sharing
          </span>
        )}
        <span style={{ flex: 1 }}/>
        {user.muted
          ? <span style={{ padding: 4, borderRadius: 6, background: 'rgba(201,122,90,0.25)', color: 'var(--err)' }}><Icons.MicOff size={11}/></span>
          : <span style={{ padding: 4, borderRadius: 6, background: 'rgba(20,19,15,0.78)', color: 'var(--ink-2)' }}><Icons.Mic size={11}/></span>}
      </div>
      <div style={{ position: 'absolute', top: 10, right: 10,
        display: 'inline-flex', alignItems: 'center', gap: 4,
        padding: '3px 6px', borderRadius: 6, background: 'rgba(20,19,15,0.65)',
        fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--moss-3)' }}>
        <Icons.Signal size={10} stroke={1.8}/>{Math.floor(Math.random()*60 + 120)}ms
      </div>
    </div>
  );
};

// --- Popovers ---

const Popover = ({ children, onClose, anchor = 'bottom' }) => (
  <>
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 40 }}/>
    <div style={{
      position: 'absolute', bottom: anchor === 'bottom' ? 72 : 'auto', top: anchor === 'top' ? 60 : 'auto',
      left: '50%', transform: 'translateX(-50%)',
      zIndex: 41, minWidth: 300, maxWidth: 340,
      background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 14,
      boxShadow: '0 12px 32px rgba(0,0,0,0.4), 0 0 0 1px var(--line-soft)',
      overflow: 'hidden',
    }}>
      {children}
    </div>
  </>
);

const WhisperPopover = ({ onClose }) => (
  <Popover onClose={onClose}>
    <div style={{
      padding: 16,
      background: 'linear-gradient(180deg, color-mix(in oklab, var(--whisper) 14%, var(--bg-1)), var(--bg-1) 90%)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <Icons.Ear size={14} stroke={1.6}/>
        <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 15, color: 'var(--whisper)' }}>whisper with ori</span>
        <span style={{ flex: 1 }}/>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-3)' }}>02:14</span>
      </div>
      <div style={{ fontSize: 12, color: 'var(--ink-2)', lineHeight: 1.5 }}>
        side-channel inside the grove. its own ephemeral key; nobody else on the call can hear it.
      </div>
      <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 8,
        padding: '8px 10px', borderRadius: 10, background: 'var(--bg-2)',
        border: '1px solid var(--line)' }}>
        <Avatar user={PEOPLE_BY_ID['u2']} size={24}/>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, color: 'var(--ink-0)' }}>ori.birch</div>
          <div style={{ fontSize: 10.5, color: 'var(--whisper)', fontStyle: 'italic', fontFamily: 'var(--font-display)' }}>speaking softly…</div>
        </div>
        <Pulse color="var(--whisper)"/>
      </div>
      <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
        <button style={{
          flex: 1, padding: '8px 10px', borderRadius: 8,
          background: 'var(--bg-2)', border: '1px solid var(--line)',
          color: 'var(--ink-1)', fontSize: 12,
        }}>invite someone</button>
        <button style={{
          flex: 1, padding: '8px 10px', borderRadius: 8,
          background: 'transparent', border: '1px solid color-mix(in oklab, var(--whisper) 40%, var(--line))',
          color: 'var(--whisper)', fontSize: 12,
        }}>leave whisper</button>
      </div>
    </div>
  </Popover>
);

const HandoffPopover = ({ onClose }) => (
  <Popover onClose={onClose}>
    <div style={{ padding: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
        <Icons.Device size={14}/>
        <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 15, color: 'var(--ink-0)' }}>{HANDOFF_COPY.title}</span>
      </div>
      <div style={{ fontSize: 12, color: 'var(--ink-2)', lineHeight: 1.5, marginBottom: 10 }}>
        {HANDOFF_COPY.subtitle}
      </div>
      {HANDOFF_DEVICES_DESKTOP.map(d => (
        <button key={d.n} disabled={d.here} style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 10,
          padding: '10px 12px', borderRadius: 10, marginBottom: 6,
          background: d.here ? 'var(--bg-2)' : 'var(--bg-2)',
          border: '1px solid var(--line)',
          color: d.here ? 'var(--ink-3)' : 'var(--ink-0)',
          textAlign: 'left', cursor: d.here ? 'default' : 'pointer',
          opacity: d.here ? 0.6 : 1,
        }}>
          <Icons.Device size={14}/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }}>{d.n}</div>
            <div style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>{d.meta}</div>
          </div>
          {d.here
            ? <Tag mono color="var(--moss-3)" border="var(--line)">here</Tag>
            : <Icons.Chevron size={12}/>}
        </button>
      ))}
    </div>
  </Popover>
);

const StatsPopover = ({ onClose }) => (
  <Popover onClose={onClose}>
    <div style={{ padding: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <Icons.Mic size={13}/>
        <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 15, color: 'var(--ink-0)' }}>speaking time</span>
        <span style={{ flex: 1 }}/>
        <span style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)' }}>last 10m</span>
      </div>
      {SPEAKING_STATS.map(row => {
        const u = PEOPLE_BY_ID[row.id];
        return (
          <div key={row.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 0' }}>
            <Avatar user={u} size={22}/>
            <span style={{ fontSize: 12, color: 'var(--ink-1)', width: 64 }}>{u.name}</span>
            <div style={{ flex: 1, height: 4, background: 'var(--bg-2)', borderRadius: 2, overflow: 'hidden' }}>
              <div style={{ width: `${row.bars}%`, height: '100%', background: 'var(--moss-2)' }}/>
            </div>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-3)', width: 40, textAlign: 'right' }}>{row.t}</span>
          </div>
        );
      })}
      <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--line-soft)',
        display: 'flex', gap: 12, fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--ink-3)' }}>
        <span>bitrate <span style={{ color: 'var(--ink-1)' }}>opus · 48k</span></span>
        <span>jitter <span style={{ color: 'var(--ink-1)' }}>8ms</span></span>
        <span>loss <span style={{ color: 'var(--moss-3)' }}>0.0%</span></span>
      </div>
    </div>
  </Popover>
);

// --- Header ticker (who's speaking now, subtle) ---

const NowSpeakingTicker = () => {
  const u = PEOPLE_BY_ID['u6'];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '3px 10px 3px 4px', borderRadius: 999,
      background: 'var(--bg-2)', border: '1px solid var(--line)',
    }}>
      <Avatar user={u} size={18}/>
      <span style={{ fontSize: 11.5, color: 'var(--ink-1)' }}>{u.name}</span>
      <span style={{ display: 'inline-flex', gap: 2, alignItems: 'end', height: 10 }}>
        {[5, 8, 4, 7, 3].map((h, i) => (
          <span key={i} style={{
            width: 2, height: h, background: 'var(--moss-3)', borderRadius: 1,
            animation: `willowPulse 900ms ${i * 120}ms infinite`,
          }}/>
        ))}
      </span>
    </span>
  );
};

const CallView = ({ onClose, layout = 'grove', channel }) => {
  const [pop, setPop] = React.useState(null); // 'whisper' | 'handoff' | 'stats' | null
  const [whisperActive] = React.useState(true);

  const screenSharer = PEOPLE_BY_ID['u6'];
  const others = [PEERS[0], PEERS[1], PEERS[2], PEERS[3], PEERS[7], PEOPLE_BY_ID['u9']];

  return (
    <div style={{
      flex: 1, background: 'var(--bg-0)',
      display: 'flex', flexDirection: 'column', minWidth: 0,
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none',
        background: 'radial-gradient(1000px 500px at 20% 0%, rgba(106,141,94,0.08), transparent 60%), radial-gradient(800px 400px at 80% 100%, rgba(168,143,201,0.06), transparent 60%)',
      }}/>

      {/* Header — minimal; ambient status sits as small chips */}
      <div style={{
        height: 52, padding: '0 16px', borderBottom: '1px solid var(--line-soft)',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <Icons.Volume size={16}/>
        <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 17, color: 'var(--ink-0)' }}>
          {channel?.name ?? 'the-porch'}
        </div>
        <Tag mono color="var(--ink-2)" border="var(--line)">7 · 42:18</Tag>
        {whisperActive && (
          <WhisperPill onClick={() => setPop('whisper')}/>
        )}
        <NowSpeakingTicker/>
        <span style={{ flex: 1 }}/>
        <Tag mono color="var(--ink-2)" border="var(--line)"><Icons.Lock size={10}/>3 direct · 4 relay</Tag>
        <IconBtn icon={Icons.Grid} label="Grid" active={layout === 'grid'}/>
        <IconBtn icon={Icons.Spotlight} label="Spotlight" active={layout === 'spotlight'}/>
        <IconBtn icon={Icons.Tree} label="Grove" active={layout === 'grove'}/>
        <IconBtn icon={Icons.X} label="Close" onClick={onClose}/>
      </div>

      {/* Stage fills the whole body */}
      <div style={{ flex: 1, padding: 16, display: 'flex', flexDirection: 'column', gap: 12, minHeight: 0, position: 'relative' }}>
        <div style={{ flex: 1, minHeight: 0 }}>
          <CallTile user={screenSharer} isScreen big speaking/>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10, height: 140 }}>
          {others.map((u, i) => (
            <CallTile key={u.id} user={{...u, muted: i === 2 || i === 4}}
              speaking={i === 0}
              whispering={i === 2}
              isSelf={u.id === 'u9'}/>
          ))}
        </div>
      </div>

      {/* Control bar — popovers for whisper / handoff / stats */}
      <div style={{
        padding: 14, borderTop: '1px solid var(--line-soft)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
        background: 'var(--bg-1)', position: 'relative',
      }}>
        <CallBtn icon={Icons.Mic} label="mute"/>
        <CallBtn icon={Icons.Cam} label="camera"/>
        <CallBtn icon={Icons.Screen} label="share" active/>
        <CallBtn icon={Icons.Ear} label="whisper" tone="whisper" active={whisperActive}
          onClick={() => setPop(pop === 'whisper' ? null : 'whisper')}/>
        <CallBtn icon={Icons.Device} label="handoff"
          onClick={() => setPop(pop === 'handoff' ? null : 'handoff')}/>
        <CallBtn icon={Icons.Dashboard} label="stats"
          onClick={() => setPop(pop === 'stats' ? null : 'stats')}/>
        <CallBtn icon={Icons.More} label="more"/>
        <div style={{ width: 24 }}/>
        <button style={{
          padding: '10px 18px', borderRadius: 10, background: 'var(--err)', color: '#14130f',
          fontWeight: 600, fontSize: 13, display: 'inline-flex', alignItems: 'center', gap: 6,
        }}>
          <Icons.PhoneDown size={14} stroke={2}/> leave grove
        </button>

        {pop === 'whisper' && <WhisperPopover onClose={() => setPop(null)}/>}
        {pop === 'handoff' && <HandoffPopover onClose={() => setPop(null)}/>}
        {pop === 'stats' && <StatsPopover onClose={() => setPop(null)}/>}
      </div>
    </div>
  );
};

const CallBtn = ({ icon, label, active, tone, onClick }) => {
  const C = icon;
  const bg = active
    ? (tone === 'whisper' ? 'color-mix(in oklab, var(--whisper) 30%, var(--bg-2))' : 'var(--bg-3)')
    : 'var(--bg-2)';
  const fg = active
    ? (tone === 'whisper' ? 'var(--whisper)' : 'var(--ink-0)')
    : 'var(--ink-1)';
  return (
    <button onClick={onClick} style={{
      width: 44, height: 44, borderRadius: '50%',
      background: bg, color: fg, border: '1px solid var(--line)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
    }} title={label}>
      <C size={18} stroke={1.6}/>
    </button>
  );
};

window.CallView = CallView;
