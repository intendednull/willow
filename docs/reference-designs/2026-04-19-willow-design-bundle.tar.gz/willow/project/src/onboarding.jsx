// Onboarding — key generation, add friend by fingerprint, first-run.

const Step = ({ n, label, active, done }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
    <div style={{
      width: 26, height: 26, borderRadius: '50%',
      background: done ? 'var(--moss-2)' : active ? 'var(--bg-3)' : 'var(--bg-2)',
      color: done ? '#14130f' : active ? 'var(--ink-0)' : 'var(--ink-3)',
      border: `1px solid ${active ? 'var(--moss-2)' : 'var(--line)'}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600,
    }}>
      {done ? <Icons.Check size={12} stroke={2.4}/> : n}
    </div>
    <div style={{ fontSize: 13, color: active ? 'var(--ink-0)' : done ? 'var(--ink-1)' : 'var(--ink-3)' }}>
      {label}
    </div>
  </div>
);

const OnboardingView = () => (
  <div style={{ flex: 1, display: 'flex', alignItems: 'stretch', background: 'var(--bg-0)', minWidth: 0, overflow: 'hidden' }}>
    {/* left: ambient */}
    <div style={{
      width: 360, background: 'var(--bg-1)', borderRight: '1px solid var(--line-soft)',
      padding: '32px 28px', display: 'flex', flexDirection: 'column', gap: 20,
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none',
        background: 'radial-gradient(500px 300px at 30% 10%, rgba(106,141,94,0.12), transparent 60%), radial-gradient(400px 300px at 70% 90%, rgba(201,155,85,0.08), transparent 60%)' }}/>
      <div style={{ position: 'relative' }}>
        <Wordmark size={28}/>
        <div style={{ marginTop: 16, fontFamily: 'var(--font-display)', fontStyle: 'italic',
          fontSize: 32, color: 'var(--ink-0)', lineHeight: 1.15, maxWidth: 280 }}>
          a quiet place, held between the people you trust.
        </div>
        <div style={{ marginTop: 12, fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.6, maxWidth: 290 }}>
          willow is peer-to-peer. there is no server with your messages. your keys live on this device and sync to the ones you add.
        </div>
      </div>
      <div style={{ flex: 1 }}/>
      <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Step n={1} label="make your keys" done/>
        <Step n={2} label="name your device" done/>
        <Step n={3} label="add a friend" active/>
        <Step n={4} label="join or start a grove"/>
      </div>
    </div>

    {/* right: current step */}
    <div style={{ flex: 1, padding: '40px 56px', overflow: 'auto' }} className="scroll">
      <div style={{ fontSize: 11, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.4 }}>
        step 3 of 4
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 34, color: 'var(--ink-0)', marginTop: 6 }}>
        {SAS_COPY.title}
      </div>
      <div style={{ fontSize: 14, color: 'var(--ink-2)', marginTop: 6, maxWidth: 560, lineHeight: 1.6 }}>
        {SAS_COPY.intro}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginTop: 28, maxWidth: 820 }}>
        {/* your card */}
        <div style={{ background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 16, padding: 22 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Avatar user={PEOPLE_BY_ID['u9']} size={36}/>
            <div>
              <div style={{ fontSize: 14, color: 'var(--ink-0)' }}>You · willow·desk</div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{SAS_COPY.youMeta}</div>
            </div>
          </div>
          <FingerprintLabel which="you" size="md"/>
          <FingerprintGrid words={SAS_YOU_WORDS} size="md"/>
        </div>

        {/* friend card */}
        <div style={{ background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 16, padding: 22 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Avatar user={PEOPLE_BY_ID['u2']} size={36}/>
            <div>
              <div style={{ fontSize: 14, color: 'var(--ink-0)' }}>Ori · willow·phone</div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{SAS_COPY.peerMeta}</div>
            </div>
          </div>
          <FingerprintLabel which="peer" size="md"/>
          <FingerprintGrid words={SAS_PEER_WORDS} size="md"/>
          <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
            <button style={{
              flex: 1, padding: '10px 12px', borderRadius: 10,
              background: 'var(--moss-2)', color: '#14130f', fontSize: 13, fontWeight: 600,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            }}>
              <Icons.Check size={14} stroke={2.2}/> {SAS_COPY.matchCta}
            </button>
            <button style={{
              padding: '10px 12px', borderRadius: 10,
              background: 'transparent', border: '1px solid var(--line)', color: 'var(--ink-2)', fontSize: 13,
            }}>
              {SAS_COPY.noMatchCta}
            </button>
          </div>
        </div>
      </div>

      <div style={{ marginTop: 20, fontSize: 12, color: 'var(--ink-3)', maxWidth: 720, lineHeight: 1.6,
        display: 'flex', alignItems: 'flex-start', gap: 10 }}>
        <Icons.Shield size={16} stroke={1.6}/>
        <div>
          {SAS_COPY.reassurance}
        </div>
      </div>

      <div style={{ marginTop: 28, display: 'flex', gap: 10 }}>
        <button style={{ padding: '10px 16px', borderRadius: 10, background: 'var(--bg-2)',
          color: 'var(--ink-2)', border: '1px solid var(--line)', fontSize: 13 }}>skip for now</button>
        <button style={{ padding: '10px 16px', borderRadius: 10, background: 'var(--bg-3)',
          color: 'var(--ink-0)', border: '1px solid var(--line)', fontSize: 13,
          display: 'inline-flex', alignItems: 'center', gap: 6 }}>
          continue <Icons.Arrow size={13}/>
        </button>
      </div>
    </div>
  </div>
);

window.OnboardingView = OnboardingView;
