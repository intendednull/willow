// Desktop profile popover — positions ProfileCardContent near the anchor element.
// Listens on useProfileController(); wrap the app with <ProfilePopoverHost/>.

const { useState: useSPop, useEffect: useEPop, useRef: useRPop, useLayoutEffect: useLPop } = React;

function ProfilePopoverHost() {
  const ctrl = useProfileController();
  const cardRef = useRPop(null);
  const [pos, setPos] = useSPop({ left: -9999, top: -9999 });

  // Position near anchor; flip if it would overflow. Runs pre-paint so
  // we never see the card at its placeholder offscreen coords.
  useLPop(() => {
    if (!ctrl || !cardRef.current) return;
    const CARD_W = 320;
    const CARD_H = cardRef.current.offsetHeight || 280;
    const GAP = 8;
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    let left, top;
    if (ctrl.anchor && ctrl.anchor.getBoundingClientRect) {
      const r = ctrl.anchor.getBoundingClientRect();
      left = r.right + GAP;
      if (left + CARD_W + 12 > vw) left = r.left - CARD_W - GAP;
      if (left < 12) left = Math.max(12, Math.min(vw - CARD_W - 12, r.left));
      top = r.top;
      if (top + CARD_H + 12 > vh) top = Math.max(12, vh - CARD_H - 12);
    } else {
      left = Math.round(vw / 2 - CARD_W / 2);
      top  = Math.round(vh / 2 - CARD_H / 2);
    }
    setPos({ left, top });
  }, [ctrl]);

  // Click-outside closes
  useEPop(() => {
    if (!ctrl) return;
    const onDown = (e) => {
      if (!cardRef.current) return;
      if (cardRef.current.contains(e.target)) return;
      if (ctrl.anchor && ctrl.anchor.contains && ctrl.anchor.contains(e.target)) return;
      closeProfile();
    };
    // defer one tick so the click that opened us doesn't also close
    const t = setTimeout(() => document.addEventListener('mousedown', onDown), 0);
    return () => { clearTimeout(t); document.removeEventListener('mousedown', onDown); };
  }, [ctrl]);

  if (!ctrl) return null;

  const onAction = (id, user) => {
    if (id === 'copyFp' && navigator.clipboard) {
      navigator.clipboard.writeText(user.fp || '').catch(() => {});
    }
    // Other actions are stubs in this prototype
    closeProfile();
  };

  return (
    <div ref={cardRef} role="dialog" aria-label={`profile — ${ctrl.user.name}`}
      style={{
        position: 'fixed', left: pos.left, top: pos.top, width: 320, zIndex: 200,
        background: 'var(--bg-1)', border: '1px solid var(--line)', borderRadius: 12,
        boxShadow: '0 20px 60px rgba(0,0,0,0.55), 0 0 0 1px rgba(0,0,0,0.25)',
        animation: 'willow-pop-in 140ms ease-out',
      }}>
      <ProfileCardContent
        user={ctrl.user}
        platform="desktop"
        AvatarComponent={Avatar}
        onAction={onAction}
        onClose={closeProfile}
      />
    </div>
  );
}

Object.assign(window, { ProfilePopoverHost });
