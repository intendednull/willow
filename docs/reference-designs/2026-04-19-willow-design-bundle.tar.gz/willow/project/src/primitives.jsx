// Small reusable UI atoms for Willow.

const Avatar = ({ user, size = 28, ring, overlap, nonInteractive }) => {
  if (!user) return null;
  const initials = user.name?.[0]?.toUpperCase() ?? '?';
  const interactive = !nonInteractive && !!window.openProfile;
  const s = { width: size, height: size, borderRadius: '50%', background: user.avatar, color: '#14130f',
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: size * 0.42,
    border: ring ? `2px solid ${ring}` : 'none',
    boxShadow: '0 0 0 2px var(--bg-0)',
    marginLeft: overlap ? -size * 0.35 : 0,
    position: 'relative', flexShrink: 0,
    cursor: interactive ? 'pointer' : 'default',
    transition: 'transform 120ms',
  };
  const onClick = interactive
    ? (e) => { e.stopPropagation(); window.openProfile(user.id, e.currentTarget); }
    : undefined;
  const onEnter = interactive ? (e) => { e.currentTarget.style.transform = 'scale(1.06)'; } : undefined;
  const onLeave = interactive ? (e) => { e.currentTarget.style.transform = 'scale(1)'; } : undefined;
  return (
    <span style={s} onClick={onClick} onMouseEnter={onEnter} onMouseLeave={onLeave}
          title={interactive ? user.name : undefined}>
      {initials}
    </span>
  );
};

// Wraps a clickable name/handle so the same popover opens from text triggers.
const PeerName = ({ user, children, style }) => {
  if (!user) return children ?? null;
  const interactive = !!window.openProfile;
  return (
    <span
      onClick={interactive ? (e) => { e.stopPropagation(); window.openProfile(user.id, e.currentTarget); } : undefined}
      style={{
        cursor: interactive ? 'pointer' : 'inherit',
        borderRadius: 4,
        transition: 'background 100ms',
        padding: interactive ? '0 2px' : 0,
        margin: interactive ? '0 -2px' : 0,
        ...style,
      }}
      onMouseEnter={interactive ? (e) => { e.currentTarget.style.background = 'color-mix(in oklab, var(--ink-0) 8%, transparent)'; } : undefined}
      onMouseLeave={interactive ? (e) => { e.currentTarget.style.background = 'transparent'; } : undefined}
    >
      {children ?? user.name}
    </span>
  );
};

const StatusDot = ({ status, size = 10 }) => {
  const map = {
    online:  'var(--moss-2)',
    idle:    'var(--warn)',
    offline: 'var(--ink-4)',
    whisper: 'var(--whisper)',
  };
  return <span style={{
    width: size, height: size, borderRadius: '50%',
    background: map[status] ?? 'var(--ink-4)',
    boxShadow: '0 0 0 2px var(--bg-1)',
    display: 'inline-block',
  }}/>;
};

// "Short Authentication String" style word triplet — 3 words from the fingerprint.
const ShortCode = ({ fp, length = 3 }) => {
  if (!fp) return null;
  const words = fp.split('-').slice(0, length);
  return (
    <span style={{
      fontFamily: 'var(--font-mono)', fontSize: 11,
      color: 'var(--ink-2)', letterSpacing: 0.2,
      display: 'inline-flex', gap: 6, alignItems: 'center'
    }}>
      {words.map((w, i) => (
        <React.Fragment key={i}>
          <span>{w}</span>
          {i < words.length - 1 && <span style={{ color: 'var(--ink-4)' }}>·</span>}
        </React.Fragment>
      ))}
    </span>
  );
};

const VerifiedBadge = ({ size = 12, title = 'verified peer' }) => (
  <span title={title} style={{
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    width: size + 4, height: size + 4, borderRadius: '50%',
    background: 'var(--moss-1)', color: 'var(--moss-4)',
    boxShadow: '0 0 0 1.5px var(--bg-1)',
  }}>
    <Icons.Check size={size - 2} stroke={2.2}/>
  </span>
);

const Tag = ({ children, color = 'var(--ink-2)', bg = 'var(--bg-2)', border, mono }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 4,
    padding: '2px 7px', borderRadius: 999,
    background: bg, color,
    border: border ? `1px solid ${border}` : '1px solid transparent',
    fontFamily: mono ? 'var(--font-mono)' : 'var(--font-ui)',
    fontSize: 11, lineHeight: 1.2, letterSpacing: mono ? 0.2 : 0,
  }}>{children}</span>
);

const IconBtn = ({ icon, label, onClick, active, tone, size = 32 }) => {
  const C = icon;
  const toneFg = tone === 'danger' ? 'var(--err)' : tone === 'accent' ? 'var(--moss-3)' : 'var(--ink-2)';
  return (
    <button onClick={onClick} title={label} aria-label={label} style={{
      width: size, height: size, borderRadius: 8,
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      background: active ? 'var(--bg-3)' : 'transparent',
      color: active ? 'var(--ink-0)' : toneFg,
      transition: 'background 120ms, color 120ms',
    }}
    onMouseEnter={e => { e.currentTarget.style.background = 'var(--bg-3)'; e.currentTarget.style.color = 'var(--ink-0)'; }}
    onMouseLeave={e => { e.currentTarget.style.background = active ? 'var(--bg-3)' : 'transparent'; e.currentTarget.style.color = active ? 'var(--ink-0)' : toneFg; }}
    >
      <C size={size === 32 ? 16 : 14}/>
    </button>
  );
};

// A little heartbeat line — nods to p2p connection quality.
const Pulse = ({ color = 'var(--moss-2)' }) => (
  <svg width="22" height="10" viewBox="0 0 22 10" style={{ verticalAlign: 'middle' }}>
    <path d="M0 5 H5 L7 2 L10 8 L13 1 L16 9 L18 5 H22"
          fill="none" stroke={color} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// Willow mark — a willow frond stylised as three hanging strokes in a circle.
const WillowMark = ({ size = 22, color = 'var(--willow)' }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" aria-label="Willow">
    <circle cx="16" cy="16" r="15" fill="none" stroke={color} strokeOpacity="0.35" strokeWidth="1"/>
    {/* trunk */}
    <path d="M16 5 C16 9 16 12 16 14" stroke={color} strokeWidth="1.4" strokeLinecap="round" fill="none"/>
    {/* fronds */}
    <path d="M16 13 C12 15 9 19 8 26" stroke={color} strokeWidth="1.3" strokeLinecap="round" fill="none"/>
    <path d="M16 13 C17 17 17 22 16 27" stroke={color} strokeWidth="1.3" strokeLinecap="round" fill="none"/>
    <path d="M16 13 C20 15 23 19 24 26" stroke={color} strokeWidth="1.3" strokeLinecap="round" fill="none"/>
    {/* leaf hints */}
    <path d="M10 22 q-1 1.5 0 3" stroke={color} strokeWidth="1" fill="none" strokeLinecap="round"/>
    <path d="M22 22 q1 1.5 0 3" stroke={color} strokeWidth="1" fill="none" strokeLinecap="round"/>
    <path d="M16 23 q0 1.5 0 3" stroke={color} strokeWidth="1" fill="none" strokeLinecap="round"/>
  </svg>
);

const Wordmark = ({ size = 20, showMark = true }) => (
  <span style={{ display: 'inline-flex', alignItems: 'baseline', gap: 8 }}>
    {showMark && <span style={{ transform: 'translateY(3px)' }}><WillowMark size={size * 1.1}/></span>}
    <span style={{
      fontFamily: 'var(--font-display)',
      fontWeight: 400, fontStyle: 'italic',
      fontSize: size, letterSpacing: -0.2,
      color: 'var(--ink-0)',
    }}>willow</span>
  </span>
);

// A generative abstract "image" placeholder — organic leafy shape
const LeafPlaceholder = ({ w = 360, h = 200, seed = 0 }) => {
  const tints = [
    ['#2a3a28', '#6a8d5e', '#c3d8b2'],
    ['#3a3022', '#c99b55', '#f1ede2'],
    ['#2a2a38', '#a88fc9', '#f1ede2'],
  ];
  const [a, b, c] = tints[seed % tints.length];
  return (
    <svg width={w} height={h} viewBox="0 0 360 200" style={{ borderRadius: 10, display: 'block' }}>
      <defs>
        <linearGradient id={`g-${seed}`} x1="0" x2="1" y1="0" y2="1">
          <stop offset="0" stopColor={a}/>
          <stop offset="1" stopColor={b} stopOpacity="0.7"/>
        </linearGradient>
      </defs>
      <rect width="360" height="200" fill={`url(#g-${seed})`}/>
      {/* willow branch */}
      <path d="M40 20 C 120 80, 180 60, 320 180"
            stroke={c} strokeOpacity="0.9" strokeWidth="1.5" fill="none"/>
      {[...Array(14)].map((_, i) => {
        const x = 50 + i * 20 + (seed * 3 % 5);
        const y = 30 + Math.sin(i + seed) * 20 + i * 8;
        return <path key={i} d={`M ${x} ${y} q -6 12 -2 26`} stroke={c} strokeOpacity="0.75" strokeWidth="1" fill="none"/>;
      })}
    </svg>
  );
};

Object.assign(window, {
  Avatar, PeerName, StatusDot, ShortCode, VerifiedBadge, Tag, IconBtn, Pulse, WillowMark, Wordmark, LeafPlaceholder
});
