// DMs view — left panel is conversations, right is the thread.

const DMRow = ({ dm, onSelect, active }) => {
  if (dm.members) {
    const firstTwo = dm.members.slice(0,2).map(id => PEOPLE_BY_ID[id]);
    return (
      <div onClick={() => onSelect(dm.id)} style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '10px 12px', margin: '0 6px', borderRadius: 10,
        background: active ? 'var(--bg-3)' : 'transparent', cursor: 'pointer',
      }}
      onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'var(--bg-2)'; }}
      onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}
      >
        <div style={{ display: 'flex' }}>
          {firstTwo.map((u, i) => <span key={u.id} style={{ marginLeft: i ? -10 : 0 }}><Avatar user={u} size={30}/></span>)}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, color: 'var(--ink-0)', display: 'flex', alignItems: 'center', gap: 4 }}>
            {dm.name}
            <Tag mono><Icons.Users size={10}/>{dm.members.length}</Tag>
          </div>
          <div style={{ fontSize: 11.5, color: 'var(--ink-3)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{dm.last}</div>
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-3)' }}>{dm.t}</div>
      </div>
    );
  }
  const u = PEOPLE_BY_ID[dm.peer];
  return (
    <div onClick={() => onSelect(dm.id)} style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '10px 12px', margin: '0 6px', borderRadius: 10,
      background: active ? 'var(--bg-3)' : 'transparent', cursor: 'pointer',
    }}
    onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'var(--bg-2)'; }}
    onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}
    >
      <div style={{ position: 'relative' }}>
        <Avatar user={u} size={30}/>
        <span style={{ position: 'absolute', right: -2, bottom: -2 }}>
          <StatusDot status={u.status} size={9}/>
        </span>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span style={{ fontSize: 13, color: 'var(--ink-0)' }}>{u.name}</span>
          {dm.verified
            ? <VerifiedBadge size={9}/>
            : <span title="unverified" style={{
                width: 13, height: 13, borderRadius: '50%',
                border: '1.2px dashed var(--amber)', display: 'inline-flex',
                alignItems: 'center', justifyContent: 'center', color: 'var(--amber)', fontSize: 9,
              }}>?</span>}
          {dm.whisper && <Icons.Ear size={11} stroke={1.6} style={{ color: 'var(--whisper)' }}/>}
          <span style={{ flex: 1 }}/>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-3)' }}>{dm.t}</span>
        </div>
        <div style={{ fontSize: 11.5, color: dm.unread ? 'var(--ink-1)' : 'var(--ink-3)',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
          display: 'flex', alignItems: 'center', gap: 6 }}>
          {dm.queued > 0 && <Tag mono color="var(--amber)" border="var(--amber-soft)"><Icons.Hourglass size={9}/>{dm.queued}</Tag>}
          {dm.pendingVerify && <Tag mono color="var(--amber)" border="var(--amber-soft)"><Icons.Fingerprint size={9}/>verify</Tag>}
          {dm.last}
        </div>
      </div>
      {dm.unread > 0 && (
        <span style={{ background: 'var(--moss-2)', color: '#14130f',
          borderRadius: 10, padding: '1px 6px', fontSize: 11, fontWeight: 600 }}>{dm.unread}</span>
      )}
    </div>
  );
};

const DMsView = () => {
  const [sel, setSel] = React.useState('d1');
  const active = [...DMS, ...GROUP_DMS].find(d => d.id === sel);
  const peer = active?.peer ? PEOPLE_BY_ID[active.peer] : null;

  return (
    <>
      <aside style={{
        width: 290, background: 'var(--bg-1)', borderRight: '1px solid var(--line-soft)',
        display: 'flex', flexDirection: 'column', height: '100%',
      }}>
        <div style={{ padding: '14px 14px 8px' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 20, color: 'var(--ink-0)' }}>
            letters
          </div>
          <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>direct messages · e2e, device-local</div>
          <div style={{
            marginTop: 10, display: 'flex', alignItems: 'center', gap: 6,
            background: 'var(--bg-2)', borderRadius: 8, padding: '6px 10px',
          }}>
            <Icons.Search size={12}/>
            <input placeholder="search letters…" style={{
              flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 12, color: 'var(--ink-0)',
            }}/>
          </div>
        </div>
        <div style={{ padding: '4px 12px', fontSize: 10.5, color: 'var(--ink-3)',
          textTransform: 'uppercase', letterSpacing: 1.2 }}>direct</div>
        {DMS.map(dm => <DMRow key={dm.id} dm={dm} active={sel===dm.id} onSelect={setSel}/>)}
        <div style={{ padding: '10px 12px 4px', fontSize: 10.5, color: 'var(--ink-3)',
          textTransform: 'uppercase', letterSpacing: 1.2 }}>small circles</div>
        {GROUP_DMS.map(dm => <DMRow key={dm.id} dm={dm} active={sel===dm.id} onSelect={setSel}/>)}
        <div style={{ flex: 1 }}/>
        <div style={{ padding: '10px 14px', borderTop: '1px solid var(--line-soft)',
          display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'var(--ink-3)' }}>
          <Icons.Plus size={12}/>
          <span>start a letter · by fingerprint</span>
        </div>
      </aside>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg-1)', minWidth: 0 }}>
        <div style={{ height: 52, padding: '0 16px', borderBottom: '1px solid var(--line-soft)',
          display: 'flex', alignItems: 'center', gap: 10 }}>
          {peer ? (
            <>
              <Avatar user={peer} size={28}/>
              <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 16, color: 'var(--ink-0)' }}>{peer.name}</div>
              <span style={{ fontSize: 12, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)' }}>{peer.handle}</span>
              {peer.verified && <VerifiedBadge/>}
              <Tag mono color="var(--moss-3)" border="var(--line)"><Icons.Lock size={10}/>direct · no relay</Tag>
            </>
          ) : active?.name && (
            <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 16, color: 'var(--ink-0)' }}>{active.name}</div>
          )}
          <span style={{ flex: 1 }}/>
          <ShortCode fp={peer?.fp}/>
          <IconBtn icon={Icons.Phone} label="call"/>
          <IconBtn icon={Icons.Cam} label="video"/>
          <IconBtn icon={Icons.Search} label="search"/>
        </div>

        <div className="scroll" style={{ flex: 1, padding: '24px 32px' }}>
          <div style={{ textAlign: 'center', margin: '20px 0 40px' }}>
            <WillowMark size={44}/>
            <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 22, color: 'var(--ink-0)', marginTop: 8 }}>
              you met {peer?.name ?? '…'} in person
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--ink-3)', marginTop: 4 }}>
              keys verified 14 feb · no one between you
            </div>
          </div>
          {[
            { from: 'u2', t: '10:02', body: 'woke up to leaves everywhere. did the shed survive?' },
            { from: 'u9', t: '10:04', body: 'shed ok — the willow lost a limb. mira posted photos in #meander' },
            { from: 'u2', t: '10:13', body: 'do you want help? i can bring the big saw' },
            { from: 'u9', t: '10:14', body: 'yes please 🫶' },
          ].map((m, i, all) => {
            const u = PEOPLE_BY_ID[m.from];
            const self = m.from === 'u9';
            return (
              <div key={i} style={{
                display: 'flex', gap: 10, justifyContent: self ? 'flex-end' : 'flex-start',
                marginBottom: 10,
              }}>
                {!self && <Avatar user={u} size={28}/>}
                <div style={{ maxWidth: 480 }}>
                  <div style={{
                    padding: '8px 12px', borderRadius: 12,
                    background: self ? 'var(--moss-1)' : 'var(--bg-2)',
                    color: self ? 'var(--moss-4)' : 'var(--ink-1)',
                    border: '1px solid var(--line)',
                    fontSize: 14, lineHeight: 1.5,
                  }}>{m.body}</div>
                  <div style={{ fontSize: 10.5, color: 'var(--ink-3)', marginTop: 3, textAlign: self ? 'right' : 'left', fontFamily: 'var(--font-mono)' }}>
                    {m.t} {self && '· delivered · sealed'}
                  </div>
                </div>
                {self && <Avatar user={PEOPLE_BY_ID['u9']} size={28}/>}
              </div>
            );
          })}
        </div>

        <div style={{ padding: '0 16px 16px' }}>
          <div style={{ background: 'var(--bg-2)', border: '1px solid var(--line)',
            borderRadius: 12, padding: '8px 10px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <IconBtn icon={Icons.Paperclip} label="attach" size={28}/>
            <input placeholder={`write to ${peer?.name ?? '…'}…`}
              style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 14, color: 'var(--ink-0)' }}/>
            <Icons.Send size={14} stroke={1.8}/>
          </div>
        </div>
      </div>
    </>
  );
};

window.DMsView = DMsView;
