// Event log inspector — willow is event-sourced, this surfaces the raw event stream.
// Also: Invites, Roles, Files overview, sync state.

const EVENT_LOG = [
  { seq: 412, hlc: '01J8.9f2a', kind: 'MessageSent',  by: 'u1', at: '10:02', channel: 'meander', meta: 'msg_a1f2', ok: true },
  { seq: 413, hlc: '01J8.9f2b', kind: 'MessageSent',  by: 'u1', at: '10:02', channel: 'meander', meta: 'msg_a1f3 · img · 3 chunks', ok: true },
  { seq: 414, hlc: '01J8.9f2c', kind: 'ReactionAdded', by: 'u4', at: '10:03', channel: 'meander', meta: '🍃 → msg_a1f2', ok: true },
  { seq: 415, hlc: '01J8.9f31', kind: 'MessageEdited', by: 'u1', at: '10:04', channel: 'meander', meta: 'msg_a1f2 (typo)', ok: true },
  { seq: 416, hlc: '01J8.9f45', kind: 'ThreadStarted', by: 'u2', at: '10:13', channel: 'meander', meta: 'root=msg_a1f2', ok: true },
  { seq: 417, hlc: '01J8.9f48', kind: 'ProposeAction', by: 'u1', at: '10:20', channel: 'grove',   meta: 'grant-role → perrin', ok: true },
  { seq: 418, hlc: '01J8.9f52', kind: 'VoteCast',     by: 'u4', at: '10:22', channel: 'grove',   meta: 'yes · p_8a1c', ok: true },
  { seq: 419, hlc: '01J8.9f66', kind: 'KeyRotated',   by: '—',  at: '10:25', channel: 'meander', meta: 'epoch 13 → 14', ok: true },
  { seq: 420, hlc: '01J8.9f6a', kind: 'InviteCreated',by: 'u1', at: '10:27', channel: 'grove',   meta: 'expires 7d · uses 1', ok: true },
  { seq: 421, hlc: '01J8.9f72', kind: 'MessageSent',  by: 'u3', at: '10:29', channel: 'meander', meta: 'msg_a201 (merge)', warn: 'out-of-order → reordered by HLC' },
  { seq: 422, hlc: '01J8.9f81', kind: 'PeerJoined',   by: 'u5', at: '10:31', channel: 'grove',   meta: 'via invite i_2f4', ok: true },
];

const kindColor = {
  MessageSent: 'var(--ink-1)',
  MessageEdited: 'var(--amber)',
  ReactionAdded: 'var(--moss-3)',
  ThreadStarted: 'var(--moss-3)',
  ProposeAction: 'var(--willow)',
  VoteCast: 'var(--willow)',
  KeyRotated: 'var(--whisper)',
  InviteCreated: 'var(--amber)',
  PeerJoined: 'var(--moss-3)',
};

const EventLogView = () => (
  <div style={{ flex: 1, background: 'var(--bg-1)', display: 'flex', flexDirection: 'column', minWidth: 0 }}>
    <div style={{ padding: '22px 32px 14px', borderBottom: '1px solid var(--line-soft)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <Icons.Dashboard size={18}/>
        <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 24, color: 'var(--ink-0)' }}>
          event log
        </div>
        <span style={{ flex: 1 }}/>
        <Tag mono color="var(--moss-3)" border="var(--line)"><Icons.Signal size={10}/>live · 42 events/min</Tag>
        <Tag mono color="var(--ink-2)" border="var(--line)">HLC ordering</Tag>
        <Tag mono color="var(--ink-2)" border="var(--line)">ed25519 · signed</Tag>
      </div>
      <div style={{ fontSize: 12.5, color: 'var(--ink-2)', marginTop: 6, maxWidth: 680, lineHeight: 1.55 }}>
        willow is event-sourced. the grove's state — channels, roles, keys, messages — is a replay of signed events.
        HLC timestamps merge concurrent writes from different peers without a central clock.
      </div>
    </div>

    <div style={{ display: 'grid', gridTemplateColumns: '1fr 260px', gap: 0, flex: 1, minHeight: 0 }}>
      <div className="scroll" style={{ overflow: 'auto', padding: '0 0 20px' }}>
        <div style={{ position: 'sticky', top: 0, background: 'var(--bg-1)', zIndex: 1,
          padding: '10px 32px 8px', borderBottom: '1px solid var(--line-soft)',
          display: 'grid', gridTemplateColumns: '60px 120px 150px 110px 1fr 80px',
          gap: 10, fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.2,
          fontFamily: 'var(--font-mono)' }}>
          <span>seq</span><span>hlc</span><span>kind</span><span>by</span><span>meta</span><span>state</span>
        </div>
        {EVENT_LOG.slice().reverse().map(e => (
          <div key={e.seq} style={{
            display: 'grid', gridTemplateColumns: '60px 120px 150px 110px 1fr 80px', gap: 10,
            padding: '8px 32px', borderBottom: '1px solid var(--line-soft)',
            fontFamily: 'var(--font-mono)', fontSize: 11.5, alignItems: 'center',
          }}>
            <span style={{ color: 'var(--ink-3)' }}>#{e.seq}</span>
            <span style={{ color: 'var(--ink-2)' }}>{e.hlc}</span>
            <span style={{ color: kindColor[e.kind] ?? 'var(--ink-1)' }}>{e.kind}</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: 'var(--ink-1)' }}>
              {e.by !== '—' && <Avatar user={PEOPLE_BY_ID[e.by]} size={16}/>}
              {e.by !== '—' ? PEOPLE_BY_ID[e.by].name.toLowerCase() : <span style={{ color: 'var(--ink-3)' }}>system</span>}
            </span>
            <span style={{ color: 'var(--ink-2)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {e.meta}
            </span>
            <span>
              {e.warn
                ? <Tag mono color="var(--amber)" border="var(--amber-soft)">merged</Tag>
                : <Tag mono color="var(--moss-3)" border="var(--line)">ok</Tag>}
            </span>
          </div>
        ))}
      </div>

      <div style={{ borderLeft: '1px solid var(--line-soft)', padding: '16px 20px', background: 'var(--bg-0)' }}>
        <div style={{ fontSize: 11, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.4, marginBottom: 8 }}>
          sync state
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-2)', lineHeight: 1.8 }}>
          <div><span style={{ color: 'var(--ink-3)' }}>local head</span> 422</div>
          <div><span style={{ color: 'var(--ink-3)' }}>network head</span> 422 · <span style={{ color: 'var(--moss-3)' }}>in sync</span></div>
          <div><span style={{ color: 'var(--ink-3)' }}>heads summary</span> 8 peers</div>
        </div>
        <div style={{ height: 1, background: 'var(--line-soft)', margin: '16px 0' }}/>
        <div style={{ fontSize: 11, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.4, marginBottom: 8 }}>
          peers
        </div>
        {[
          { id: 'u1', h: 422, k: 'storage' },
          { id: 'u4', h: 422, k: 'direct' },
          { id: 'u2', h: 422, k: 'direct' },
          { id: 'u6', h: 421, k: 'direct' },
          { id: 'u8', h: 420, k: 'relay' },
          { id: 'u3', h: 418, k: 'relay' },
          { id: 'u7', h: 412, k: 'relay' },
          { id: 'u5', h: 'offline', k: 'queued' },
        ].map(p => {
          const u = PEOPLE_BY_ID[p.id];
          return (
            <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 0', fontSize: 11.5 }}>
              <Avatar user={u} size={18}/>
              <span style={{ color: 'var(--ink-1)', flex: 1, minWidth: 0 }}>{u.name}</span>
              <span style={{ fontFamily: 'var(--font-mono)', color: p.h === 'offline' ? 'var(--amber)' : 'var(--ink-2)' }}>
                {p.h === 'offline' ? 'queued' : `#${p.h}`}
              </span>
              <Tag mono color={p.k === 'direct' ? 'var(--moss-3)' : p.k === 'storage' ? 'var(--willow)' : p.k === 'queued' ? 'var(--amber)' : 'var(--ink-3)'}
                 border="var(--line)">{p.k}</Tag>
            </div>
          );
        })}
        <div style={{ height: 1, background: 'var(--line-soft)', margin: '16px 0' }}/>
        <div style={{ fontSize: 11, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 1.4, marginBottom: 8 }}>
          worker nodes
        </div>
        <div style={{ fontSize: 11.5, color: 'var(--ink-2)', lineHeight: 1.7 }}>
          <div><span style={{ color: 'var(--moss-3)' }}>●</span> replay <span style={{ color: 'var(--ink-3)' }}>· mira's cabin</span></div>
          <div><span style={{ color: 'var(--moss-3)' }}>●</span> storage <span style={{ color: 'var(--ink-3)' }}>· mira's cabin, wren's shelf</span></div>
          <div><span style={{ color: 'var(--moss-3)' }}>●</span> relay <span style={{ color: 'var(--ink-3)' }}>· 3 nodes</span></div>
        </div>
      </div>
    </div>
  </div>
);

window.EventLogView = EventLogView;
